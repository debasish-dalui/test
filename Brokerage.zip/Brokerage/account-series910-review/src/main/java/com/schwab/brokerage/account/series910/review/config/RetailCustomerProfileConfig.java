package com.schwab.brokerage.account.series910.review.config;

import com.schwab.brokerage.account.series910.review.constant.RRBusKeys;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import schwab.rrbus._1_0.sch_core_customeraccount_retailcustomerprofileservice.RetailCustomerProfileService;
import schwab.rrbus.provider.JAXWSBindingHandler;
import schwab.rrbus.provider.soap.JAXWSContextHandler;
import schwab.rrbus.requester.config.SpringHandlerConfigurationProperties;
import schwab.rrbus.requester.service.internal.SpringBeanHandler;
import schwab.rrbus.requester.service.internal.SpringBeanServiceRef;

import java.util.Arrays;
import java.util.Properties;

@Configuration
public class RetailCustomerProfileConfig {
    private final String serviceName;
    private final String uddi;
    private final String port;
    private final String wsdlService;

    public RetailCustomerProfileConfig(
            @Value("${service.retail-customer-profile.name}") String serviceName,
            @Value("${service.retail-customer-profile.uddi}") String uddi,
            @Value("${service.retail-customer-profile.port}") String port,
            @Value("${service.retail-customer-profile.cust-retail-login}") String wsdlService) {
        this.serviceName = serviceName;
        this.uddi = uddi;
        this.port = port;
        this.wsdlService = wsdlService;
    }

    @Bean("configPropForRetailCustomerProfileService")
    public SpringHandlerConfigurationProperties springHandlerConfigurationProperties() {
        SpringHandlerConfigurationProperties configurationProperties = new SpringHandlerConfigurationProperties();
        Properties properties = new Properties();
        properties.setProperty(RRBusKeys.RRBUS_NAME, serviceName);
        properties.setProperty(RRBusKeys.RRBUS_SERVICE, uddi);
        properties.setProperty(RRBusKeys.RRBUS_PORT, port);
        properties.setProperty(RRBusKeys.WSDL_SERVICE, wsdlService);
        configurationProperties.setHandlerConfigProperties(properties);
        return configurationProperties;
    }

    @Bean("retailCustomerProfileServiceJAXBindingHandler")
    @DependsOn("configPropForRetailCustomerProfileService")
    public JAXWSBindingHandler retailCustomerProfileServiceJAXBindingHandler(
            @Qualifier("configPropForRetailCustomerProfileService") SpringHandlerConfigurationProperties springHandlerConfigurationProperties
    ) {
        JAXWSBindingHandler retailCustomerProfileServiceJAXBindingHandler = new JAXWSBindingHandler();
        retailCustomerProfileServiceJAXBindingHandler.setHandlerConfigProperties(springHandlerConfigurationProperties);
        return retailCustomerProfileServiceJAXBindingHandler;
    }

    @Bean("retailCustomerProfileServiceSpringBeanBindingHandler")
    @DependsOn("retailCustomerProfileServiceJAXBindingHandler")
    public SpringBeanHandler retailCustomerProfileServiceSpringBeanBindingHandler(
            @Qualifier("retailCustomerProfileServiceJAXBindingHandler") JAXWSBindingHandler retailCustomerProfileServiceJAXBindingHandler
    ) {
        SpringBeanHandler retailCustomerProfileServiceSpringBeanContextHandler = new SpringBeanHandler();
        Properties properties = new Properties();
        properties.setProperty(RRBusKeys.RRBUS_SERVICE, uddi);
        properties.setProperty(RRBusKeys.RRBUS_PORT, port);
        retailCustomerProfileServiceSpringBeanContextHandler.setHandler(retailCustomerProfileServiceJAXBindingHandler);
        retailCustomerProfileServiceSpringBeanContextHandler.setInitParams(properties);
        retailCustomerProfileServiceSpringBeanContextHandler.setPortName("");
        return retailCustomerProfileServiceSpringBeanContextHandler;
    }

    @Bean("retailCustomerProfileServiceBeanJAXContextHolder")
    @DependsOn("configPropForRetailCustomerProfileService")
    public JAXWSContextHandler retailCustomerProfileServiceSpringBeanJAXContextHandler(
            @Qualifier("configPropForRetailCustomerProfileService") SpringHandlerConfigurationProperties configurationProperties
    ) {
        JAXWSContextHandler retailCustomerProfileServiceSpringBeanJAXContextHandler = new JAXWSContextHandler();
        retailCustomerProfileServiceSpringBeanJAXContextHandler.setHandlerConfigProperties(configurationProperties);
        return retailCustomerProfileServiceSpringBeanJAXContextHandler;
    }

    @Bean("retailCustomerProfileServiceSpringBeanContextHandler")
    @DependsOn("retailCustomerProfileServiceJAXBindingHandler")
    public SpringBeanHandler retailCustomerProfileServiceSpringBeanContextHandler(
            @Qualifier("retailCustomerProfileServiceBeanJAXContextHolder") JAXWSContextHandler retailCustomerProfileServiceContextHandler
    ) {
        SpringBeanHandler retailCustomerProfileServiceSpringBeanContextHandler = new SpringBeanHandler();
        Properties properties = new Properties();
        retailCustomerProfileServiceSpringBeanContextHandler.setHandler(retailCustomerProfileServiceContextHandler);
        retailCustomerProfileServiceSpringBeanContextHandler.setInitParams(properties);
        retailCustomerProfileServiceSpringBeanContextHandler.setPortName("");
        return retailCustomerProfileServiceSpringBeanContextHandler;
    }

    @Bean("retailCustomerProfileService")
    public SpringBeanServiceRef springBeanRetailCustomerProfileServiceRef(
            @Qualifier("retailCustomerProfileServiceSpringBeanBindingHandler") SpringBeanHandler retailCustomerProfileServiceSpringBeanBindingHandler,
            @Qualifier("retailCustomerProfileServiceSpringBeanContextHandler") SpringBeanHandler retailCustomerProfileServiceSpringBeanContextHandler
    ) {
        SpringBeanServiceRef beanRetailCustomerProfileServiceRef = new SpringBeanServiceRef();
        beanRetailCustomerProfileServiceRef.setServiceClass(RetailCustomerProfileService.class);
        beanRetailCustomerProfileServiceRef.setServiceRefName("retailcustomercrofileservice/GetCustRetailLoginData");
        beanRetailCustomerProfileServiceRef.setHandlers(
                Arrays.asList(retailCustomerProfileServiceSpringBeanBindingHandler, retailCustomerProfileServiceSpringBeanContextHandler));
        return beanRetailCustomerProfileServiceRef;
    }

}
