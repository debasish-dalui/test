package com.schwab.brokerage.account.series910.review.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ApiModel(description = "Reason for account approval failure.")
public class FailReason {
    @ApiModelProperty("Fail Reason Code.")
    @JsonProperty("resultCode")
    private String failReasonCode;

    @ApiModelProperty("Fail Reason Text.")
    @JsonProperty("resultText")
    private String failReasonText;
}
