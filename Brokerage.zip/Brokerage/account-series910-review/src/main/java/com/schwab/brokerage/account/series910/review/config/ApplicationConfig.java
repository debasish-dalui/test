package com.schwab.brokerage.account.series910.review.config;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.schwab.brokerage.account.series910.review.interceptor.RestSecurityInterceptor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.web.client.RestTemplate;
import schwab.rrbus._1_0.sch_core_enterprisesecurity_brokerageoperationsauthorizationservice.io.Resource;
import schwab.rrbus._1_0.sch_core_enterprisesecurity_brokerageoperationsauthorizationservice.io.ResourceList;
import schwab.rrbus._1_0.sch_core_enterprisesecurity_brokerageoperationsauthorizationservice.io.ResourceType;

import javax.sql.DataSource;

@Slf4j
@Configuration
@SuppressWarnings("unused")
public class ApplicationConfig {
    @Bean
    public ResourceList boaServiceResources(@Value("${boaResourceId}") String boaResourceId) {
        ResourceList resources = new ResourceList();
        Resource resource = new Resource();
        resource.setResourceId(boaResourceId);
        resource.setResourceType(ResourceType.FCT);
        resources.getResource().add(resource);
        return resources;
    }

    @Bean
    public RestTemplate restTemplate(RestTemplateBuilder builder, RestSecurityInterceptor restSecurityInterceptor) {
        return builder
                .additionalInterceptors(restSecurityInterceptor)
                .build();
    }

    @Bean
    @Primary
    public ObjectMapper objectMapper() {
        return new ObjectMapper().registerModules(new Jdk8Module(), new JavaTimeModule());
    }

    @Bean
    @Scope("prototype")
    public SimpleJdbcCall simpleJdbcCall(
            DataSource datasource,
            @Value("${db2.schemaName}") String schemaName,
            @Value("${db2.procedureName}") String procedureName
    ) {
        return new SimpleJdbcCall(datasource).withSchemaName(schemaName).withProcedureName(procedureName);
    }
}
