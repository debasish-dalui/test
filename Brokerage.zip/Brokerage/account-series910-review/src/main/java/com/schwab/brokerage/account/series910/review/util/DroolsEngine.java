
package com.schwab.brokerage.account.series910.review.util;

import com.schwab.brokerage.account.series910.review.model.Account;
import com.schwab.brokerage.account.series910.review.model.DroolsCustomerDetails;
import lombok.extern.slf4j.Slf4j;
import org.kie.dmn.api.core.DMNContext;
import org.kie.dmn.api.core.DMNModel;
import org.kie.dmn.api.core.DMNResult;
import org.kie.dmn.api.core.DMNRuntime;
import org.kie.dmn.core.api.DMNFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;


@Slf4j
@Component
public class DroolsEngine {

    private final DMNModel accountRegistrationEligibilityModel;
    private final DMNRuntime accountRegistrationRuntime;
    private final DMNModel customerEligibilityModel;
    private final DMNRuntime customerEligibilityRuntime;
    private final DMNModel mailingAddressModel;
    private final DMNRuntime mailingAddressRuntime;

    @Autowired
    public DroolsEngine(
            DMNModel accountRegistrationEligibilityModel,
            DMNRuntime accountRegistrationRuntime,
            DMNModel customerEligibilityModel,
            DMNRuntime customerEligibilityRuntime,
            DMNModel mailingAddressModel,
            DMNRuntime mailingAddressRuntime) {

        this.accountRegistrationRuntime = accountRegistrationRuntime;
        this.accountRegistrationEligibilityModel = accountRegistrationEligibilityModel;
        this.customerEligibilityModel = customerEligibilityModel;
        this.customerEligibilityRuntime = customerEligibilityRuntime;
        this.mailingAddressModel = mailingAddressModel;
        this.mailingAddressRuntime = mailingAddressRuntime;
    }


    public Map<String, String> fireEligibilityRule(Account account) {

        DMNContext context = DMNFactory.newContext();
        context.set("productCode", account.getAccountProductCode());
        context.set("registrationCode", account.getAccountRegistrationCode());

        DMNResult dmnResult = accountRegistrationRuntime.evaluateAll(accountRegistrationEligibilityModel, context);
        return populateResult(dmnResult);
    }

    public Map<String, String> fireCustomerRule(DroolsCustomerDetails customerDetails) {

        DMNContext context = DMNFactory.newContext();

        context.set("citizenship", customerDetails.getCitizenship());
        context.set("residencyCode", customerDetails.getResidencyCode());
        context.set("roles", customerDetails.getRole());
        context.set("age", BigDecimal.valueOf(customerDetails.getAge()));
        context.set("organizationCode", customerDetails.getCustomerTypeCode());
        context.set("restriction", customerDetails.getRestriction());
        context.set("brokerageAffiliation", customerDetails.getIndividual407TypeCode());
        context.set("productCode", customerDetails.getAcctProdCode());
        context.set("accountTitleCode", customerDetails.getRole());

        DMNResult dmnResult = customerEligibilityRuntime.evaluateAll(customerEligibilityModel, context);
        return populateResult(dmnResult);

    }


    public Map<String, String> fireMailingAddressRule(String country) {

        DMNContext context = DMNFactory.newContext();
        context.set("country", country);

        DMNResult dmnResult = mailingAddressRuntime.evaluateAll(mailingAddressModel, context);

        return populateResult(dmnResult);

    }


    private Map<String, String> populateResult(DMNResult dmnResult) {
        Map<String, String> result = new HashMap<>();
        dmnResult.getDecisionResults().forEach(dmnDecisionResult -> result.put(dmnDecisionResult.getDecisionName(), (String) dmnDecisionResult.getResult()));
        return result;
    }

}
