package com.schwab.brokerage.account.series910.review.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.schwab.brokerage.account.series910.review.constant.HeaderKeys;
import com.schwab.brokerage.account.series910.review.model.request.ClientRequestHeader;
import com.schwab.brokerage.account.series910.review.model.request.ManualPostRequest;
import com.schwab.brokerage.account.series910.review.model.response.ReturnDetails;
import com.schwab.brokerage.account.series910.review.model.response.Series910Response;
import com.schwab.brokerage.account.series910.review.service.AuthorizationService;
import com.schwab.brokerage.account.series910.review.service.ResultRetrievalService;
import com.schwab.brokerage.account.series910.review.service.ManualReviewUpdateService;
import com.schwab.brokerage.account.series910.review.util.RequestValidator;
import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import schwab.rrbus._1_0.sch_core_enterprisesecurity_brokerageoperationsauthorizationservice.io.AccessType;

import javax.naming.NamingException;
import java.io.IOException;

@Api(tags = "manual")
@Slf4j
@RefreshScope
@RestController
@RequestMapping("/api/brokerage/accounts/series910/results")
@SuppressWarnings("unused")
public class ManualReviewController {
    private final ObjectMapper objectMapper;
    private final ResultRetrievalService resultRetrievalService;
    private final AuthorizationService authorizationService;
    private final RequestValidator requestValidator;
    private final ClientRequestHeader clientRequestHeader;
    private final ManualReviewUpdateService manualReviewUpdateService;


    @Autowired
    public ManualReviewController(
            ObjectMapper objectMapper,
            ResultRetrievalService resultRetrievalService,
            AuthorizationService authorizationService,
            RequestValidator requestValidator,
            ClientRequestHeader clientRequestHeader,
            ManualReviewUpdateService manualReviewUpdateService
    ) {
        this.objectMapper = objectMapper;
        this.resultRetrievalService = resultRetrievalService;
        this.authorizationService = authorizationService;
        this.requestValidator = requestValidator;
        this.clientRequestHeader = clientRequestHeader;
        this.manualReviewUpdateService = manualReviewUpdateService;
    }

    @ApiOperation(
            value = "Retrieve series 9/10 account results in decending order.",
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    @ApiResponses({
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 400, message = "Bad Request"),
            @ApiResponse(code = 500, message = "Internal Server Error")
    })
    @GetMapping(
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public Series910Response autoReviewResult(
            @ApiParam(
                    value = "{\"accountId\": 0}",
                    required = true,
                    example = "{\"accountId\": 0}"
            )
            @RequestHeader(HeaderKeys.CLIENT_REQUEST) String schwabClientRequest
    ) throws IOException, NamingException {

        requestValidator.validateManualGetRequest(schwabClientRequest);

        ObjectNode schwabHeaders = objectMapper.readValue(schwabClientRequest, ObjectNode.class);
        Integer accountId = schwabHeaders.get("accountId").asInt();
        authorizationService.service(accountId,
                AccessType.READ);
        return resultRetrievalService.service(accountId);
    }

    @ApiOperation(
            value = "Manually Add series 9/10 results.",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    @ApiResponses({
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 400, message = "Bad Request", response = ReturnDetails.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ReturnDetails.class)
    })
    @PostMapping(
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    public Series910Response manualPost(
            @ApiParam(
                    value = "{\"channel\": \"CHN\", \"userId\": \"example\"}",
                    required = true,
                    example = "{\"channel\": \"CHN\", \"userId\": \"example\"}"
            )
            @RequestHeader(HeaderKeys.CLIENT_REQUEST) String schwabClientRequest,
            @RequestBody ManualPostRequest manualPostRequest
    ) throws IOException, NamingException {
        requestValidator.validateManualPostRequest(manualPostRequest);
        authorizationService.service(manualPostRequest.getBrokerageAccountId(),
                AccessType.WRITE);

        clientRequestHeader.populateHeaders(schwabClientRequest);

        return manualReviewUpdateService.service(manualPostRequest);
    }
}
