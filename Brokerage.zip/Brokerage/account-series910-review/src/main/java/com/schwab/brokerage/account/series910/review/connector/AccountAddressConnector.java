package com.schwab.brokerage.account.series910.review.connector;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.schwab.brokerage.account.series910.review.exception.RestRuntimeException;
import com.schwab.brokerage.account.series910.review.model.request.GenericRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class AccountAddressConnector {
    private final RestTemplate restTemplate;
    private final HttpHeaders accountAddressServiceHeaders;
    private final ObjectMapper objectMapper;

    @Autowired
    public AccountAddressConnector(
            RestTemplate restTemplate,
            HttpHeaders accountAddressServiceHeaders,
            ObjectMapper objectMapper
    ) {
        this.restTemplate = restTemplate;
        this.accountAddressServiceHeaders = accountAddressServiceHeaders;
        this.objectMapper = objectMapper;
    }

    public ResponseEntity<String> sendRestRequest(String url, HttpMethod httpMethod, GenericRequest requestBody) {
        try {
            HttpEntity<String> restRequest = new HttpEntity<>(
                    objectMapper.writeValueAsString(requestBody),
                    accountAddressServiceHeaders
            );
            return restTemplate.exchange(url, httpMethod, restRequest, String.class);
        } catch (Exception e) {
            throw new RestRuntimeException(e);
        }
    }
}
