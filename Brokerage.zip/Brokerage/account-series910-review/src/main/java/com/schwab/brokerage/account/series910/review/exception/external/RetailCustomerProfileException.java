package com.schwab.brokerage.account.series910.review.exception.external;

import com.schwab.brokerage.account.series910.review.exception.InternalServerException;

public class RetailCustomerProfileException extends InternalServerException {
    private static final String SOURCE = "retail-customer-profile-service";

    public RetailCustomerProfileException() {
        super(SOURCE);
    }

    public RetailCustomerProfileException(String message) {
        super(SOURCE, message);
    }

    public RetailCustomerProfileException(String message, Throwable cause) {
        super(SOURCE, message, cause);
    }

    public RetailCustomerProfileException(Throwable cause) {
        super(SOURCE, cause);
    }
}
