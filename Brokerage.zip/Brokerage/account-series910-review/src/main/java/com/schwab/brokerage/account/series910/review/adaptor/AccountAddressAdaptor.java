package com.schwab.brokerage.account.series910.review.adaptor;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.schwab.brokerage.account.series910.review.connector.AccountAddressConnector;
import com.schwab.brokerage.account.series910.review.model.request.AddressServiceRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Slf4j
@Component
public class AccountAddressAdaptor {
    private final String url;
    private final AccountAddressConnector accountAddressConnector;
    private final ObjectMapper objectMapper;

    @Autowired
    public AccountAddressAdaptor(
            @Value("${service.account-address.detail}") String url,
            AccountAddressConnector accountAddressConnector,
            ObjectMapper objectMapper) {
        this.url = url;
        this.accountAddressConnector = accountAddressConnector;
        this.objectMapper = objectMapper;
    }

    public String getCountryCode(Integer accountId) throws IOException {
        AddressServiceRequest request = new AddressServiceRequest(accountId);
        ResponseEntity<String> response = accountAddressConnector.sendRestRequest(url, HttpMethod.POST, request);

        JsonNode node = objectMapper.readValue(response.getBody(), JsonNode.class);
        node = node.get("accountAddress").get(0).get("countryCode");
        return node.asText();
    }
}
