package com.schwab.brokerage.account.series910.review.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CustomerIdRequest implements GenericRequest {
    private String taxId;

}