package com.schwab.brokerage.account.series910.review.dto.mongo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "series910-results")
@CompoundIndex(def = "{'acctId': 1, '_audit.createDt': -1}", unique = true)
public class Series910ResultMongo {
    private String id;
    @Field(value = "acctId")
    private Integer accountId;
    @Field(value = "trgrEventCd")
    private String triggerEventCode;
    @Field(value = "passFailCd")
    private String passFailCode;
    @Field(value = "channelNm")
    private String channelName;
    @Field(value = "failRsns")
    private List<Series910FailMongo> failReasons;
    @Field(value = "_audit")
    private Series910Audit audit;
}
