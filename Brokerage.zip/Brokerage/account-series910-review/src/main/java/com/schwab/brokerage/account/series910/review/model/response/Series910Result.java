package com.schwab.brokerage.account.series910.review.model.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.schwab.brokerage.account.series910.review.model.FailReason;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Series910Result {

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private LocalDateTime reviewTimestamp;

    private String channelName;

    private String passFailCode;

    private String triggerEventCode;

    private String auditUpdateUserId;

    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private LocalDateTime auditUpdateTimestamp;

    private List<FailReason> failReasons;

}
