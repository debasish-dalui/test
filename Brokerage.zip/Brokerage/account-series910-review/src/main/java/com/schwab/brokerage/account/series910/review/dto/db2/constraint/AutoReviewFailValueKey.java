package com.schwab.brokerage.account.series910.review.dto.db2.constraint;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Data

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Embeddable
public class AutoReviewFailValueKey implements Serializable {
    private AutoReviewFailKey autoReviewFailKey;

    @Column(name = "VALUE_SEQ_ID")
    private Integer valueSequenceId;
}
