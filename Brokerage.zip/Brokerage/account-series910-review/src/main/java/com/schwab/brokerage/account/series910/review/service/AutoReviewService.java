package com.schwab.brokerage.account.series910.review.service;

import com.schwab.brokerage.account.series910.review.adaptor.AccountServiceAdaptor;
import com.schwab.brokerage.account.series910.review.adaptor.DatabaseAdaptor;
import com.schwab.brokerage.account.series910.review.adaptor.Series910ResultAdaptor;
import com.schwab.brokerage.account.series910.review.exception.AccountNotFoundException;
import com.schwab.brokerage.account.series910.review.exception.ValidationAlreadyRunException;
import com.schwab.brokerage.account.series910.review.model.Account;
import com.schwab.brokerage.account.series910.review.model.BrokerageAccount;
import com.schwab.brokerage.account.series910.review.model.Customer;
import com.schwab.brokerage.account.series910.review.model.DroolsCustomerDetails;
import com.schwab.brokerage.account.series910.review.model.request.ClientRequestHeader;
import com.schwab.brokerage.account.series910.review.model.response.ReturnDetails;
import com.schwab.brokerage.account.series910.review.model.response.Series910Response;
import com.schwab.brokerage.account.series910.review.model.response.Series910Result;
import com.schwab.brokerage.account.series910.review.util.DroolsEngine;
import com.schwab.brokerage.account.series910.review.util.FailReasonGenerator;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;
import schwab.mime.lang.StringUtils;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@Slf4j
@RefreshScope
public class AutoReviewService {
    private final AccountServiceAdaptor accountServiceAdaptor;
    private final Series910ResultAdaptor series910ResultAdaptor;
    private final DroolsEngine droolsEngine;
    private final FailReasonGenerator failReasonGenerator;
    private final CustomerDataRetrievalService customerDataRetrievalService;
    private final AccountDataRetrievalService accountDataRetrievalService;
    private final ClientRequestHeader clientRequestHeader;
    private final DatabaseAdaptor databaseAdaptor;
    private final String accountRegistration;
    private final String organizationRestriction;
    private final String ageRestrictionByRole;
    private final String custodianCheck;

    @Autowired
    public AutoReviewService(
            AccountServiceAdaptor accountServiceAdaptor,
            Series910ResultAdaptor series910ResultAdaptor,
            DroolsEngine droolsEngine,
            FailReasonGenerator failReasonGenerator,
            CustomerDataRetrievalService customerDataRetrievalService,
            AccountDataRetrievalService accountDataRetrievalService,
            ClientRequestHeader clientRequestHeader,
            DatabaseAdaptor databaseAdaptor,
            @Value("${series910.droolsEngine.accountRegistrationRule.decisionName.accountRegistration}") String accountRegistration,
            @Value("${series910.droolsEngine.customerEligibilityRule.decisionName.organizationRestriction}") String organizationRestriction,
            @Value("${series910.droolsEngine.customerEligibilityRule.decisionName.ageRestrictionByRole}") String ageRestrictionByRole,
            @Value("${series910.droolsEngine.customerEligibilityRule.decisionName.custodianCheck}") String custodianCheck
    ) {
        this.accountServiceAdaptor = accountServiceAdaptor;
        this.series910ResultAdaptor = series910ResultAdaptor;
        this.droolsEngine = droolsEngine;
        this.failReasonGenerator = failReasonGenerator;
        this.customerDataRetrievalService = customerDataRetrievalService;
        this.accountDataRetrievalService = accountDataRetrievalService;
        this.clientRequestHeader = clientRequestHeader;
        this.databaseAdaptor = databaseAdaptor;
        this.accountRegistration = accountRegistration;
        this.organizationRestriction = organizationRestriction;
        this.ageRestrictionByRole = ageRestrictionByRole;
        this.custodianCheck = custodianCheck;

    }

    public Series910Response service(Integer accountId) throws IOException {
        Account account = accountServiceAdaptor.retrieveAccountDetails(accountId);
        if (account == null ||
                StringUtils.isEmpty(account.getAccountRegistrationCode()) ||
                StringUtils.isEmpty(account.getAccountProductCode())) {
            throw new AccountNotFoundException();
        }

        List<Series910Result> series910ResultList = series910ResultAdaptor.retrieve(accountId);
        if (!org.apache.commons.collections.CollectionUtils.isEmpty(series910ResultList)) {
            throw new ValidationAlreadyRunException();
        }
        String registrationEligibilityResult = droolsEngine.fireEligibilityRule(account).get(accountRegistration);
        if (!"CONFIRMED".equals(registrationEligibilityResult)) {
            failReasonGenerator.addFailReasonToAccount(account, "REG");
            return series910ResponseGenerator(account);
        }
        account = customerDataRetrievalService.service(account);

        applyMailingAddressRule(account);
        applyCustomerRule(account);

        Set<Integer> custIds = account.getCustomers().stream().map(Customer::getCustomerId).collect(Collectors.toSet());
        Set<BrokerageAccount> relatedAccounts = accountDataRetrievalService.service(custIds);

        return series910ResponseGenerator(account);
    }

    private void applyMailingAddressRule(Account account) {
        Map<String, String> result = droolsEngine.fireMailingAddressRule(account.getCountryCode());
        failReasonGenerator.addFailReasonToAccount(account, result.get("mailingAddressCheck"));
    }

    private void applyCustomerRule(Account account) {
        account.getCustomers()
                .forEach(customer ->
                        account.getRolesByCustomer(customer)
                                .forEach(role -> {
                                    DroolsCustomerDetails droolsCustomerDetails = DroolsCustomerDetails.builder()
                                            .acctProdCode(account.getAccountProductCode())
                                            .residencyCode(customer.getCountryOfResidence())
                                            .role(role)
                                            .citizenship(handleMultipleCitizenShips(customer))
                                            .age(calculateAge(customer))
                                            .customerTypeCode(customer.getCustomerTypeCode())
                                            .individual407TypeCode(customer.getIndividual407TypeCode())
                                            .build();
                                    if (!CollectionUtils.isEmpty(customer.getRestrictions())) {
                                        customer.getRestrictions().forEach(s -> {
                                            droolsCustomerDetails.setRestriction(s);
                                            Map<String, String> result = droolsEngine.fireCustomerRule(droolsCustomerDetails);
                                            populateFailReasons(account, customer, result);
                                        });
                                    } else {
                                        Map<String, String> result = droolsEngine.fireCustomerRule(droolsCustomerDetails);
                                        populateFailReasons(account, customer, result);
                                    }
                                })
                );
    }


    private String handleMultipleCitizenShips(Customer customer) {
        String citizenship = "";
        if (!CollectionUtils.isEmpty(customer.getCitizenships())
                && "US".equals(customer.getCitizenships().get(0).getCountryOfCitizenship())
                && customer.getCitizenships().size() == 1) {
            citizenship = "US";
        }
        return citizenship;
    }

    private Double calculateAge(Customer customer) {
        Double age = (double) -1;
        if (!"ORG".equals(customer.getCustomerTypeCode())) {
            long days = ChronoUnit.MONTHS.between(customer.getDateOfBirth(), LocalDate.now());
            age = days / 12.0;
        }
        return age;
    }


    private void populateFailReasons(Account account, Customer customer, Map<String, String> result) {
        if (!"CONFIRMED".equals(result.get(organizationRestriction))) {
            failReasonGenerator.addFailReasonToAccountWithId(account, result.get(organizationRestriction), customer.getCustomerId().toString());
        } else {
            result.forEach((key, value) -> {
                if (custodianCheck.equals(key) || ageRestrictionByRole.equals(key)) {
                    failReasonGenerator.addFailReasonToAccountWithId(account, value, customer.getTaxPayerId());
                } else {
                    failReasonGenerator.addFailReasonToAccountWithId(account, value, customer.getCustomerId().toString());
                }
            });
        }
    }

    private Series910Response series910ResponseGenerator(Account account) {
        log.info("The account has a product code of " + account.getAccountProductCode() + " and a registration code of " + account.getAccountRegistrationCode());

        Series910Result series910Result = Series910Result.builder()
                .reviewTimestamp(LocalDateTime.now())
                .triggerEventCode("AUTO")
                .auditUpdateTimestamp(LocalDateTime.now())
                .failReasons(CollectionUtils.emptyIfNull(account.getFailReasons()).parallelStream().collect(Collectors.toList()))
                .channelName(clientRequestHeader.getChannel())
                .auditUpdateUserId(clientRequestHeader.getUserId())
                .build();
        ReturnDetails returnDetails = ReturnDetails.builder().build();
        if (CollectionUtils.isNotEmpty(account.getFailReasons())) {
            series910Result.setPassFailCode("FAIL");
            returnDetails.setReturnCode(11000);
            returnDetails.setReturnMessage("Account has failed Automated Series 9/10 Review!");
        } else {
            series910Result.setPassFailCode("PASS");
        }
        log.info("The account was an AUTO " + series910Result.getPassFailCode());

        LocalDateTime now = LocalDateTime.now();
        databaseAdaptor.saveAutoReviewResult(
                account.getAccountId(),
                clientRequestHeader.getChannel(),
                "RETAIL",
                "AUTO",
                ("PASS".equals(series910Result.getPassFailCode())) ? "UFSSSTAR" : clientRequestHeader.getUserId(),
                now,
                series910Result.getPassFailCode(),
                now,
                series910Result.getFailReasons()
        );

        return Series910Response.builder()
                .series910Results(Collections.singletonList(series910Result))
                .returnDetails(Collections.singletonList(returnDetails))
                .build();
    }
}
