package com.schwab.brokerage.account.series910.review.exception;

public class AccountNotFoundException extends BadRequestException {

    public AccountNotFoundException(String message) {
        super(10400, message);
    }

    public AccountNotFoundException() {
        super(10400);
    }
}
