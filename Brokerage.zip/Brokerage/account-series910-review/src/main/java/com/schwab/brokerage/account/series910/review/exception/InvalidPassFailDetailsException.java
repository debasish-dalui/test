package com.schwab.brokerage.account.series910.review.exception;

public class InvalidPassFailDetailsException extends BadRequestException {

    public InvalidPassFailDetailsException() {
        super(11003);
    }
}
