package com.schwab.brokerage.account.series910.review.connector;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.schwab.brokerage.account.series910.review.exception.RestRuntimeException;
import com.schwab.brokerage.account.series910.review.model.request.GenericRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class CustomerServiceConnector {
    private final RestTemplate restTemplate;
    private final HttpHeaders customerServiceHeaders;
    private final ObjectMapper objectMapper;

    @Autowired
    public CustomerServiceConnector(
            RestTemplate restTemplate,
            HttpHeaders customerServiceHeaders,
            ObjectMapper objectMapper
    ) {
        this.restTemplate = restTemplate;
        this.customerServiceHeaders = customerServiceHeaders;
        this.objectMapper = objectMapper;
    }

    public ResponseEntity<String> sendRestRequest(String url, HttpMethod httpMethod, GenericRequest requestBody) {
        try {
            HttpEntity<String> restRequest = new HttpEntity<>(objectMapper.writeValueAsString(requestBody), customerServiceHeaders);
            return restTemplate.exchange(url, httpMethod, restRequest, String.class);
        } catch (Exception e) {
            throw new RestRuntimeException(e);
        }
    }
}



