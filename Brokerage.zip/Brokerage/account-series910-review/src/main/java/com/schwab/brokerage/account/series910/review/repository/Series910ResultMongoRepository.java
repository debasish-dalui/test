package com.schwab.brokerage.account.series910.review.repository;

import com.google.common.eventbus.AllowConcurrentEvents;
import com.schwab.brokerage.account.series910.review.dto.mongo.Series910ResultMongo;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface Series910ResultMongoRepository
        extends MongoRepository<
        Series910ResultMongo,
        String
        > {
    List<Series910ResultMongo> findByAccountId(Sort sort, Integer accountId);
}
