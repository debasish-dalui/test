package com.schwab.brokerage.account.series910.review.config;

import com.schwab.brokerage.account.series910.review.constant.HeaderKeys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

@Configuration
@ConfigurationProperties
@SuppressWarnings("unused")
public class RestRequestHeaderConfig {
    @Bean
    public HttpHeaders accountAddressServiceHeaders(
            @Value("${service.account-address.uddi}") String serviceKey,
            @Value("${service.account-address.interface}") String portType
    ) {
        return headerBuilder(serviceKey, portType);
    }

    @Bean
    public HttpHeaders accountServiceHeaders(
            @Value("${service.account.uddi}") String serviceKey,
            @Value("${service.account.interface}") String portType
    ) {
        return headerBuilder(serviceKey, portType);
    }

    @Bean
    public HttpHeaders customerServiceHeaders(
            @Value("${service.customer.uddi}") String serviceKey,
            @Value("${service.customer.interface}") String portType
    ) {
        return headerBuilder(serviceKey, portType);
    }

    @Bean
    public HttpHeaders brokerageCustomerServiceHeaders(
            @Value("${service.brokerage-customer.uddi}") String serviceKey,
            @Value("${service.brokerage-customer.interface}") String portType
    ) {
        return headerBuilder(serviceKey, portType);
    }

    private HttpHeaders headerBuilder(String serviceKey, String portType) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set(HeaderKeys.RRBUS_SERVICE_KEY, serviceKey);
        headers.set(HeaderKeys.RRBUS_PORT_TYPE, portType);
        return headers;
    }
}
