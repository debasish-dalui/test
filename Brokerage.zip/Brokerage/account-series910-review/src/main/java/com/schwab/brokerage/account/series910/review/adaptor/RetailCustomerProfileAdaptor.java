package com.schwab.brokerage.account.series910.review.adaptor;

import com.schwab.brokerage.account.series910.review.connector.RetailCustomerProfileConnectorRest;
import com.schwab.brokerage.account.series910.review.model.BrokerageAccount;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import schwab.rrbus._1_0.sch_core_customeraccount_retailcustomerprofileservice.io.GetCustRetailLoginDataReply;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Component
public class RetailCustomerProfileAdaptor {
    private final RetailCustomerProfileConnectorRest retailCustomerProfileConnectorRest;

    public RetailCustomerProfileAdaptor(RetailCustomerProfileConnectorRest retailCustomerProfileConnectorRest) {
        this.retailCustomerProfileConnectorRest = retailCustomerProfileConnectorRest;
    }

    public List<BrokerageAccount> retrieveBrokerageAccounts(Integer customerId) {
        GetCustRetailLoginDataReply reply = retailCustomerProfileConnectorRest.custRetailLoginData(customerId);
        return reply.getBrokerageAccounts().getBrokerageAccount().stream()
                .map(brokerageAccount -> BrokerageAccount.builder()
                        .accountId(brokerageAccount.getBrkrAcctId())
                        .productCode(brokerageAccount.getProductCode())
                        .registrationCode(brokerageAccount.getTypeCode())
                        .roles(new HashSet<>(Collections.singletonList(brokerageAccount.getRoleTitleCode())))
                        .isClosed(brokerageAccount.isIsClosed())
                        .hasESPP(brokerageAccount.isHasEspp())
                        .build())
                .collect(Collectors.toList());
    }
}
