package com.schwab.brokerage.account.series910.review.property;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Configuration
@ConfigurationProperties(prefix = "db2.storedProcParameters")
@SuppressWarnings("unused")
public class StoredProcParametersProp {
    private String accountId;
    private String channelName;
    private String enterprise;
    private String triggerEventCode;
    private String reviewerUserId;
    private String reviewerUserDate;
    private String reviewerUserTime;
    private String passFailCode;
    private String failReasonCode;
    private String failReasonText;

    private String returnCode;
    private String messageSource;
    private String returnMessage;

    private Integer parameterArrayStart;
    private Integer parameterArrayMax;
}
