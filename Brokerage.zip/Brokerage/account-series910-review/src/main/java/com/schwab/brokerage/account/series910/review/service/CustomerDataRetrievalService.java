package com.schwab.brokerage.account.series910.review.service;


import com.schwab.brokerage.account.series910.review.adaptor.*;
import com.schwab.brokerage.account.series910.review.config.Series910Config;
import com.schwab.brokerage.account.series910.review.exception.DataAggregationException;
import com.schwab.brokerage.account.series910.review.model.Account;
import com.schwab.brokerage.account.series910.review.model.Customer;
import com.schwab.brokerage.account.series910.review.model.FailReason;
import com.schwab.brokerage.account.series910.review.model.request.ClientRequestHeader;
import com.schwab.brokerage.account.series910.review.model.response.AccountCustRoleResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class CustomerDataRetrievalService {
    private final AccountServiceAdaptor accountServiceAdaptor;
    private final CustomerServiceAdaptor customerServiceAdaptor;
    private final AccountAddressAdaptor accountAddressAdaptor;
    private final BrokerageCustomerAdaptor brokerageCustomerAdaptor;
    private final DatabaseAdaptor databaseAdaptor;
    private final ClientRequestHeader clientRequestHeader;
    private final Series910Config series910Config;

    @Autowired
    public CustomerDataRetrievalService(
            AccountServiceAdaptor accountServiceAdaptor,
            CustomerServiceAdaptor customerServiceAdaptor,
            AccountAddressAdaptor accountAddressAdaptor,
            BrokerageCustomerAdaptor brokerageCustomerAdaptor,
            DatabaseAdaptor databaseAdaptor,
            ClientRequestHeader clientRequestHeader,
            Series910Config series910Config
    ) {
        this.accountServiceAdaptor = accountServiceAdaptor;
        this.customerServiceAdaptor = customerServiceAdaptor;
        this.accountAddressAdaptor = accountAddressAdaptor;
        this.brokerageCustomerAdaptor = brokerageCustomerAdaptor;
        this.databaseAdaptor = databaseAdaptor;
        this.clientRequestHeader = clientRequestHeader;
        this.series910Config = series910Config;
    }

    public Account service(Account account) throws IOException {
        List<AccountCustRoleResponse> accountCustRoleResponses = accountServiceAdaptor.retrieveAccountRoles(account);
        if (CollectionUtils.isEmpty(accountCustRoleResponses)) {
            handleDataRetrievalError(account.getAccountId(), 11005, "No customers were found for this account.");
        } else {
            List<AccountCustRoleResponse> filteredAccountCustRoles = filterRoles(account.getAccountId(), accountCustRoleResponses);
            retrieveCustomerDetails(account, filteredAccountCustRoles);

            account.setCountryCode(accountAddressAdaptor.getCountryCode(account.getAccountId()));

            for (Customer c : account.getCustomers()) {
                c.setRestrictions(brokerageCustomerAdaptor.retrieveCustomerRestrictions(c.getCustomerId()));
            }
        }
        return account;
    }

    private List<AccountCustRoleResponse> filterRoles(Integer accountId, List<AccountCustRoleResponse> custRoleList) {
        List<AccountCustRoleResponse> filteredCustRoleList = custRoleList.stream()
                .filter(accountCustRoleResponse -> series910Config.getValidCustRoles().contains(accountCustRoleResponse.getRole()))
                .collect(Collectors.toList());

        if (CollectionUtils.isEmpty(filteredCustRoleList)) {
            handleDataRetrievalError(accountId, 11005, "No customers were found with Auto series 9/10 eligible roles");
        }
        return filteredCustRoleList;
    }

    private void retrieveCustomerDetails(Account account, List<AccountCustRoleResponse> custRolesList) throws IOException {

        for (AccountCustRoleResponse accountCustRoleResponse : custRolesList) {
            Customer customer = customerServiceAdaptor.retrieveCustomerDetails(accountCustRoleResponse.getCustomerId());
            if (customer == null) {
                handleDataRetrievalError(account.getAccountId(), 11006, "No Customer Details found for Customer.");
            } else {
                customer.setIndividual407TypeCode(customerServiceAdaptor.retrieveCustomer407Code(customer.getCustomerId()));
                account.addCustomer(customer, accountCustRoleResponse.getRole());
            }
        }
    }

    private void saveToDatabase(Integer accountId, FailReason fail) {
        LocalDateTime now = LocalDateTime.now();
        databaseAdaptor.saveAutoReviewResult(
                accountId,
                clientRequestHeader.getChannel(),
                "RETAIL",
                "AUTO",
                clientRequestHeader.getUserId(),
                now,
                "FAIL",
                now,
                new ArrayList<>(Collections.singletonList(fail))
        );
    }

    private void handleDataRetrievalError(Integer accountId, Integer errorCode, String failTxt) {
        log.info("Data Aggregation Error.  " + failTxt);
        FailReason fail = new FailReason("OTH", failTxt);
        saveToDatabase(accountId, fail);
        throw new DataAggregationException(errorCode, failTxt);
    }
}
