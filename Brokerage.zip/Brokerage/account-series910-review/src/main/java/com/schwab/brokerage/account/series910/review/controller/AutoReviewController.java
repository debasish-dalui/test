package com.schwab.brokerage.account.series910.review.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.schwab.brokerage.account.series910.review.constant.HeaderKeys;
import com.schwab.brokerage.account.series910.review.model.request.AutoReviewPostRequest;
import com.schwab.brokerage.account.series910.review.model.response.ReturnDetails;
import com.schwab.brokerage.account.series910.review.model.response.Series910Response;
import com.schwab.brokerage.account.series910.review.service.AuthorizationService;
import com.schwab.brokerage.account.series910.review.service.AutoReviewService;
import com.schwab.brokerage.account.series910.review.util.RequestValidator;
import com.schwab.brokerage.account.series910.review.model.request.ClientRequestHeader;
import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;


@Api(tags = "auto")
@Slf4j
@RestController
@RequestMapping(value = "${series910.endpoint.auto}")
@SuppressWarnings("unused")
public class AutoReviewController {
    private final ObjectMapper objectMapper;
    private final AutoReviewService autoReviewService;
    private final AuthorizationService authorizationService;
    private final RequestValidator requestValidator;
    private final ClientRequestHeader clientRequestHeader;

    @Autowired
    public AutoReviewController(
            ObjectMapper objectMapper,
            AutoReviewService autoReviewService,
            AuthorizationService authorizationService,
            ClientRequestHeader clientRequestHeader,
            RequestValidator requestValidator
    ) {
        this.objectMapper = objectMapper;
        this.autoReviewService = autoReviewService;
        this.authorizationService = authorizationService;
        this.clientRequestHeader = clientRequestHeader;
        this.requestValidator = requestValidator;
    }

    @ApiOperation(
            value = "Apply auto-series 9/10 rules to the account.",
            consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE
    )
    @ApiResponses({
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 400, message = "Bad Request", response = ReturnDetails.class),
            @ApiResponse(code = 500, message = "Internal Server Error", response = ReturnDetails.class)
    })
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public Series910Response autoApprovalRules(
            @ApiParam(
                    value = "{\"channel\": \"CHN\", \"userId\": \"string\"}",
                    required = true,
                    example = "{\"channel\": \"CHN\", \"userId\": \"string\"}"
            )
            @RequestHeader(HeaderKeys.CLIENT_REQUEST) String clientRequest,
            @RequestBody AutoReviewPostRequest autoReviewPostRequest
    ) throws Exception {
        requestValidator.validateAutoReviewPostRequest(autoReviewPostRequest);
        authorizationService.service(autoReviewPostRequest.getAccountId(), null);
        clientRequestHeader.populateHeaders(clientRequest);
        return autoReviewService.service(autoReviewPostRequest.getAccountId());
    }
}


