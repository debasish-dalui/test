package com.schwab.brokerage.account.series910.review.adaptor;

import com.schwab.brokerage.account.series910.review.model.FailReason;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

public interface DatabaseAdaptor {
    Map<String, Object> saveAutoReviewResult(
            Integer accountId,
            String channelName,
            String enterprise,
            String triggerEventCode,
            String reviewUserId,
            LocalDateTime reviewUserTimestamp,
            String passFailCode,
            LocalDateTime auditUpdateTimestamp,
            List<FailReason> autoReviewFails
    );
}
