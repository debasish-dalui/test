package com.schwab.brokerage.account.series910.review.util;

import com.schwab.brokerage.account.series910.review.exception.InternalServerException;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import schwab.comsec.authn.client.InvalidSecurityTokenException;
import schwab.comsec.authn.client.KeystoreManager;
import schwab.comsec.authn.client.SamlSecurityToken;
import schwab.comsec.authn.client.SecurityTokenValidationError;
import schwab.comsec.authn.client.rrbus.SessionContextImpl;
import schwab.comsec.authn.client.services.SecurityTokenServiceClient;
import schwab.comsec.authn.client.services.ServiceManager;
import schwab.rrbus.requester.ApplicationContext;
import schwab.rrbus.requester.ServiceContext;
import schwab.rrbus.requester.SessionContext;

import javax.xml.soap.SOAPElement;

@Slf4j
@Component
public class TokenGenerator {
    @Getter
    private SOAPElement systemSamlToken;
    private final String cert;
    private final String pswd;

    @Autowired
    public TokenGenerator(
            @Value("${encodedcert}") String cert,
            @Value("${encodedpswd}") String pswd
    ) {
        this.cert = cert;
        this.pswd = pswd;
    }

    public String getToken() {
        if (systemSamlToken == null) {
            systemSamlToken = generateNewToken();
        }
        try {
            validateCurrentToken(systemSamlToken);
            log.info("AutoSeries Token is still valid");
            return "SAML " + encode(systemSamlToken);
        } catch (Exception e) {
            log.info("AutoSeries Token is invalid, generating a new one");
            return "SAML " + encode(generateNewToken());
        }
    }


    private SOAPElement generateNewToken() {
        SessionContext sessionCtx = new SessionContextImpl(null);
        ApplicationContext appCtx = ServiceContext.getApplicationContext();
        ServiceContext.init(sessionCtx, appCtx);
        KeystoreManager.getInstance(cert, pswd);
        try {
            SecurityTokenServiceClient sts = ServiceManager.getSecurityTokenService();
            return sts.getSecurityToken(null,
                    "urn:schwab:comsec:1.0:entity:System",
                    "urn:schwab:comsec:1.0:entity:System",
                    true);
        } catch (Exception e) {
            log.info("Unable to generate a token: " + e.getMessage());
            throw new InternalServerException("account-series910-review", "Unable to generate SystemSAML token", e);
        }

    }


    private String encode(SOAPElement token) {
        byte[] encodedBytes = Base64.encodeBase64(token.toString().getBytes());
        return new String(encodedBytes);
    }

    public String decode(String token) {
        byte[] decodedBytes = Base64.decodeBase64(token.getBytes());
        return new String(decodedBytes);
    }

    private void validateCurrentToken(SOAPElement token)
            throws SecurityTokenValidationError, InvalidSecurityTokenException {
        SamlSecurityToken saml = new SamlSecurityToken(token);
        saml.validate();
    }
}
