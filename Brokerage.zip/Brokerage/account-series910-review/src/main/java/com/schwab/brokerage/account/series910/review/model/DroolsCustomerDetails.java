package com.schwab.brokerage.account.series910.review.model;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DroolsCustomerDetails {

    private String acctProdCode;
    private String residencyCode;
    private String role;
    private String citizenship;
    private Double age;
    private String customerTypeCode;
    private String restriction;
    private String individual407TypeCode;

}
