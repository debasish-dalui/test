package com.schwab.brokerage.account.series910.review.util;

import com.schwab.brokerage.account.series910.review.config.Series910Config;
import com.schwab.brokerage.account.series910.review.model.Account;
import com.schwab.brokerage.account.series910.review.model.FailReason;
import com.schwab.brokerage.account.series910.review.model.request.ManualPostRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@Component
@Slf4j
public class FailReasonGenerator {
    private final Series910Config series910Config;
    @Autowired
    public FailReasonGenerator(Series910Config series910Config) {
        this.series910Config = series910Config;
    }

    public void addFailReasonToAccount(Account account, String failReasonCode) {
        if (series910Config.getValidFailReasons().containsKey(failReasonCode)) {
            log.info("The account has a fail reason of: " + failReasonCode);
            account.getFailReasons().add(FailReason.builder()
                    .failReasonCode(failReasonCode)
                    .failReasonText(series910Config.getValidFailReasons().get(failReasonCode))
                    .build());

        }
    }

    public void addFailReasonToAccountWithId(Account account, String failReasonCode, String id) {
        if (series910Config.getValidFailReasons().containsKey(failReasonCode)) {
            log.info("The account has a fail reason of: " + failReasonCode);
            account.getFailReasons().add(FailReason.builder()
                    .failReasonCode(failReasonCode)
                    .failReasonText(String.format(series910Config.getValidFailReasons().get(failReasonCode), id))
                    .build());
        }
    }

    public List<FailReason> addFailReasonToSaveResultRequest(ManualPostRequest request) {
        return request.getResultCode().stream()
                .map(s -> FailReason.builder()
                        .failReasonCode(series910Config.getValidFailReasons().get(s))
                        .failReasonText(s)
                        .build())
                .collect(Collectors.toList());
    }
}
