package com.schwab.brokerage.account.series910.review.exception;

public class DataAggregationException extends BadRequestException {
    public DataAggregationException(Integer code, String msg) {
        super(code, msg);
    }
}
