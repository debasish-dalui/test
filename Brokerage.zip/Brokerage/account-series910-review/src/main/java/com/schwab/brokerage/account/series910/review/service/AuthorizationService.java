package com.schwab.brokerage.account.series910.review.service;

import com.schwab.boa.helper.BOAHelper;
import com.schwab.brokerage.account.series910.review.exception.NotAuthorizedException;
import com.schwab.token.helper.TokenHelper;
import com.schwab.token.helper.dto.TokenDetail;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import schwab.rrbus._1_0.sch_core_enterprisesecurity_brokerageoperationsauthorizationservice.io.AccessType;
import schwab.rrbus._1_0.sch_core_enterprisesecurity_brokerageoperationsauthorizationservice.io.GetResourceAndConfidentialAccessPermissionsReply;
import schwab.rrbus._1_0.sch_core_enterprisesecurity_brokerageoperationsauthorizationservice.io.ResourceList;
import schwab.rrbus._1_0.sch_core_enterprisesecurity_brokerageoperationsauthorizationservice.io.ResourceVerified;

import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;
import java.util.Arrays;

@Slf4j
@Service
public class AuthorizationService {

    private final TokenHelper tokenHelper;
    private final BOAHelper boaHelper;
    private final ResourceList boaServiceResources;

    @Autowired
    public AuthorizationService(TokenHelper tokenHelper,
                                BOAHelper boaHelper,
                                ResourceList boaServiceResources) {
        this.boaHelper = boaHelper;
        this.boaServiceResources = boaServiceResources;
        this.tokenHelper = tokenHelper;
    }

    public String service(Integer accountId, AccessType accessType) throws NamingException {
        TokenDetail tokenDetail = tokenHelper.getTokenDetails();
        if (tokenDetail.getRepId() != null) {
            tokenAuthorization(accountId, accessType);
        } else if (tokenDetail.getSystemId() == null
                && tokenDetail.getRepId() == null) {
            log.info("Actor was neither a Rep nor a System");
            throw new NotAuthorizedException(403, "");
        }
        return "User has been authenticated";
    }

    public void tokenAuthorization(Integer accountId, AccessType accessType) throws NamingException {
        boaServiceResources.getResource().get(0).setAccessType(accessType);

        GetResourceAndConfidentialAccessPermissionsReply getResourceAndConfidentialAccessPermissionsReply =
                boaHelper.getResourceAndConfidentialAccessPermissions(Arrays.asList(accountId), boaServiceResources, 0);

        ResourceVerified resourceVerified = getResourceAndConfidentialAccessPermissionsReply
                .getResourcesVerified()
                .getResourceVerified()
                .get(0);
        if (!resourceVerified.isHasAccess()) {
            log.error("User does not have " + accessType.value() + " access.");
            throw new NotAuthorizedException(403, "");
        }

    }


}
