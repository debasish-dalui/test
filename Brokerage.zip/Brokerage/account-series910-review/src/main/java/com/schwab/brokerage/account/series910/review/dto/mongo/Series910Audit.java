package com.schwab.brokerage.account.series910.review.dto.mongo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Document
public class Series910Audit {
    @Field(value = "createBy")
    private String createdBy;
    @Field(value = "createDt")
    private LocalDateTime creationDate;
    @Field(value = "lastUpdtBy")
    private String lastUpdatedBy;
    @Field(value = "lastUpdtTs")
    private LocalDateTime lastUpdateTimestamp;

    private Integer version;

    private Integer schemaVersion;
}
