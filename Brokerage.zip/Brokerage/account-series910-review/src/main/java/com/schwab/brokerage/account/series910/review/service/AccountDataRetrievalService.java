package com.schwab.brokerage.account.series910.review.service;

import com.schwab.brokerage.account.series910.review.adaptor.AccountServiceAdaptor;
import com.schwab.brokerage.account.series910.review.adaptor.RetailCustomerProfileAdaptor;
import com.schwab.brokerage.account.series910.review.exception.BadRequestException;
import com.schwab.brokerage.account.series910.review.model.BrokerageAccount;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class AccountDataRetrievalService {

    private final RetailCustomerProfileAdaptor retailCustomerProfileAdaptor;
    private final AccountServiceAdaptor accountServiceAdaptor;

    @Autowired
    public AccountDataRetrievalService(RetailCustomerProfileAdaptor retailCustomerProfileAdaptor,
                                       AccountServiceAdaptor accountServiceAdaptor) {
        this.retailCustomerProfileAdaptor = retailCustomerProfileAdaptor;
        this.accountServiceAdaptor = accountServiceAdaptor;
    }

    public Set<BrokerageAccount> service(Set<Integer> customerIds) {
        return new HashSet<>(customerIds.stream()
                .map(retailCustomerProfileAdaptor::retrieveBrokerageAccounts)
                .flatMap(Collection::stream)
                .peek((BrokerageAccount brokerageAccount) -> {
                    try {
                        brokerageAccount.setRestrictions(accountServiceAdaptor.retrieveAccountRestrictions(brokerageAccount.getAccountId()));
                    } catch (IOException e) {
                        throw new BadRequestException(e);
                    }
                }).collect(Collectors.toMap(
                        BrokerageAccount::hashCode,
                        Function.identity(),
                        (account, account1) -> {
                            account.getRoles().addAll(account1.getRoles());
                            return account;
                        }
                )).values()
        );
    }
}
