package com.schwab.brokerage.account.series910.review.model;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.cache.annotation.Cacheable;

import java.util.Set;

@Data
@EqualsAndHashCode(of = "accountId")
@Builder
public class BrokerageAccount {
    private Integer accountId;
    private String productCode;
    private String registrationCode;
    private Set<String> roles;
    private Set<String> restrictions;
    private Boolean isClosed;
    private Boolean hasESPP;
}
