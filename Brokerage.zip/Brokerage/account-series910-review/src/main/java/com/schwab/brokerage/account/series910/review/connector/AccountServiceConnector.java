package com.schwab.brokerage.account.series910.review.connector;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.schwab.brokerage.account.series910.review.exception.external.AccountServiceException;
import com.schwab.brokerage.account.series910.review.model.request.GenericRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class AccountServiceConnector {
    private final RestTemplate restTemplate;
    private final HttpHeaders accountServiceHeaders;
    private final ObjectMapper objectMapper;

    @Autowired
    public AccountServiceConnector(
            RestTemplate restTemplate,
            HttpHeaders accountServiceHeaders,
            ObjectMapper objectMapper
    ) {
        this.restTemplate = restTemplate;
        this.accountServiceHeaders = accountServiceHeaders;
        this.objectMapper = objectMapper;
    }

    public ResponseEntity<String> sendRestRequest(String url, HttpMethod httpMethod, GenericRequest requestBody) {
        try {
            HttpEntity<String> restRequest = new HttpEntity<>(objectMapper.writeValueAsString(requestBody), accountServiceHeaders);
            return restTemplate.exchange(url, httpMethod, restRequest, String.class);
        } catch (Exception e) {
            throw new AccountServiceException(e);
        }
    }
}
