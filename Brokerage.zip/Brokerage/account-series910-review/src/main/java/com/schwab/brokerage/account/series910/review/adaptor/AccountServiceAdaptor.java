package com.schwab.brokerage.account.series910.review.adaptor;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.schwab.brokerage.account.series910.review.connector.AccountServiceConnector;
import com.schwab.brokerage.account.series910.review.model.Account;
import com.schwab.brokerage.account.series910.review.model.request.AccountServiceRequest;
import com.schwab.brokerage.account.series910.review.model.response.AccountCustRoleResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.*;

@Slf4j
@Component
public class AccountServiceAdaptor {
    private final String attributeEndpoint;
    private final String custRoleEndpoint;
    private final String restrictionEndpoint;
    private final ObjectMapper objectMapper;
    private final AccountServiceConnector accountServiceConnector;

    @Autowired
    public AccountServiceAdaptor(
            @Value("${service.account.attribute}") String attributeEndpoint,
            @Value("${service.account.cust-role}") String custRoleEndpoint,
            @Value("${service.account.restriction}") String restrictionEndpoint,
            ObjectMapper objectMapper,
            AccountServiceConnector accountServiceConnector) {
        this.attributeEndpoint = attributeEndpoint;
        this.custRoleEndpoint = custRoleEndpoint;
        this.restrictionEndpoint = restrictionEndpoint;
        this.objectMapper = objectMapper;
        this.accountServiceConnector = accountServiceConnector;
    }

    @Cacheable("accounts")
    public Account retrieveAccountDetails(Integer accountId) throws IOException {
        AccountServiceRequest accountServiceRequest = AccountServiceRequest.builder()
                .accountId(accountId)
                .build();
        HttpEntity<String> response = accountServiceConnector.sendRestRequest(attributeEndpoint, HttpMethod.POST, accountServiceRequest);


        return formulateAccount(response);
    }

    private Account formulateAccount(HttpEntity<String> response) throws IOException {
        String correlationId = objectMapper.readTree(response.getHeaders()
                .get("x-cat-envelope")
                .get(0))
                .get("CorrelationId")
                .asText();
        Account responseAccount = objectMapper.readValue(response.getBody(), Account.class);
        responseAccount.setPassFailCode("FAIL");
        responseAccount.setCorrelationId(UUID.fromString(correlationId));

        return Account.builder()
                .correlationId(UUID.fromString(correlationId))
                .accountId(responseAccount.getAccountId())
                .accountRegistrationCode(responseAccount.getAccountRegistrationCode())
                .accountProductCode(responseAccount.getAccountProductCode())
                .build();
    }

    public List<AccountCustRoleResponse> retrieveAccountRoles(Account primaryAccount) throws IOException {
        AccountServiceRequest requestBody = new AccountServiceRequest(primaryAccount.getAccountId());
        ResponseEntity<String> response = accountServiceConnector.sendRestRequest(custRoleEndpoint, HttpMethod.POST, requestBody);

        JsonNode node = objectMapper.readValue(response.getBody(), JsonNode.class);
        if (!node.has("acctCustRoleList")) {
            return Collections.emptyList();
        }
        node = node.get("acctCustRoleList");
        String custRoleList = node.toString();
        TypeFactory typeFactory = objectMapper.getTypeFactory();
        return objectMapper.readValue(custRoleList, typeFactory.constructCollectionType(List.class, AccountCustRoleResponse.class));
    }

    public Set<String> retrieveAccountRestrictions(Integer accountId) throws IOException {
        AccountServiceRequest requestBody = new AccountServiceRequest(accountId);
        ResponseEntity<String> response = accountServiceConnector.sendRestRequest(restrictionEndpoint, HttpMethod.POST, requestBody);

        JsonNode node = objectMapper.readValue(response.getBody(), JsonNode.class);
        if (!node.has("restrictions")) {
            return Collections.emptySet();
        }
        Set<String> results = new HashSet<>();
        Iterator<JsonNode> iter = node.get("restrictions").elements();
        while (iter.hasNext()) {
            node = iter.next();
            results.add(node.get("reasonShortName").asText());
        }

        return results;
    }
}
