package com.schwab.brokerage.account.series910.review.exception.external;

import com.schwab.brokerage.account.series910.review.exception.InternalServerException;

public class AccountServiceException extends InternalServerException {
    private static final String SOURCE = "account-service";

    public AccountServiceException(Throwable cause) {
        super(SOURCE, cause);
    }
}
