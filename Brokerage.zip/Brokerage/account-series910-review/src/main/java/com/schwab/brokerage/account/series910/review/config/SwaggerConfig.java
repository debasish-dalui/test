package com.schwab.brokerage.account.series910.review.config;

import com.schwab.brokerage.account.series910.review.constant.HeaderKeys;
import com.schwab.brokerage.account.series910.review.controller.AutoReviewController;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.Arrays;

@EnableSwagger2
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Configuration
@ConfigurationProperties(prefix = "swagger.api")
@SuppressWarnings("unused")
public class SwaggerConfig {
    private String version;
    private String title;
    private String description;
    private String termsOfServiceUrl;
    private String license;
    private String licenseUrl;

    @Bean
    public Docket series910Api(
            @Value("${schwab.rrbus.service.key}") String uddi
    ) {
        ModelRef modelRef = new ModelRef("string");
        String parameterType = "header";
        return new Docket(DocumentationType.SWAGGER_2)
                .globalOperationParameters(
                        Arrays.asList(
                                new ParameterBuilder()
                                        .modelRef(modelRef)
                                        .required(true)
                                        .parameterType(parameterType)
                                        .name(HttpHeaders.AUTHORIZATION)
                                        .description("SAML Token")
                                        .build(),
                                new ParameterBuilder()
                                        .modelRef(modelRef)
                                        .required(true)
                                        .parameterType(parameterType)
                                        .name(HeaderKeys.RRBUS_SERVICE_KEY)
                                        .description(HeaderKeys.RRBUS_SERVICE_KEY)
                                        .defaultValue(uddi)
                                        .build(),
                                new ParameterBuilder()
                                        .modelRef(modelRef)
                                        .required(true)
                                        .parameterType(parameterType)
                                        .name(HeaderKeys.RRBUS_PORT_TYPE)
                                        .description(HeaderKeys.RRBUS_PORT_TYPE)
                                        .defaultValue("BrokerageAccountSeries910ServiceInterfaceCL3")
                                        .build()
                        ))
                .apiInfo(apiInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage(AutoReviewController.class.getPackage().getName()))
                .paths(PathSelectors.ant("/api/**"))
                .build();
    }


    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title(title)
                .version(version)
                .termsOfServiceUrl(termsOfServiceUrl)
                .license(license)
                .licenseUrl(licenseUrl)
                .description(description)
                .build();
    }
}
