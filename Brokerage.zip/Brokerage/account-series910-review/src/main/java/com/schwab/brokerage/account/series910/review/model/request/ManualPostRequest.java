package com.schwab.brokerage.account.series910.review.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ApiModel("Manual Post Request")
public class ManualPostRequest {
    @JsonProperty("accountId")
    private Integer brokerageAccountId;

    private String passFailCode;
    private String indicator;
    private String caseId;

    @ApiModelProperty(allowableValues =
            "AB,AGE,CO,CSH,CT,CUA,DAY,DS,FI,FMA,FR,FRC,FRR," +
                    "IA,IN,IR,LIQ,MAN,MI,MN,ORG,OTH,PAC,RA,RE,REG,RI," +
                    "STR,STU,UI,UND,407"
    )

    private List<String> resultCode;

}
