package com.schwab.brokerage.account.series910.review.config;

import org.apache.cxf.Bus;
import org.apache.cxf.BusFactory;
import org.apache.cxf.interceptor.OutInterceptors;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.ImportResource;
import schwab.rrbus.requester.config.SpringHandlerConfigurationProperties;
import schwab.rrbus.requester.service.internal.SpringBeanServiceManager;
import schwab.rrbus.requester.service.internal.SpringBeanServiceRef;
import schwab.rrbus.requester.soap.RRBusMessageSenderInterceptor;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * RRBUSHandler
 */
@Configuration
@OutInterceptors(interceptors = "rrbusInterceptor")
@ImportResource("classpath:/interceptorConfig.xml")
@SuppressWarnings("unused")
public class RRBUSHandler {
    @Bean
    public SpringBeanServiceManager getSchwabSpringBeanServiceManager(
//            @Qualifier("brokerageOperationsAuthorizationService") SpringBeanServiceRef beanServiceRef,
            @Qualifier("retailCustomerProfileService") SpringBeanServiceRef serviceRefForRetailCustomerProfileService
    ) {
        SpringBeanServiceManager beanServiceManager = SpringBeanServiceManager.getInstance();
        Map<String, SpringBeanServiceRef> serviceRefMap = new HashMap<>(2, 2);
//        serviceRefMap.put("service/boaService", beanServiceRef);
        serviceRefMap.put("retailcustomercrofileservice/GetCustRetailLoginData", serviceRefForRetailCustomerProfileService);
        beanServiceManager.setServiceReferences(serviceRefMap);
        return beanServiceManager;
    }

    @Bean("rrbusInterceptor")
    @DependsOn("configPropForRetailCustomerProfileService")
    public RRBusMessageSenderInterceptor getSchwabRRBusMessageSender(
            @Qualifier("configPropForRetailCustomerProfileService") SpringHandlerConfigurationProperties configurationProperties
    ) {
        RRBusMessageSenderInterceptor busMessageSenderInterceptor = new RRBusMessageSenderInterceptor();
        busMessageSenderInterceptor.setHandlerConfigProperties(Arrays.asList(configurationProperties));
        return busMessageSenderInterceptor;
    }

    @Bean
    public Bus bus(
            @Qualifier("rrbusInterceptor") RRBusMessageSenderInterceptor rrBusMessageSenderInterceptor
    ) {
        Bus bus = BusFactory.getDefaultBus();
        bus.getInInterceptors().add(rrBusMessageSenderInterceptor);
        bus.getOutInterceptors().add(rrBusMessageSenderInterceptor);
        return bus;
    }
}
