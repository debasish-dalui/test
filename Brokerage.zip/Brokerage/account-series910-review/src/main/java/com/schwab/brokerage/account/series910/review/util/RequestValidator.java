package com.schwab.brokerage.account.series910.review.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.schwab.brokerage.account.series910.review.config.Series910Config;
import com.schwab.brokerage.account.series910.review.exception.BadRequestException;
import com.schwab.brokerage.account.series910.review.exception.InvalidPassFailDetailsException;
import com.schwab.brokerage.account.series910.review.exception.InvalidResultCodesException;
import com.schwab.brokerage.account.series910.review.model.request.AutoReviewPostRequest;
import com.schwab.brokerage.account.series910.review.model.request.ManualPostRequest;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class RequestValidator {
    private final Series910Config series910Config;
    private final ObjectMapper objectMapper;

    public RequestValidator(Series910Config series910Config, ObjectMapper objectMapper) {
        this.series910Config = series910Config;
        this.objectMapper = objectMapper;
    }

    public void validateAutoReviewPostRequest(AutoReviewPostRequest autoReviewPostRequest) {
        if (autoReviewPostRequest.getAccountId() == null) {
            throw new BadRequestException("Account ID missing from request.");
        }

        if (autoReviewPostRequest.getAccountId() <= 0) {
            throw new BadRequestException("Account number must be larger than 0.");
        }
    }

    public void validateManualPostRequest(ManualPostRequest request) {
        if (request.getBrokerageAccountId() == null || request.getPassFailCode() == null || request.getResultCode() == null) {
            throw new BadRequestException("Request Body is missing field.");
        }

        checkRequestStructure(request);

        List<String> invalidResultCodes = findInvalidResultCodes(request.getResultCode());
        if (!invalidResultCodes.isEmpty()) {
            String errorMsg = "The following result codes are invalid: ["
                    + String.join(",", invalidResultCodes) + "]";
            throw new InvalidResultCodesException(errorMsg);
        }
    }

    private void checkRequestStructure(ManualPostRequest request) {
        if (request.getPassFailCode().equals("PASS")) {
            passValidateResultCode(request.getResultCode());
        } else if (request.getPassFailCode().equals("FAIL")) {
            failValidateResultCode(request.getResultCode());
        } else {
            throw new InvalidPassFailDetailsException();
        }
    }

    private void passValidateResultCode(List<String> resultCodes) {
        if (CollectionUtils.isNotEmpty(resultCodes)) {
            throw new InvalidResultCodesException("Accounts set to PASS should not have result codes");
        }
    }

    private void failValidateResultCode(List<String> resultCodes) {
        if (CollectionUtils.isEmpty(resultCodes)) {
            throw new InvalidResultCodesException("Accounts set to FAIL should have at least one Result Code");
        } else if (resultCodes.size() > 50) {
            throw new InvalidResultCodesException("Accounts can have at most 50 Result codes");
        }
    }

    private List<String> findInvalidResultCodes(List<String> requestResultCodes) {
        return requestResultCodes.stream()
                .filter(s -> !series910Config.getValidFailReasons().keySet().contains(s))
                .collect(Collectors.toList());
    }


    public void validateManualGetRequest(String schwabClientRequest) throws IOException {
        ObjectNode schwabHeaders = objectMapper.readValue(schwabClientRequest, ObjectNode.class);
        if (!schwabHeaders.has("accountId")) {
            throw new BadRequestException("AccountId is missing from the headers");
        }
        Integer accountId = schwabHeaders.get("accountId").asInt();
        validateAccountId(accountId);

    }

    private void validateAccountId(Integer accountId) {
        if (accountId == null) {
            throw new BadRequestException("AccountId is missing from the request");
        }
        if (accountId <= 0) {
            throw new BadRequestException("AccountId must be greater than 0");
        }
    }


}
