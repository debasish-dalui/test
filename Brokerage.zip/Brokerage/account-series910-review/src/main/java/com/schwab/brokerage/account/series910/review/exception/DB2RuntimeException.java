package com.schwab.brokerage.account.series910.review.exception;

public class DB2RuntimeException extends InternalServerException {
    private static final String SOURCE = "db2";

    public DB2RuntimeException(Throwable throwable) {
        super(SOURCE, throwable);
    }

    public DB2RuntimeException(String message) {
        super(SOURCE, message);
    }
}
