package com.schwab.brokerage.account.series910.review.adaptor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.schwab.brokerage.account.series910.review.connector.BrokerageCustomerConnector;
import com.schwab.brokerage.account.series910.review.constant.HeaderKeys;
import com.schwab.brokerage.account.series910.review.model.response.CustomerRestrictionResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Component
public class BrokerageCustomerAdaptor {
    private final String url;
    private final HttpHeaders brokerageCustomerServiceHeaders;
    private final ObjectMapper objectMapper;
    private final BrokerageCustomerConnector brokerageCustomerConnector;

    @Autowired
    public BrokerageCustomerAdaptor(
            @Value("${service.brokerage-customer.restrictions}") String url,
            HttpHeaders brokerageCustomerServiceHeaders,
            ObjectMapper objectMapper,
            BrokerageCustomerConnector brokerageCustomerConnector) {
        this.url = url;
        this.brokerageCustomerServiceHeaders = brokerageCustomerServiceHeaders;
        this.objectMapper = objectMapper;
        this.brokerageCustomerConnector = brokerageCustomerConnector;
    }

    public List<String> retrieveCustomerRestrictions(Integer customerId) throws IOException {
        ObjectNode objectNode = objectMapper.getNodeFactory().objectNode().put("custId", customerId.toString());
        brokerageCustomerServiceHeaders.set(HeaderKeys.CLIENT_REQUEST, objectNode.toString());

        ResponseEntity<String> responseEntity = brokerageCustomerConnector.sendRestRequest(
                url,
                HttpMethod.GET,
                brokerageCustomerServiceHeaders
        );
        CustomerRestrictionResponse response = objectMapper.readValue(
                responseEntity.getBody(),
                CustomerRestrictionResponse.class
        );
        return response.getCustomerRestrictions().stream()
                .map(customerRestriction -> customerRestriction.getShortName().trim())
                .collect(Collectors.toList());
    }
}
