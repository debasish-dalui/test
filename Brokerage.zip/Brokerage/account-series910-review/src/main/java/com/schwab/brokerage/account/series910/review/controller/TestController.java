package com.schwab.brokerage.account.series910.review.controller;


import com.schwab.brokerage.account.series910.review.adaptor.*;
import com.schwab.brokerage.account.series910.review.model.Account;
import com.schwab.brokerage.account.series910.review.model.Customer;
import com.schwab.brokerage.account.series910.review.model.request.AutoReviewPostRequest;
import com.schwab.brokerage.account.series910.review.service.AccountDataRetrievalService;
import com.schwab.brokerage.account.series910.review.service.AuthorizationService;
import com.schwab.brokerage.account.series910.review.service.CustomerDataRetrievalService;
import com.schwab.brokerage.account.series910.review.util.DBMigrator;
import com.schwab.brokerage.account.series910.review.util.DroolsEngine;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import schwab.rrbus._1_0.sch_core_enterprisesecurity_brokerageoperationsauthorizationservice.io.AccessType;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.*;

@RestController
@RequiredArgsConstructor
@RequestMapping(value = "/test")
public class TestController {
    //TODO DELETE THIS ONCE I'M DONE IMPLEMENTING THIS FEATURE

    private final CustomerDataRetrievalService customerDataRetrievalService;
    private final AccountDataRetrievalService accountDataRetrievalService;
    private final CustomerServiceAdaptor customerServiceAdaptor;
    private final AccountAddressAdaptor accountAddressAdaptor;
    private final AuthorizationService authorizationService;
    private final AccountServiceAdaptor accountServiceAdaptor;
    private final DroolsEngine droolsEngine;
    private final DBMigrator dbMigrator;



    @GetMapping(value = "/deleteAccts")
    public String asdf() {

        List<String> removeAccts = Arrays.asList(
                "1000497",
                "97486371",
                "74771489",
                "96548630",
                "30705849",
                "2112",
                "99692905",
                "95689096",
                "35431438",
                "11824613"
        );

//        removeAccts.forEach(s -> {
//            tmpMongoRepo.deleteByAccountId(Integer.valueOf(s));
//        });

        return "Accounts Removed";
    }

    @GetMapping(value = "/deleteAccts/{accountId}")
    public String asdf2(@PathVariable Integer accountId) {
//        tmpMongoRepo.deleteByAccountId(accountId);
        return "Accounts Removed";
    }


    @PostMapping(
            consumes = MediaType.APPLICATION_JSON_VALUE
    )
    public String testEndpoint(@RequestBody AutoReviewPostRequest req, HttpServletRequest httpServletRequest) throws Exception {

        Account account1 = accountServiceAdaptor.retrieveAccountDetails(req.getAccountId());
        Account a = new Account();
        a.setAccountProductCode(account1.getAccountProductCode());
//        a.setAcctRegistrationTypeCode(account1.getAcctRegistrationTypeCode());
//        a.setAccountProductCode();

        StringBuilder msg = new StringBuilder("Account Info: \n");
        msg.append("Product Code: " + a.getAccountProductCode() + "\n\n");


        msg.append("Roles & Customers\n");


        a.setAccountId(req.getAccountId());
        customerDataRetrievalService.service(a);
        Set<Customer> custs;
        for (String role : a.getRoles()) {
            custs = a.getCustomersByRole(role);
            msg.append(role + ": [");
            for (Customer c : custs) {
                msg.append(c.getCustomerId() + ",");
            }
            msg.deleteCharAt(msg.length() - 1);
            msg.append("]\n");
        }
        msg.append("\nCustomer Details: (size: " + a.getCustomers().size() + ")\n");
        Set<Customer> cust = a.getCustomers();
        for (Customer c : cust) {
            msg.append(c.toString() + "\n");
        }
        msg.append("\nFULL ACCOUNT:  "+a.toString().replace(", ",",\t\n"));
        return msg.toString();
    }

    @GetMapping
    public String testCustService(@RequestHeader Integer accountId) throws Exception {
        Account a = Account.builder().accountId(accountId).build();
        a.setCountryCode(accountAddressAdaptor.getCountryCode(a.getAccountId()));
        return a.toString();
    }

    @Autowired
    private final RetailCustomerProfileAdaptor retailCustomerProfileAdaptor;

    @GetMapping("/retailcustomer/{customerId}")
    public ResponseEntity testRetailCustomer(@PathVariable Set<Integer> customerId) {
        return ResponseEntity.ok(accountDataRetrievalService.service(customerId));
    }


    @GetMapping(value = "/auth")
    public String auth(HttpServletRequest httpServletRequest, @RequestHeader String type, @RequestHeader Integer accountId) throws Exception {
        AccessType accessType = AccessType.valueOf(type);

        authorizationService.service(accountId, accessType);
        return "SUCCESS";
    }

    @Autowired
    private BrokerageCustomerAdaptor brokerageCustomerAdaptor;

    @GetMapping(value = "/restriction/{customerId}")
    public ResponseEntity restriction(@PathVariable Integer customerId) throws
            IOException {
        return ResponseEntity.ok(brokerageCustomerAdaptor.retrieveCustomerRestrictions(customerId));
    }

    @GetMapping(value = "/acct-restrictions")
    public Set<String> restrictions(@RequestHeader Integer accountId) throws Exception {
        return accountServiceAdaptor.retrieveAccountRestrictions(accountId);
    }

    @GetMapping(value = "/migrate")
    public String doMigrate() throws Exception {
        return dbMigrator.migrate();
    }


//    @Autowired
//    Auto
//
//    @GetMapping(value = "/rules")
//    public Series910Response rules() throws Exception {
//        Account account = Account.builder()
//                .accountProductCode("IRA")
//                .accountRegistrationCode("CO")
//                .build();
//        ArrayList<Citizenship> citizenship = new ArrayList<>();
//        citizenship.add(Citizenship.builder().countryOfCitizenship("GE").build());
//        citizenship.add(Citizenship.builder().countryOfCitizenship("US").build());
//        Customer customer = Customer.builder()
//                .customerId(12345)
//                .citizenships(citizenship)
//                .countryOfResidence("US")
//                .dateOfBirth(LocalDate.of(1988, 1, 4))
//                .build();
//        account.addCustomer(customer, "IND");
//
//        return autoreview.service(account);
//    }


//    @GetMapping(value = "/rules2")
//    public Series910Response rules2() throws Exception {
//        Account account = Account.builder()
//                .accountProductCode("IRA")
//                .accountRegistrationCode("CO")
//                .build();
//        ArrayList<Citizenship> citizenship = new ArrayList<>();
//        citizenship.add(Citizenship.builder().countryOfCitizenship("US").build());
//        Customer customer1 = Customer.builder()
//                .individual407TypeCode("No")
//                .customerTypeCode("IND")
//                .customerId(1)
//                .taxPayerId("1")
//                .citizenships(citizenship)
//                .countryOfResidence("US")
//                .dateOfBirth(LocalDate.of(2008, 1, 4))
//                .build();
//        account.addCustomer(customer1, "CUST");
//
//        ArrayList<Citizenship> citizenship2 = new ArrayList<>();
//        citizenship2.add(Citizenship.builder().countryOfCitizenship("GE").build());
//        Customer customer2 = Customer.builder()
//                .individual407TypeCode("No")
//                .customerTypeCode("IND")
//                .customerId(2)
//                .taxPayerId("2")
//                .citizenships(citizenship2)
//                .countryOfResidence("US")
//                .dateOfBirth(LocalDate.of(1988, 1, 4))
//                .build();
//        account.addCustomer(customer2, "IND");
//
//        ArrayList<Citizenship> citizenship3 = new ArrayList<>();
//        citizenship.add(Citizenship.builder().countryOfCitizenship("US").build());
//        Customer customer3 = Customer.builder()
//                .individual407TypeCode("No")
//                .customerTypeCode("IND")
//                .customerId(3)
//                .taxPayerId("3")
//                .citizenships(citizenship)
//                .countryOfResidence("GE")
//                .dateOfBirth(LocalDate.of(1988, 1, 4))
//                .build();
//        account.addCustomer(customer3, "IND");
//
//        ArrayList<Citizenship> citizenship4 = new ArrayList<>();
//        citizenship.add(Citizenship.builder().countryOfCitizenship("US").build());
//        Customer customer4 = Customer.builder()
//                .individual407TypeCode("No")
//                .customerTypeCode("IND")
//                .customerId(4)
//                .taxPayerId("4")
//                .citizenships(citizenship)
//                .countryOfResidence("US")
//                .dateOfBirth(LocalDate.of(1888, 1, 4))
//                .build();
//        account.addCustomer(customer4, "IND");
//
//        ArrayList<Citizenship> citizenship5 = new ArrayList<>();
//        citizenship.add(Citizenship.builder().countryOfCitizenship("US").build());
//        Customer customer5 = Customer.builder()
//                .individual407TypeCode("No")
//                .customerTypeCode("ORG")
//                .customerId(5)
//                .taxPayerId("5")
//                .citizenships(citizenship)
//                .countryOfResidence("US")
//                .dateOfBirth(LocalDate.of(1988, 1, 4))
//                .build();
//        account.addCustomer(customer5, "IND");
//
//        ArrayList<Citizenship> citizenship6 = new ArrayList<>();
//        citizenship.add(Citizenship.builder().countryOfCitizenship("US").build());
//        Customer customer6 = Customer.builder()
//                .individual407TypeCode("No")
//                .customerTypeCode("IND")
//                .customerId(6)
//                .taxPayerId("6")
//                .citizenships(citizenship)
//                .countryOfResidence("US")
//                .dateOfBirth(LocalDate.of(1988, 1, 4))
//                .build();
//        account.addCustomer(customer6, "MINOR");
//
//        ArrayList<Citizenship> citizenship7 = new ArrayList<>();
//        citizenship.add(Citizenship.builder().countryOfCitizenship("US").build());
//        Customer customer7 = Customer.builder()
//                .individual407TypeCode("Y")
//                .customerTypeCode("IND")
//                .customerId(7)
//                .taxPayerId("7")
//                .citizenships(citizenship)
//                .countryOfResidence("US")
//                .dateOfBirth(LocalDate.of(1988, 1, 4))
//                .build();
//        account.addCustomer(customer7, "IND");
//
//        ArrayList<Citizenship> citizenship8 = new ArrayList<>();
//        citizenship.add(Citizenship.builder().countryOfCitizenship("US").build());
//        ArrayList<String> restrictions8 = new ArrayList<>();
//        restrictions8.add("PAV CLOSED");
//        Customer customer8 = Customer.builder()
//                .individual407TypeCode("No")
//                .customerTypeCode("IND")
//                .customerId(8)
//                .taxPayerId("8")
//                .citizenships(citizenship)
//                .countryOfResidence("US")
//                .restrictions(restrictions8)
//                .dateOfBirth(LocalDate.of(1988, 1, 4))
//                .build();
//        account.addCustomer(customer8, "IND");
//
//        return series910RulesService.service(account);
//    }

    @PostMapping(value = "/getCustIds")
    public List<String> getCustIDendpoint(@RequestBody String taxPayerId) throws Exception{
       List<String> al = customerServiceAdaptor.retrieveCustomerIds(taxPayerId);

       return al;
    }
}
