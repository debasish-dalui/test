package com.schwab.brokerage.account.series910.review;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableCaching
@EnableDiscoveryClient
@ComponentScan({
        "com.schwab.brokerage.account.series910.*",
        "com.schwab.common.loggingcontroller",
        "com.schwab.common.loggingservice",
        "com.schwab.common.loggingrepository",
        "com.schwab.common.utility",
        "com.schwab.common.filter",
        "com.schwab.common.logging",
        "com.schwab.common.model,com.schwab.common.filter",
        "com.schwab.boa.*",
        "com.schwab.cat.party.fct.*",
        "com.schwab.token.helper"
})
public class AccountSeries910ReviewApplication {
    public static void main(String[] args) {
        SpringApplication.run(AccountSeries910ReviewApplication.class, args);
    }
}
