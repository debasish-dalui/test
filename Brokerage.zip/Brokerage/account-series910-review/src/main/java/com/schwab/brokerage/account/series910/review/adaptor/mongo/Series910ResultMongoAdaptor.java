package com.schwab.brokerage.account.series910.review.adaptor.mongo;

import com.schwab.brokerage.account.series910.review.adaptor.Series910ResultAdaptor;
import com.schwab.brokerage.account.series910.review.adaptor.converter.ResponseConverter;
import com.schwab.brokerage.account.series910.review.adaptor.converter.Series910FailMongoConverter;
import com.schwab.brokerage.account.series910.review.dto.mongo.Series910ResultMongo;
import com.schwab.brokerage.account.series910.review.model.response.Series910Result;
import com.schwab.brokerage.account.series910.review.repository.Series910ResultMongoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("mongo.autoReviewResult")
@SuppressWarnings("unused")
public class Series910ResultMongoAdaptor
        implements Series910ResultAdaptor, ResponseConverter<Series910ResultMongo, Series910Result> {
    private final Series910ResultMongoRepository series910ResultMongoRepository;
    private final Series910FailMongoConverter series910FailMongoAdaptor;
    private final Sort series910ResultSortMongo;

    @Autowired
    public Series910ResultMongoAdaptor(
            Series910ResultMongoRepository series910ResultMongoRepository,
            Series910FailMongoConverter series910FailMongoAdaptor,
            Sort series910ResultSortMongo) {
        this.series910ResultMongoRepository = series910ResultMongoRepository;
        this.series910FailMongoAdaptor = series910FailMongoAdaptor;
        this.series910ResultSortMongo = series910ResultSortMongo;
    }

    @Override
    public List<Series910Result> retrieve(Integer accountId) {
        List<Series910ResultMongo> autoReviewResults = series910ResultMongoRepository.findByAccountId(
                series910ResultSortMongo,
                accountId
        );
        return toResponses(autoReviewResults);
    }

    @Override
    public Series910Result toResponse(Series910ResultMongo autoReviewResult) {
        return Series910Result.builder()
                .reviewTimestamp(autoReviewResult.getAudit().getCreationDate())
                .channelName(autoReviewResult.getChannelName())
                .passFailCode(autoReviewResult.getPassFailCode())
                .triggerEventCode(autoReviewResult.getTriggerEventCode())
                .auditUpdateUserId(autoReviewResult.getAudit().getLastUpdatedBy())
                .auditUpdateTimestamp(autoReviewResult.getAudit().getLastUpdateTimestamp())
                .failReasons(series910FailMongoAdaptor.toResponses(autoReviewResult.getFailReasons()))
                .build();
    }
}
