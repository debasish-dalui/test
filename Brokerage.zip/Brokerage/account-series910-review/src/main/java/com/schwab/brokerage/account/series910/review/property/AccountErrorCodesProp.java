package com.schwab.brokerage.account.series910.review.property;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Configuration
@ConfigurationProperties
@SuppressWarnings("unused")
public class AccountErrorCodesProp {
    private Map<Integer, String> accountErrorCodes;

    @Bean
    Map<Integer, String> accountErrorCodes() {
        return accountErrorCodes;
    }
}
