package com.schwab.brokerage.account.series910.review.connector;

import com.schwab.brokerage.account.series910.review.exception.RestRuntimeException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class BrokerageCustomerConnector {
    private final RestTemplate restTemplate;

    @Autowired
    public BrokerageCustomerConnector(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public ResponseEntity<String> sendRestRequest(String url, HttpMethod httpMethod, HttpHeaders headers) {
        try {
            HttpEntity<String> restRequest = new HttpEntity<>(headers);
            return restTemplate.exchange(url, httpMethod, restRequest, String.class);
        } catch (Exception e) {
            throw new RestRuntimeException(e);
        }
    }

}
