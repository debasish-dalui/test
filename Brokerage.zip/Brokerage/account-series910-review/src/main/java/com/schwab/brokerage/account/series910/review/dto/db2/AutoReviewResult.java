package com.schwab.brokerage.account.series910.review.dto.db2;

import com.schwab.brokerage.account.series910.review.dto.db2.constraint.AutoReviewResultKey;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "AUTO_REVU_RESULT", schema = "SAMS")
public class AutoReviewResult {

    @EmbeddedId
    private AutoReviewResultKey primaryKey;

    @Column(name = "TRGR_EVENT_CD")
    private String triggerEventCode;

    @Column(name = "SRVC_PORTAL_CD")
    private String servicePortalCode;

    @Column(name = "ENTERPRISE_NM")
    private String enterpriseName;

    @Column(name = "VERSION_ID")
    private Integer versionId;

    @Column(name = "CHANNEL_NM")
    private String channelName;

    @Column(name = "PASS_FAIL_CD")
    private String passFailCode;

    @Column(name = "AUDIT_UPDT_USER_ID")
    private String auditUpdateUserId;

    @Column(name = "AUDIT_UPDT_TS")
    private Timestamp auditUpdateTimestamp;

    @OneToMany(mappedBy = "autoReviewResult", fetch = FetchType.EAGER)
    private List<AutoReviewFail> autoReviewFails;
}
