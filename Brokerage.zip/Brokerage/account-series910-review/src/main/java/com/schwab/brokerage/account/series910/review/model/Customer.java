package com.schwab.brokerage.account.series910.review.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.time.LocalDate;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode(of = "customerId")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Customer {
    @JsonProperty("custId")
    private Integer customerId;
    private String taxPayerId;
    private String countryOfResidence;
    @JsonProperty("custTypeCd")
    private String customerTypeCode;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private LocalDate dateOfBirth;
    private List<Citizenship> citizenships;
    private String individual407TypeCode;
    private List<String> restrictions;
}
