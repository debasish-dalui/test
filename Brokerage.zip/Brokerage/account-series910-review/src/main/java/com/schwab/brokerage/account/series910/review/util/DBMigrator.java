package com.schwab.brokerage.account.series910.review.util;

import com.schwab.brokerage.account.series910.review.adaptor.converter.Series910FailDb2Converter;
import com.schwab.brokerage.account.series910.review.adaptor.converter.Series910FailMongoConverter;
import com.schwab.brokerage.account.series910.review.dto.db2.AutoReviewResult;
import com.schwab.brokerage.account.series910.review.dto.mongo.Series910Audit;
import com.schwab.brokerage.account.series910.review.dto.mongo.Series910FailMongo;
import com.schwab.brokerage.account.series910.review.dto.mongo.Series910ResultMongo;
import com.schwab.brokerage.account.series910.review.repository.Series910ResultDb2Repository;
import com.schwab.brokerage.account.series910.review.repository.Series910ResultMongoRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;

import static org.apache.commons.lang.StringUtils.trimToEmpty;

@Slf4j
@Component
public class DBMigrator {

    private final Series910ResultDb2Repository db2Repo;
    private final Series910ResultMongoRepository mongoRepo;
    private final Series910FailMongoConverter series910FailMongoAdaptor;
    private final Series910FailDb2Converter series910FailDb2Converter;

    private final Integer schemaVersion;

    @Autowired
    public DBMigrator(Series910ResultDb2Repository db2Repo,
                      Series910ResultMongoRepository mongoRepo,
                      Series910FailMongoConverter series910FailMongoAdaptor,
                      Series910FailDb2Converter series910FailDb2Converter,
                      @Value("${series910.schemaVersion}") Integer schemaVersion) {
        this.db2Repo = db2Repo;
        this.mongoRepo = mongoRepo;
        this.series910FailMongoAdaptor = series910FailMongoAdaptor;
        this.series910FailDb2Converter = series910FailDb2Converter;
        this.schemaVersion = schemaVersion;
    }

    public String migrate() {
        Instant before = Instant.now();
        List<AutoReviewResult> dbContents = db2Repo.findAll();
//        Page<AutoReviewResult> page = db2Repo.findAll(new PageRequest(0,50));
//        List<AutoReviewResult> dbContents = new ArrayList<>();
//        page.forEach(autoReviewResult -> dbContents.add(autoReviewResult));
        dbContents.stream()
                .filter(this::canMigrate)
                .forEach(autoReviewResult -> {
                    try {
                        Series910ResultMongo mongoDto = convertDto(autoReviewResult);
                        mongoRepo.insert(mongoDto);
                    } catch (Exception e) {
                        log.warn("Error saving Account number: " + autoReviewResult.getPrimaryKey().getAccountId(), e);
                    }
                });
        Instant after = Instant.now();
        log.warn("Migration completed, process took " + Duration.between(before, after).toMinutes() + " minutes.");
        return "SUCCESS";
    }

    private Series910ResultMongo convertDto(AutoReviewResult autoReviewResult) {
        log.warn("Converting DTO");
        Series910Audit audit = Series910Audit.builder()
                .createdBy(autoReviewResult.getAuditUpdateUserId())
                .creationDate(autoReviewResult.getPrimaryKey().getReviewDate()
                        .toLocalDate().atTime(
                                autoReviewResult.getPrimaryKey().getReviewTime().toLocalTime()
                        )
                )
                .lastUpdatedBy(autoReviewResult.getAuditUpdateUserId())
                .lastUpdateTimestamp(autoReviewResult.getAuditUpdateTimestamp().toLocalDateTime())
                .version(autoReviewResult.getVersionId())
                .schemaVersion(schemaVersion)
                .build();

        List<Series910FailMongo> failReasons = autoReviewResult.getAutoReviewFails().stream()
                .map(series910FailDb2Converter::toResponse)
                .map(series910FailMongoAdaptor::toModel)
                .collect(Collectors.toList());

        return Series910ResultMongo.builder()
                .accountId(autoReviewResult.getPrimaryKey().getAccountId())
                .triggerEventCode(trimToEmpty(autoReviewResult.getTriggerEventCode()))
                .channelName(trimToEmpty(autoReviewResult.getChannelName()))
                .passFailCode(trimToEmpty(autoReviewResult.getPassFailCode()))
                .failReasons(failReasons)
                .audit(audit)
                .build();
    }

    private boolean canMigrate(AutoReviewResult autoReviewResult) {
//        log.warn("Beginning filter process");
        return true;
    }
}
