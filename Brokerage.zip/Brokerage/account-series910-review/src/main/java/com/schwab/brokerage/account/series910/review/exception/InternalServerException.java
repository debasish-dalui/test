package com.schwab.brokerage.account.series910.review.exception;

import com.schwab.brokerage.account.series910.review.model.response.ReturnDetails;

public class InternalServerException extends ReturnDetailsException {
    public InternalServerException() {
        super();
    }

    public InternalServerException(Throwable cause) {
        super(cause);
    }

    public InternalServerException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    public InternalServerException(ReturnDetails returnDetails) {
        super(returnDetails);
    }

    public InternalServerException(ReturnDetails returnDetails, String message) {
        super(returnDetails, message);
    }

    public InternalServerException(ReturnDetails returnDetails, String message, Throwable cause) {
        super(returnDetails, message, cause);
    }

    public InternalServerException(ReturnDetails returnDetails, Throwable cause) {
        super(returnDetails, cause);
    }

    public InternalServerException(ReturnDetails returnDetails, String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(returnDetails, message, cause, enableSuppression, writableStackTrace);
    }

    public InternalServerException(String source) {
        super();
        getReturnDetails().setSource(source);
    }

    public InternalServerException(String source, String message) {
        super(message);
        getReturnDetails().setSource(source);
    }

    public InternalServerException(String source, String message, Throwable cause) {
        super(message, cause);
        getReturnDetails().setSource(source);
    }

    public InternalServerException(String source, Throwable cause) {
        super(cause);
        getReturnDetails().setSource(source);
    }

    public InternalServerException(String source, String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
        getReturnDetails().setSource(source);
    }

    @Override
    protected ReturnDetails getDefaultReturnDetails() {
        return ReturnDetails.builder().returnCode(500).build();
    }


}
