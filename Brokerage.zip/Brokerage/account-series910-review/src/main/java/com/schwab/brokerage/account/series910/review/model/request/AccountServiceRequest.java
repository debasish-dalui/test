package com.schwab.brokerage.account.series910.review.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@NoArgsConstructor
@Builder
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class AccountServiceRequest implements GenericRequest {
    @JsonProperty("AcctID")
    private Integer accountId;
}


