package com.schwab.brokerage.account.series910.review.interceptor;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

@Slf4j
@Component
public class RestSecurityInterceptor implements ClientHttpRequestInterceptor {
    private final HttpServletRequest incomingRequest;

    @Autowired
    public RestSecurityInterceptor(HttpServletRequest incomingRequest) {
        this.incomingRequest = incomingRequest;
    }

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
            throws IOException {
        log.info("Outbound REST Request [" + request.getMethod() + "] " + request.getURI());

        request.getHeaders().set(
                HttpHeaders.AUTHORIZATION,
                incomingRequest.getHeader(HttpHeaders.AUTHORIZATION)
        );
        return execution.execute(request, body);
    }
}
