package com.schwab.brokerage.account.series910.review.advice;


import com.schwab.brokerage.account.series910.review.exception.BadRequestException;
import com.schwab.brokerage.account.series910.review.exception.InternalServerException;
import com.schwab.brokerage.account.series910.review.exception.NotAuthorizedException;
import com.schwab.brokerage.account.series910.review.exception.ReturnDetailsException;
import com.schwab.brokerage.account.series910.review.model.response.ReturnDetails;
import com.schwab.brokerage.account.series910.review.model.response.Series910Response;
import com.schwab.brokerage.account.series910.review.property.AccountErrorCodesProp;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Collections;

@Slf4j
@RestControllerAdvice
@SuppressWarnings("unused")
public class GlobalExceptionHandler {
    private final AccountErrorCodesProp accountErrorCodesProp;
    private final String messageSource;

    @Autowired
    public GlobalExceptionHandler(
            AccountErrorCodesProp accountErrorCodesProp,
            @Value("${message.source}") String messageSource
    ) {
        this.accountErrorCodesProp = accountErrorCodesProp;
        this.messageSource = messageSource;
    }

    @ExceptionHandler({NotAuthorizedException.class})
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public Series910Response httpMessageNotReadableException(NotAuthorizedException e) {
        log.error(messageSource + ": authorization error: " + e.getMessage(), e);

        return Series910Response.builder()
                .returnDetails(Collections.singletonList(ReturnDetails.builder()
                        .returnCode(e.getReturnCode())
                        .returnMessage(e.getMessage())
                        .build()))
                .build();
    }

    @ExceptionHandler({Exception.class})
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public Series910Response catchAllOtherExceptions(Exception e) {
        log.error(messageSource + ": an error occurred: " + e.getMessage(), e);

        return Series910Response.builder()
                .returnDetails(Collections.singletonList(
                        ReturnDetails.builder()
                                .returnCode(500)
                                .returnMessage("Internal Server Error: " + e.getMessage())
                                .build())
                )
                .build();
    }

    @ExceptionHandler({HttpMessageNotReadableException.class, IllegalArgumentException.class, NumberFormatException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Series910Response httpMessageNotReadableException(Exception e) {
        log.error(messageSource + ": invalid input was given" + e.getMessage(), e);
        return Series910Response.builder()
                .returnDetails(Collections.singletonList(
                        ReturnDetails.builder()
                                .returnCode(400)
                                .returnMessage("Invalid Request: " + e.getMessage())
                                .build())
                )
                .build();
    }


    @ExceptionHandler({BadRequestException.class})
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Series910Response badRequestExceptionHandler(BadRequestException badRequestException) {
        return errorResponse(badRequestException);
    }

    @ExceptionHandler({InternalServerException.class})
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public Series910Response internalServerExceptionHandler(InternalServerException internalServerException) {
        return errorResponse(internalServerException);
    }

    private Series910Response errorResponse(ReturnDetailsException returnDetailsException) {
        if (!accountErrorCodesProp.getAccountErrorCodes().containsKey(returnDetailsException.getReturnDetails().getReturnCode())) {
            log.warn("There is no returnMessage associated with the returnCode. " + returnDetailsException.getReturnDetails());
        }
        String returnMessage = StringUtils.trimToEmpty(
                accountErrorCodesProp.getAccountErrorCodes().getOrDefault(returnDetailsException.getReturnDetails().getReturnCode(), "")
                        + " " + StringUtils.trimToEmpty(returnDetailsException.getMessage())
        );

        log.error(StringUtils.defaultString(returnDetailsException.getReturnDetails().getSource(), messageSource) + returnMessage, returnDetailsException);

        return Series910Response.builder()
                .returnDetails(Collections.singletonList(
                        ReturnDetails.builder()
                                .returnCode(returnDetailsException.getReturnDetails().getReturnCode())
                                .returnMessage(returnMessage)
                                .source(returnDetailsException.getReturnDetails().getSource())
                                .build())
                )
                .build();
    }
}
