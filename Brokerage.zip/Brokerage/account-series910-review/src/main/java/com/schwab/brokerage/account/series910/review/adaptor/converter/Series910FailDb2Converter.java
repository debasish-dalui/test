package com.schwab.brokerage.account.series910.review.adaptor.converter;

import com.schwab.brokerage.account.series910.review.model.FailReason;
import com.schwab.brokerage.account.series910.review.dto.db2.AutoReviewFail;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

@Component
public class Series910FailDb2Converter implements ResponseConverter<AutoReviewFail, FailReason> {
    @Override
    public FailReason toResponse(AutoReviewFail autoReviewFail) {
        return FailReason.builder()
                .failReasonCode(StringUtils.trimToEmpty(autoReviewFail.getPrimaryKey().getResultCode()))
                .failReasonText(StringUtils.trimToEmpty(autoReviewFail.getResultText()))
                .build();
    }
}
