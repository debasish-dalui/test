package com.schwab.brokerage.account.series910.review.exception;

public class DB2NonZeroException extends BadRequestException {
    public DB2NonZeroException(String message) {
        super(message);
    }
}
