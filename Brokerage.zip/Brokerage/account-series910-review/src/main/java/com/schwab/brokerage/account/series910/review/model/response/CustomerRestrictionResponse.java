package com.schwab.brokerage.account.series910.review.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.schwab.brokerage.account.series910.review.model.CustomerRestriction;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerRestrictionResponse {
    @JsonProperty("custId")
    private Integer customerId;
    private List<CustomerRestriction> customerRestrictions;
}
