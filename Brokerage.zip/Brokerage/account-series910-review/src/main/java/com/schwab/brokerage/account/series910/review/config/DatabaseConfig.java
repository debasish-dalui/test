package com.schwab.brokerage.account.series910.review.config;

import com.mongodb.MongoClientURI;
import com.schwab.brokerage.account.series910.review.adaptor.Series910ResultAdaptor;
import com.schwab.brokerage.account.series910.review.adaptor.DatabaseAdaptor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;

import java.net.UnknownHostException;

@Slf4j
@Configuration
@RefreshScope
@SuppressWarnings("unused")
public class DatabaseConfig {
    private final ApplicationContext applicationContext;

    public DatabaseConfig(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    @Bean
    @Primary
    @RefreshScope
    public Series910ResultAdaptor autoReviewResultAdaptor(
            @Value("${series910.database:mongo}.autoReviewResult") String adaptor
    ) {
        return (Series910ResultAdaptor) applicationContext.getBean(adaptor);
    }

    @Bean
    @Primary
    @RefreshScope
    public DatabaseAdaptor databaseAdaptor(
            @Value("${series910.database:mongo}.adaptor") String adaptor
    ) {
        return (DatabaseAdaptor) applicationContext.getBean(adaptor);
    }

    @Bean
    @RefreshScope
    public MongoClientURI mongoClientURI(@Value("${spring.data.mongodb.uri}") String uri) {
        return new MongoClientURI(uri);
    }

    @Bean
    @RefreshScope
    public MongoDbFactory mongoDbFactory(MongoClientURI mongoClientURI) throws UnknownHostException {
        return new SimpleMongoDbFactory(mongoClientURI);
    }

    @Bean
    @RefreshScope
    public MongoTemplate mongoTemplate(MongoDbFactory mongoDbFactory) {
        return new MongoTemplate(mongoDbFactory);
    }

    @Bean
    public Sort autoReviewResultSort() {
        return new Sort(Sort.Direction.DESC, "primaryKey.reviewDate", "primaryKey.reviewTime");
    }

    @Bean
    public Sort series910ResultSortMongo() {
        return new Sort(Sort.Direction.DESC, "_audit.createDt");
    }
}
