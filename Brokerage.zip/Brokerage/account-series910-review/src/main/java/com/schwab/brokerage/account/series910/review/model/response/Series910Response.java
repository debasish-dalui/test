package com.schwab.brokerage.account.series910.review.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import lombok.Builder;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
@Builder
@ApiModel(description = "Returns a list of results.")
public class Series910Response {
    @JsonProperty("results")
    private List<Series910Result> series910Results;
    @Builder.Default
    private List<ReturnDetails> returnDetails = new ArrayList<>();
}
