package com.schwab.brokerage.account.series910.review.exception;

public class ManualValidationAlreadyRunException extends BadRequestException {

    public ManualValidationAlreadyRunException() {
        super(11007);
    }

}
