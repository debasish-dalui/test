package com.schwab.brokerage.account.series910.review.adaptor.db2;

import com.schwab.brokerage.account.series910.review.adaptor.Series910ResultAdaptor;
import com.schwab.brokerage.account.series910.review.adaptor.converter.ResponseConverter;
import com.schwab.brokerage.account.series910.review.adaptor.converter.Series910FailDb2Converter;
import com.schwab.brokerage.account.series910.review.dto.db2.AutoReviewResult;
import com.schwab.brokerage.account.series910.review.model.response.Series910Result;
import com.schwab.brokerage.account.series910.review.repository.Series910ResultDb2Repository;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Component;

import java.util.List;

@Component("db2.autoReviewResult")
public class Series910ResultDb2Adaptor
        implements Series910ResultAdaptor, ResponseConverter<AutoReviewResult, Series910Result> {
    private final Series910ResultDb2Repository series910ResultDb2Repository;
    private final Series910FailDb2Converter series910FailDb2Converter;
    private final Sort autoReviewResultSort;

    @Autowired
    public Series910ResultDb2Adaptor(
            Series910ResultDb2Repository series910ResultDb2Repository,
            Series910FailDb2Converter series910FailDb2Converter,
            Sort autoReviewResultSort) {
        this.series910ResultDb2Repository = series910ResultDb2Repository;
        this.series910FailDb2Converter = series910FailDb2Converter;
        this.autoReviewResultSort = autoReviewResultSort;
    }

    @Override
    public List<Series910Result> retrieve(Integer accountId) {
        List<AutoReviewResult> autoReviewResults = series910ResultDb2Repository.findByPrimaryKeyAccountId(
                autoReviewResultSort,
                accountId
        );
        return toResponses(autoReviewResults);
    }

    @Override
    public Series910Result toResponse(AutoReviewResult autoReviewResult) {
        return Series910Result.builder()
                .reviewTimestamp(autoReviewResult.getPrimaryKey().getReviewTime().toLocalTime()
                        .atDate(autoReviewResult.getPrimaryKey().getReviewDate().toLocalDate()))
                .channelName(StringUtils.trimToEmpty(autoReviewResult.getChannelName()))
                .passFailCode(StringUtils.trimToEmpty(autoReviewResult.getPassFailCode()))
                .triggerEventCode(StringUtils.trimToEmpty(autoReviewResult.getTriggerEventCode()))
                .auditUpdateUserId(StringUtils.trimToEmpty(autoReviewResult.getAuditUpdateUserId()))
                .auditUpdateTimestamp(autoReviewResult.getAuditUpdateTimestamp().toLocalDateTime())
                .failReasons(series910FailDb2Converter.toResponses(autoReviewResult.getAutoReviewFails()))
                .build();
    }

}
