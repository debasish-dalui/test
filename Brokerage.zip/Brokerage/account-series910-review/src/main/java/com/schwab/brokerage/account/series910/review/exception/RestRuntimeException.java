package com.schwab.brokerage.account.series910.review.exception;

public class RestRuntimeException extends InternalServerException {
    public RestRuntimeException(String message) {
        super(message);
    }

    public RestRuntimeException(Throwable throwable) {
        super(throwable);
    }
}
