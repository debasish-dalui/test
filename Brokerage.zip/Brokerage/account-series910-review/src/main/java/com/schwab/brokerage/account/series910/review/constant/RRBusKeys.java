package com.schwab.brokerage.account.series910.review.constant;

public abstract class RRBusKeys {
    public static final String RRBUS_NAME = "schwab.rrbus.name";
    public static final String RRBUS_SERVICE = "schwab.rrbus.requester.service";
    public static final String RRBUS_PORT = "schwab.rrbus.requester.port";
    public static final String WSDL_SERVICE = "javax.xml.ws.wsdl.service";
}
