package com.schwab.brokerage.account.series910.review.model.request;

public interface GenericRequest {
}
