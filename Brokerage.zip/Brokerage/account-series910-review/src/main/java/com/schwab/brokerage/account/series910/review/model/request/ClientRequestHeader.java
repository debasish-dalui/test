package com.schwab.brokerage.account.series910.review.model.request;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;

import java.io.IOException;

@Data
@Component
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ClientRequestHeader {
    private final ObjectMapper objectMapper;
    private final String userIdHeader;
    private final String channelHeader;

    private String channel;
    private String userId;

    @Autowired
    public ClientRequestHeader(
            ObjectMapper objectMapper,
            @Value("${series910.headers.userId}") String userIdHeader,
            @Value("${series910.headers.channel}") String channelHeader) {
        this.objectMapper = objectMapper;
        this.userIdHeader = userIdHeader;
        this.channelHeader = channelHeader;
    }

    public void populateHeaders(String headers) throws IOException {
        ObjectNode requestHeaders = objectMapper.readValue(headers, ObjectNode.class);
        String userId = requestHeaders.get(userIdHeader).asText();
        String channelName = requestHeaders.get(channelHeader).asText();

        this.setUserId(userId);
        this.setChannel(channelName);
    }


}
