package com.schwab.brokerage.account.series910.review.adaptor.converter;

import org.apache.commons.collections.CollectionUtils;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;


public interface ModelConverter<F, T> {
    T toModel(F f);

    default List<T> toModels(List<F> fs) {
        if (CollectionUtils.isEmpty(fs)) {
            return Collections.emptyList();
        }
        return fs.stream()
                .map(this::toModel)
                .collect(Collectors.toList());
    }
}
