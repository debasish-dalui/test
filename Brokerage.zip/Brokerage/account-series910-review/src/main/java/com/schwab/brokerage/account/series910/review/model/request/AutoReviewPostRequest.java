package com.schwab.brokerage.account.series910.review.model.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.annotations.ApiModel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ApiModel(description = "Account ID in the payload.")
@JsonIgnoreProperties(ignoreUnknown = true)
public class AutoReviewPostRequest {
    private Integer accountId;
}
