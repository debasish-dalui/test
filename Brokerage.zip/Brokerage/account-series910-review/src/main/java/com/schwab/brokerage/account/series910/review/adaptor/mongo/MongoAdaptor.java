package com.schwab.brokerage.account.series910.review.adaptor.mongo;

import com.schwab.brokerage.account.series910.review.adaptor.DatabaseAdaptor;
import com.schwab.brokerage.account.series910.review.adaptor.converter.Series910FailMongoConverter;
import com.schwab.brokerage.account.series910.review.dto.mongo.Series910Audit;
import com.schwab.brokerage.account.series910.review.dto.mongo.Series910ResultMongo;
import com.schwab.brokerage.account.series910.review.model.FailReason;
import com.schwab.brokerage.account.series910.review.repository.Series910ResultMongoRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Component("mongo.adaptor")
@SuppressWarnings("unused")
public class MongoAdaptor implements DatabaseAdaptor {
    private final Integer versionId;
    private final Integer schemaVersion;
    private final Series910ResultMongoRepository series910ResultMongoRepository;
    private final Series910FailMongoConverter series910FailMongoAdaptor;

    public MongoAdaptor(@Value("${series910.versionId}") Integer versionId,
                        @Value("${series910.schemaVersion}") Integer schemaVersion,
                        Series910ResultMongoRepository series910ResultMongoRepository,
                        Series910FailMongoConverter series910FailMongoAdaptor) {
        this.versionId = versionId;
        this.schemaVersion = schemaVersion;
        this.series910ResultMongoRepository = series910ResultMongoRepository;
        this.series910FailMongoAdaptor = series910FailMongoAdaptor;
    }

    @Override
    public Map<String, Object> saveAutoReviewResult(
            Integer accountId,
            String channelName,
            String enterprise,
            String triggerEventCode,
            String reviewUserId,
            LocalDateTime reviewTimestamp,
            String passFailCode,
            LocalDateTime auditUpdateTimestamp,
            List<FailReason> autoReviewFails
    ) {
        Series910Audit audit = Series910Audit.builder()
                .createdBy(reviewUserId)
                .creationDate(reviewTimestamp)
                .lastUpdatedBy(reviewUserId)
                .lastUpdateTimestamp(auditUpdateTimestamp)
                .version(versionId)
                .schemaVersion(schemaVersion)
                .build();

        Series910ResultMongo series910ResultMongo = Series910ResultMongo.builder()
                .accountId(accountId)
                .triggerEventCode(triggerEventCode)
                .channelName(channelName)
                .passFailCode(passFailCode)
                .failReasons(series910FailMongoAdaptor.toModels(autoReviewFails))
                .audit(audit)
                .build();
        series910ResultMongoRepository.insert(series910ResultMongo);
        return null;
    }
}
