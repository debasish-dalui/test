package com.schwab.brokerage.account.series910.review.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.*;
import java.util.stream.Collectors;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Account {
    @JsonProperty("acctId")
    private Integer accountId;
    @JsonProperty("acctProductCode")
    private String accountProductCode;
    @JsonProperty("acctRgstrCode")
    private String accountRegistrationCode;
    @Builder.Default
    private String passFailCode = "FAIL";
    @Builder.Default
    private Set<FailReason> failReasons = new HashSet<>();
    private UUID correlationId;
    private String countryCode;

    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    private final Map<String, Set<Integer>> customersByRoles = new HashMap<>();
    @Getter(AccessLevel.NONE)
    @Setter(AccessLevel.NONE)
    private final Map<Integer, Customer> customers = new HashMap<>();
    private Set<String> accountRestrictions;

    public void addCustomer(Customer customer, String role) {
        Integer custId = customer.getCustomerId();
        customers.put(custId, customer);
        Set<Integer> custIdsForRole = customersByRoles.get(role);
        if (custIdsForRole == null) {
            HashSet<Integer> custIdSet = new HashSet<>();
            custIdSet.add(customer.getCustomerId());
            customersByRoles.put(role, custIdSet);
        } else {
            custIdsForRole.add(customer.getCustomerId());
            customersByRoles.replace(role, custIdsForRole);
        }
    }

    public void addCustomer(Integer customerId, String role) {
        HashSet<Integer> custIdSet = new HashSet<>();
        custIdSet.add(customerId);
        customersByRoles.put(role, custIdSet);
    }

    public Set<Customer> getCustomersByRole(String role) {
        Set<Integer> customerIds = customersByRoles.get(role);
        Set<Customer> results = new HashSet<>();
        for (Integer custId : customerIds) {
            results.add(customers.get(custId));
        }
        return results;
    }

    public Set<Customer> getCustomers() {
        return new HashSet<>(customers.values());
    }

    public Customer getCustomerById(Integer id) {
        return customers.get(id);
    }

    public Set<String> getRoles() {
        return customersByRoles.keySet();
    }

    public Set<String> getRolesByCustomer(Customer customer) {
        return customersByRoles.entrySet().stream()
                .filter(stringSetEntry -> stringSetEntry.getValue().contains(customer.getCustomerId()))
                .map(Map.Entry::getKey)
                .collect(Collectors.toSet());
    }
}