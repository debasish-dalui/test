/*
 * Copyright (c) 2017, Charles Schwab and/or its affiliates. All rights reserved.
 */

package com.schwab.brokerage.account.series910.review.exception;

/**
 * Name:Series910RuleSetException
 * Description:
 *
 * @author jhoan.osorno
 */
public class Series910RuleSetException extends RuntimeException {

    public Series910RuleSetException(String message) {
        super(message);
    }

    public Series910RuleSetException(String message, Throwable cause) {
        super(message, cause);
    }
}
