package com.schwab.brokerage.account.series910.review.config;


import com.schwab.common.filter.LoggingFilter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;
import schwab.rrbus.provider.servlet.ProviderFilter;
import schwab.utilities.boa.service.BOAServiceRequester;

import javax.servlet.DispatcherType;
import java.util.EnumSet;

@Configuration
@SuppressWarnings("unused")
public class SecurityConfig {
    @Bean
    public FilterRegistrationBean shallowEtagHeaderFilter(
            @Value("${schwab.rrbus.service.key}") String serviceKey) {
        FilterRegistrationBean registration = new FilterRegistrationBean();
        registration.setFilter(getProviderFilter());
        registration.setDispatcherTypes(EnumSet.allOf(DispatcherType.class));
        registration.addUrlPatterns("/api/*", "/test/*");
        registration.addInitParameter("schwab.rrbus.service", serviceKey);
        registration.addInitParameter("schwab.rrbus.serviceType", "REST");
        return registration;
    }

    @Bean
    public ProviderFilter getProviderFilter() {
        return new ProviderFilter();
    }

    @Bean
    public FilterRegistrationBean filterRegistrationBean(LoggingFilter loggingFilter) {
        FilterRegistrationBean registrationBean = new FilterRegistrationBean();
        registrationBean.setFilter(loggingFilter);
        registrationBean.setOrder(2);
        return registrationBean;
    }

    @Bean(name = "bOAServiceRequester")
    public BOAServiceRequester bOAServiceRequester() {
        return new BOAServiceRequester();
    }

    @Bean
    @Profile("dev")
    public CorsFilter corsFilter() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.addAllowedOrigin("https://confluence.schwab.com");
        source.registerCorsConfiguration("/v2/api-docs", configuration);
        return new CorsFilter(source);
    }
}
