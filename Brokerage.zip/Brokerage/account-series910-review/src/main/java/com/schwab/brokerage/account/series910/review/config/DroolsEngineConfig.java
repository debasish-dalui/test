package com.schwab.brokerage.account.series910.review.config;

import lombok.extern.slf4j.Slf4j;
import org.kie.api.KieServices;
import org.kie.api.builder.ReleaseId;
import org.kie.api.runtime.KieContainer;
import org.kie.dmn.api.core.DMNModel;
import org.kie.dmn.api.core.DMNRuntime;
import org.kie.dmn.core.util.KieHelper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import java.util.UUID;

@Configuration
@Slf4j
@Profile("!bdd")
@SuppressWarnings("unused")
public class DroolsEngineConfig {

    @Bean
    public KieServices kieServices() {
        return KieServices.Factory.get();
    }

    @Bean
    public ReleaseId releaseId(
            KieServices kieServices,
            @Value("${series910.droolsEngine.groupId}") String groupId,
            @Value("${series910.droolsEngine.artifactId}") String artifactId,
            @Value("${series910.droolsEngine.version}") String version) {
        return kieServices.newReleaseId(groupId, artifactId + UUID.randomUUID(), version);
    }

    @Bean
    public DMNRuntime accountRegistrationRuntime(
            KieServices kieServices,
            ReleaseId releaseId,
            @Value("${series910.droolsEngine.accountRegistrationRule.dmnPath}") String dmnPath) {
        KieContainer kieContainer = KieHelper.getKieContainer(
                releaseId,
                kieServices.getResources().newClassPathResource(dmnPath, DroolsEngineConfig.class.getClass()));
        return kieContainer.newKieSession().getKieRuntime(DMNRuntime.class);
    }

    @Bean
    public DMNModel accountRegistrationEligibilityModel(
            DMNRuntime accountRegistrationRuntime,
            @Value("${series910.droolsEngine.namespace}") String namespace,
            @Value("${series910.droolsEngine.accountRegistrationRule.modelName}") String modelName) {
        return accountRegistrationRuntime.getModel(namespace, modelName);
    }

    @Bean
    public DMNRuntime customerEligibilityRuntime(
            KieServices kieServices,
            ReleaseId releaseId,
            @Value("${series910.droolsEngine.customerEligibilityRule.dmnPath}") String dmnPath) {
        KieContainer kieContainer = KieHelper.getKieContainer(
                releaseId,
                kieServices.getResources().newClassPathResource(dmnPath, DroolsEngineConfig.class.getClass()));
        return kieContainer.newKieSession().getKieRuntime(DMNRuntime.class);
    }

    @Bean
    public DMNModel customerEligibilityModel(
            DMNRuntime customerEligibilityRuntime,
            @Value("${series910.droolsEngine.namespace}") String namespace,
            @Value("${series910.droolsEngine.customerEligibilityRule.modelName}") String modelName) {
        return customerEligibilityRuntime.getModel(namespace, modelName);
    }

    @Bean
    public DMNRuntime mailingAddressRuntime(
            KieServices kieServices,
            ReleaseId releaseId,
            @Value("${series910.droolsEngine.mailingAddressRule.dmnPath}") String dmnPath) {
        KieContainer kieContainer = KieHelper.getKieContainer(
                releaseId,
                kieServices.getResources().newClassPathResource(dmnPath, DroolsEngineConfig.class.getClass()));
        return kieContainer.newKieSession().getKieRuntime(DMNRuntime.class);
    }

    @Bean
    public DMNModel mailingAddressModel(
            DMNRuntime mailingAddressRuntime,
            @Value("${series910.droolsEngine.namespace}") String namespace,
            @Value("${series910.droolsEngine.mailingAddressRule.modelName}") String modelName) {
        return mailingAddressRuntime.getModel(namespace, modelName);
    }


}
