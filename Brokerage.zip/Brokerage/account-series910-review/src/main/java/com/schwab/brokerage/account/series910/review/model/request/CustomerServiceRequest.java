package com.schwab.brokerage.account.series910.review.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.models.auth.In;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class CustomerServiceRequest implements GenericRequest {
    @JsonProperty("custId")
    private Integer customerId;
}
