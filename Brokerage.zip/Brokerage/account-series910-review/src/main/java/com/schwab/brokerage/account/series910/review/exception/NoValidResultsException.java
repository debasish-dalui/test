package com.schwab.brokerage.account.series910.review.exception;

public class NoValidResultsException extends BadRequestException {
        public NoValidResultsException(String message) {
            super(11008, message);
        }
    }

