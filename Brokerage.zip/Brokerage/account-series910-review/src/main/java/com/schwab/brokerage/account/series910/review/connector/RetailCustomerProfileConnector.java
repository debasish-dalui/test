package com.schwab.brokerage.account.series910.review.connector;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.schwab.brokerage.account.series910.review.exception.external.RetailCustomerProfileException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import schwab.rrbus._1_0.sch_core_customeraccount_retailcustomerprofileservice.RetailCustomerProfileInterface;
import schwab.rrbus._1_0.sch_core_customeraccount_retailcustomerprofileservice.RetailCustomerProfileService;
import schwab.rrbus._1_0.sch_core_customeraccount_retailcustomerprofileservice.io.GetCustRetailLoginDataReply;
import schwab.rrbus._1_0.sch_core_customeraccount_retailcustomerprofileservice.io.GetCustRetailLoginDataRequest;
import schwab.rrbus.requester.ApplicationContext;
import schwab.rrbus.requester.ServiceContext;
import schwab.rrbus.requester.SessionContext;

import javax.naming.Context;
import javax.naming.InitialContext;

@Slf4j
@Component
public class RetailCustomerProfileConnector {
    private final ObjectMapper objectMapper;

    @Autowired
    public RetailCustomerProfileConnector(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public GetCustRetailLoginDataReply custRetailLoginData(
            GetCustRetailLoginDataRequest custRetailLoginDataRequest
    ) {
        GetCustRetailLoginDataReply custRetailLoginDataReply;

        try {
            log.info("*************validateUSAddressRequest:" + objectMapper.writeValueAsString(custRetailLoginDataRequest));

            ApplicationContext applicationContext = ServiceContext.getApplicationContext();
            SessionContext sessionContext = ServiceContext.getSessionContext();

            ServiceContext.init(sessionContext, applicationContext);

            Context context = new InitialContext();
            RetailCustomerProfileService service = (RetailCustomerProfileService) context
                    .lookup("rrbus:retailcustomercrofileservice/GetCustRetailLoginData");
            RetailCustomerProfileInterface retailCustomerProfileInterface = service.getRetailCustomerProfileBusPort();
            custRetailLoginDataReply = retailCustomerProfileInterface.getCustRetailLoginData(custRetailLoginDataRequest);


            if (custRetailLoginDataReply.getReturnCode() != 0 &&
                    StringUtils.hasText(custRetailLoginDataReply.getReturnMessage())) {
                throw new RetailCustomerProfileException(custRetailLoginDataReply.getReturnMessage());
            }

        } catch (RetailCustomerProfileException rcp) {
            throw rcp;
        } catch (Exception e) {
            throw new RetailCustomerProfileException(e);
        }

        return custRetailLoginDataReply;
    }
}
