package com.schwab.brokerage.account.series910.review.exception;

public class ValidationAlreadyRunException extends BadRequestException {

    public ValidationAlreadyRunException() {
        super(11001);
    }
}
