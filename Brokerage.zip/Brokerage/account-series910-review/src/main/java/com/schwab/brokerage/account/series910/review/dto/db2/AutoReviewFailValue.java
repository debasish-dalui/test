package com.schwab.brokerage.account.series910.review.dto.db2;

import com.schwab.brokerage.account.series910.review.dto.db2.constraint.AutoReviewFailValueKey;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "AUTO_REVU_FAIL_VAL", schema = "SAMS")
public class AutoReviewFailValue {

    @EmbeddedId
    private AutoReviewFailValueKey primaryKey;

    @Column(name = "TEST_OBJ_CD")
    private Character testObjectCode;

    @Column(name = "TEST_OBJ_ID")
    private Integer testObjectId;

    @Column(name = "ELEMENT_NM", length = 35)
    private String elementName;

    @Column(name = "DATE_TYPE_CD", length = 4)
    private String dateTypeCode;

    @Column(name = "INTEGER_QY")
    private Integer integerQy;

    @Column(name = "SMALLINT_QY")
    private Short smallintQy;

    @Column(name = "DATE_DT")
    private Date date;

    @Column(name = "TIME_TM")
    private Time time;

    @Column(name = "TIMESTAMP_TS")
    private Timestamp timestamp;

    @Column(name = "CHAR_LGTH_QY", length = 3)
    private BigDecimal charLengthQy;

    @Column(name = "CHARACTER_TX")
    private String characterText;

    @Column(name = "DECIMAL_QY", length = 18)
    private BigDecimal decimalQy;

    @Column(name = "DEC_PRECISION_QY")
    private Short decimalPrecisionQy;

    @MapsId("autoReviewFailId")
    @JoinColumns({
            @JoinColumn(name = "REVU_ACCT_ID", referencedColumnName = "ACCT_ID"),
            @JoinColumn(name = "REVIEW_DT", referencedColumnName = "REVIEW_DT"),
            @JoinColumn(name = "REVIEW_TM", referencedColumnName = "REVIEW_TM"),
            @JoinColumn(name = "RESULT_CD", referencedColumnName = "RESULT_CD"),
            @JoinColumn(name = "FAIL_SEQ_ID", referencedColumnName = "FAIL_SEQ_ID")
    })
    @ManyToOne
    private AutoReviewFail autoReviewFail;
}
