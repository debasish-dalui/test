package com.schwab.brokerage.account.series910.review.config;

import com.schwab.brokerage.account.series910.review.constant.RRBusKeys;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import schwab.rrbus.provider.JAXWSBindingHandler;
import schwab.rrbus.provider.soap.JAXWSContextHandler;
import schwab.rrbus.requester.config.SpringHandlerConfigurationProperties;
import schwab.rrbus.requester.service.internal.SpringBeanHandler;
import schwab.rrbus.requester.service.internal.SpringBeanServiceRef;

import java.util.Arrays;
import java.util.Properties;

//@Configuration
public class BoaConfig {
    @Bean("configPropsForBrokerageOperationsAuthorizationService")
    public SpringHandlerConfigurationProperties getSchwabSpringHandlerConfigurationProperties() {
        SpringHandlerConfigurationProperties configurationProperties = new SpringHandlerConfigurationProperties();
        Properties props = new Properties();
        props.setProperty(RRBusKeys.RRBUS_NAME, "jaxwsRequesterHandler");
        props.setProperty(RRBusKeys.RRBUS_SERVICE,
                "uddi:schwab.com:service:sch.core.enterpriseSecurity.BrokerageOperationsAuthorizationService");
        props.setProperty(RRBusKeys.RRBUS_PORT, "BrokerageOperationsAuthorizationBusPort");
        props.setProperty(RRBusKeys.WSDL_SERVICE,
                "{urn:schwab:rrbus:1.0:sch.core.enterprisesecurity.brokerageoperationsauthorizationservice}BrokerageOperationsAuthorizationService");
        configurationProperties.setHandlerConfigProperties(props);
        return configurationProperties;
    }

    @Bean("brokerageOperationsAuthorizationServiceBindingHandler")
    public JAXWSBindingHandler getSchwabBindingHandler(
            @Qualifier("configPropsForBrokerageOperationsAuthorizationService") SpringHandlerConfigurationProperties configurationProperties) {
        JAXWSBindingHandler bindingHandler = new JAXWSBindingHandler();
        bindingHandler.setHandlerConfigProperties(configurationProperties);
        return bindingHandler;
    }

    @Bean("springBindingHandler")
    public SpringBeanHandler getSchwabSpringBeanBindingHandler(
            @Qualifier("brokerageOperationsAuthorizationServiceBindingHandler") JAXWSBindingHandler bindingHandler) {
        SpringBeanHandler springHandler = new SpringBeanHandler();
        Properties props = new Properties();
        props.setProperty("schwab.rrbus.requester.service",
                "uddi:schwab.com:service:sch.core.enterpriseSecurity.BrokerageOperationsAuthorizationService");
        props.setProperty("schwab.rrbus.requester.port", "BrokerageOperationsAuthorizationBusPort");
        springHandler.setHandler(bindingHandler);
        springHandler.setInitParams(props);
        springHandler.setPortName("");
        return springHandler;
    }

    @Bean("brokerageOperationsAuthorizationServiceContextHandler")
    public JAXWSContextHandler getSchwabJAXWSContextHandler(
            @Qualifier("configPropsForBrokerageOperationsAuthorizationService") SpringHandlerConfigurationProperties handlerConfigProperties) {
        JAXWSContextHandler contextHandler = new JAXWSContextHandler();
        contextHandler.setHandlerConfigProperties(handlerConfigProperties);
        return contextHandler;
    }

    @Bean("springContextHandler")
    public SpringBeanHandler getSchwabSpringBeanContextHandler(
            @Qualifier("brokerageOperationsAuthorizationServiceContextHandler") JAXWSContextHandler jaxwsContextHandler) {
        SpringBeanHandler beanHandler = new SpringBeanHandler();
        Properties props = new Properties();
        beanHandler.setHandler(jaxwsContextHandler);
        beanHandler.setInitParams(props);
        beanHandler.setPortName("");
        return beanHandler;
    }

    @Bean("brokerageOperationsAuthorizationService")
    public SpringBeanServiceRef getSchwabSpringBeanServiceRef(
            @Qualifier("springContextHandler") SpringBeanHandler springContextHandler,
            @Qualifier("springBindingHandler") SpringBeanHandler springBindingHandler) {
        SpringBeanServiceRef beanServiceRef = new SpringBeanServiceRef();
        beanServiceRef.setServiceClass(
                schwab.rrbus._1_0.sch_core_enterprisesecurity_brokerageoperationsauthorizationservice.BrokerageOperationsAuthorizationService.class);
        beanServiceRef.setServiceRefName("service/boaService");
        beanServiceRef.setHandlers(Arrays.asList(springBindingHandler, springContextHandler));
        return beanServiceRef;
    }

}
