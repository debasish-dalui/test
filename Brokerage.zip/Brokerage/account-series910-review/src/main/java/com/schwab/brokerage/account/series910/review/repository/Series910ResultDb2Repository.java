package com.schwab.brokerage.account.series910.review.repository;

import com.schwab.brokerage.account.series910.review.dto.db2.AutoReviewResult;
import com.schwab.brokerage.account.series910.review.dto.db2.constraint.AutoReviewResultKey;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface Series910ResultDb2Repository
        extends JpaRepository<
        AutoReviewResult,
        AutoReviewResultKey
        > {
    List<AutoReviewResult> findByPrimaryKeyAccountId(Sort sort, Integer accountId);
    Page<AutoReviewResult> findAll(Pageable pagable);
}
