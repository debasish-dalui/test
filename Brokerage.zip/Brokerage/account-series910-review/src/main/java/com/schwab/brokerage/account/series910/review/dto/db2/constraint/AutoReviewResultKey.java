package com.schwab.brokerage.account.series910.review.dto.db2.constraint;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;
import java.sql.Date;
import java.sql.Time;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Embeddable
public class AutoReviewResultKey implements Serializable {
    @Column(name = "ACCT_ID")
    private Integer accountId;

    @Column(name = "REVIEW_DT")
    private Date reviewDate;

    @Column(name = "REVIEW_TM")
    private Time reviewTime;
}
