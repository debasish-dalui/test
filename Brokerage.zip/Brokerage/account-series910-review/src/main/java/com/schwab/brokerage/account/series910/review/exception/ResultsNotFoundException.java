package com.schwab.brokerage.account.series910.review.exception;

public class ResultsNotFoundException extends BadRequestException {
    public ResultsNotFoundException(String message) {
        super(10401, message);
    }
}
