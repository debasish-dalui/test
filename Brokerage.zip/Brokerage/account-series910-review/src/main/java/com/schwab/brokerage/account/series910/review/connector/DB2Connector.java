package com.schwab.brokerage.account.series910.review.connector;

import com.schwab.brokerage.account.series910.review.exception.DB2NonZeroException;
import com.schwab.brokerage.account.series910.review.exception.DB2RuntimeException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import java.util.Map;

@Slf4j
@Repository
public class DB2Connector {
    private final SimpleJdbcCall simpleJdbcCall;

    @Autowired
    public DB2Connector(SimpleJdbcCall simpleJdbcCall) {
        this.simpleJdbcCall = simpleJdbcCall;
    }

    public Map<String, Object> createAutoReviewResult(Map<String, Object> inputParameters) {
        Map<String, Object> db2Result;
        try {
            db2Result = simpleJdbcCall.execute(inputParameters);
            if ((Integer) db2Result.get("OUT_RETURN_CODE") != 0) {
                throw new DB2NonZeroException(db2Result.get("OUT_RETURN_MESSAGE").toString().trim());
            }
        } catch (DB2NonZeroException exception) {
            throw exception;
        } catch (Exception e) {
            throw new DB2RuntimeException(e);
        }
        return db2Result;
    }
}
