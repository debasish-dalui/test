package com.schwab.brokerage.account.series910.review.dto.db2.constraint;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Embeddable
public class AutoReviewFailKey implements Serializable {
    private AutoReviewResultKey autoReviewResultKey;

    @Column(name = "RESULT_CD", length = 3)
    private String resultCode;

    @Column(name = "FAIL_SEQ_ID")
    private Integer failSequenceId;
}
