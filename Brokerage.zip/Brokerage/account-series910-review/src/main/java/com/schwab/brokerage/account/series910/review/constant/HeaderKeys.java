package com.schwab.brokerage.account.series910.review.constant;


public abstract class HeaderKeys {
    public static final String RRBUS_SERVICE_KEY = "Schwab-RRBus-ServiceKey";
    public static final String RRBUS_PORT_TYPE = "Schwab-RRBus-PortType";
    public static final String RRBUS_PILOT_ROLLOUT = "Schwab-RRBus-PilotRollout";
    public static final String CLIENT_REQUEST = "Schwab-Client-Request";
}
