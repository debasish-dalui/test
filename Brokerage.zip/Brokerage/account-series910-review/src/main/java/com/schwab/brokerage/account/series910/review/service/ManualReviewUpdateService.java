
package com.schwab.brokerage.account.series910.review.service;

import com.schwab.brokerage.account.series910.review.adaptor.AccountServiceAdaptor;
import com.schwab.brokerage.account.series910.review.adaptor.DatabaseAdaptor;
import com.schwab.brokerage.account.series910.review.exception.ManualValidationAlreadyRunException;
import com.schwab.brokerage.account.series910.review.model.request.ClientRequestHeader;
import com.schwab.brokerage.account.series910.review.model.request.ManualPostRequest;
import com.schwab.brokerage.account.series910.review.model.response.ReturnDetails;
import com.schwab.brokerage.account.series910.review.model.response.Series910Response;
import com.schwab.brokerage.account.series910.review.model.response.Series910Result;
import com.schwab.brokerage.account.series910.review.util.FailReasonGenerator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

@Service
@Slf4j
public class ManualReviewUpdateService {
    private final DatabaseAdaptor databaseAdaptor;
    private final ResultRetrievalService resultRetrievalService;
    private final FailReasonGenerator failReasonGenerator;
    private final ClientRequestHeader clientRequestHeader;
    private AccountServiceAdaptor accountServiceAdaptor;

    @Autowired
    public ManualReviewUpdateService(
            DatabaseAdaptor databaseAdaptor,
            ResultRetrievalService resultRetrievalService,
            FailReasonGenerator failReasonGenerator,
            ClientRequestHeader clientRequestHeader,
            AccountServiceAdaptor accountServiceAdaptor
    ) {
        this.databaseAdaptor = databaseAdaptor;
        this.resultRetrievalService = resultRetrievalService;
        this.failReasonGenerator = failReasonGenerator;
        this.clientRequestHeader = clientRequestHeader;
        this.accountServiceAdaptor = accountServiceAdaptor;
    }


    public Series910Response service(ManualPostRequest manualPostRequest) throws IOException {

        accountServiceAdaptor.retrieveAccountDetails(manualPostRequest.getBrokerageAccountId());

        List<Series910Result> resultResponses = resultRetrievalService.service(
                manualPostRequest.getBrokerageAccountId()).getSeries910Results();

        if (resultResponses.isEmpty() ||
                resultResponses.stream().noneMatch(series910Response ->
                        "manual".equalsIgnoreCase(series910Response.getTriggerEventCode()))) {
            log.info("Saving the Manual Result to the Database.");
            autoReviewResult(manualPostRequest);
            log.info("The account was a Manual " + manualPostRequest.getPassFailCode().toUpperCase());
            log.info("Successfully saved the Manual Review Result to the Database.");

            Series910Response series910Response = Series910Response.builder().build();
            series910Response.getReturnDetails().add(ReturnDetails.builder()
                    .returnCode(0)
                    .returnMessage("")
                    .build());
            return series910Response;
        } else {
            throw new ManualValidationAlreadyRunException();
        }
    }

    private void autoReviewResult(ManualPostRequest manualPostRequest) {
        databaseAdaptor.saveAutoReviewResult(
                manualPostRequest.getBrokerageAccountId(),
                clientRequestHeader.getChannel(),
                "RETAIL",
                "MANUAL",
                clientRequestHeader.getUserId(),
                LocalDateTime.now(),
                manualPostRequest.getPassFailCode(),
                LocalDateTime.now(),
                failReasonGenerator.addFailReasonToSaveResultRequest(manualPostRequest)
        );
    }
}
