package com.schwab.brokerage.account.series910.review.connector;

import com.schwab.brokerage.account.series910.review.exception.external.RetailCustomerProfileException;
import com.schwab.brokerage.account.series910.review.util.TokenGenerator;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import schwab.rrbus._1_0.sch_core_customeraccount_retailcustomerprofileservice.io.BrokerageAccount;
import schwab.rrbus._1_0.sch_core_customeraccount_retailcustomerprofileservice.io.BrokerageAccountList;
import schwab.rrbus._1_0.sch_core_customeraccount_retailcustomerprofileservice.io.GetCustRetailLoginDataReply;

import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.io.StringReader;
import java.util.List;

@Slf4j
@Component
public class RetailCustomerProfileConnectorRest {
    private final HttpServletRequest httpServletRequest;
    private final TokenGenerator tokenGenerator;
    private final RestTemplate restTemplate;

    public RetailCustomerProfileConnectorRest(
            HttpServletRequest httpServletRequest,
            TokenGenerator tokenGenerator,
            RestTemplate restTemplate
    ) {
        this.httpServletRequest = httpServletRequest;
        this.tokenGenerator = tokenGenerator;
        this.restTemplate = restTemplate;
    }

    public GetCustRetailLoginDataReply custRetailLoginData(
            Integer customerId
    ) {
        GetCustRetailLoginDataReply getCustRetailLoginDataReply = new GetCustRetailLoginDataReply();
        String saml = StringUtils.trim(StringUtils.remove(httpServletRequest.getHeader(HttpHeaders.AUTHORIZATION), "SAML"));

        String payload = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><SOAP-ENV:Header><wsse:Security xmlns:soapenc=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:wsse=\"http://schemas.xmlsoap.org/ws/2002/04/secext\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                tokenGenerator.decode(saml) +
                "</wsse:Security><s0:context\n" +
                "   xmlns:s0=\"urn:schwab:rrbus:schemas:context:1.0\"\n" +
                "   xmlns:soapenc=\"http://schemas.xmlsoap.org/soap/encoding/\"\n" +
                "   xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\"\n" +
                "     xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\n" +
                "   <s0:PilotRollout>\n" +
                "    <Region\n" +
                "   xmlns=\"\">TUP</Region>\n" +
                "   </s0:PilotRollout>\n" +
                "   <s0:channel>IO</s0:channel>\n" +
                "  </s0:context></SOAP-ENV:Header> <SOAP-ENV:Body>\n" +
                "  <GetAllCustRetailLoginData xmlns=\"urn:schwab:rrbus:1.0:sch.core.customeraccount.retailcustomerprofileservice:io\">\n" +
                "   <Request>\n" +
                "    <ns1:CustomerDesignator xmlns:ns1=\"urn:schwab:types:sch.core.customeraccount:1.0\">\n" +
                "     <ns1:BrkrCustId>" + customerId + "</ns1:BrkrCustId>\n" +
                "    </ns1:CustomerDesignator>\n" +
                "   <DetailRequests>\n" +
                "     <DetailRequest>IncludePreferences</DetailRequest>\n" +
                "     <DetailRequest>IncludeReadOnly</DetailRequest>\n" +
                "    </DetailRequests>\n" +
                "    <ClosedAcctCutOffDate>2099-12-17T13:38:39.157Z</ClosedAcctCutOffDate>\n" +
                "   </Request>\n" +
                "  </GetAllCustRetailLoginData>\n" +
                " </SOAP-ENV:Body>\n" +
                "</SOAP-ENV:Envelope>";

        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "text/xml; charset=UTF-8");
        headers.set("SOAPAction", "\"urn:schwab:rrbus:1.0:sch.core.customeraccount.retailcustomerprofileservice/GetAllCustRetailLoginData\"");

        HttpEntity<String> entity = new HttpEntity<>(payload, headers);

        ResponseEntity<String> responseEntity = restTemplate.postForEntity("https://intermediary-test.dev.schwab.com:9043/services?service=uddi:schwab.com:service:sch.core.customerAccount.RetailCustomerProfileService&portType=RetailCustomerProfileInterface", entity, String.class);

        if (responseEntity.getBody().contains("<BrokerageAccounts/>")) {
            getCustRetailLoginDataReply.setBrokerageAccounts(new BrokerageAccountList());
            return getCustRetailLoginDataReply;
        }

        String trimmed = StringUtils.substring(
                responseEntity.getBody(),
                StringUtils.indexOf(responseEntity.getBody(), "<BrokerageAccounts>"),
                StringUtils.indexOf(responseEntity.getBody(), "<AffiliateCustomers>")
        );

        try {
            JAXBContext context = JAXBContext.newInstance(BrokerageAccounts.class);
            Unmarshaller unmarshaller = context.createUnmarshaller();
            BrokerageAccounts accounts = (BrokerageAccounts) unmarshaller.unmarshal(
                    new StringReader(trimmed)
            );
            BrokerageAccountList brokerageAccountList = new BrokerageAccountList();
            brokerageAccountList.getBrokerageAccount().addAll(accounts.getBrokerageAccounts());
            getCustRetailLoginDataReply.setBrokerageAccounts(brokerageAccountList);

        } catch (Exception e) {
            throw new RetailCustomerProfileException(e);
        }

        return getCustRetailLoginDataReply;
    }

    @XmlRootElement(name = "BrokerageAccounts")
    public static class BrokerageAccounts {
        @XmlElement(name = "BrokerageAccount")
        private List<BrokerageAccount> brokerageAccounts;

        public List<BrokerageAccount> getBrokerageAccounts() {
            return this.brokerageAccounts;
        }
    }
}
