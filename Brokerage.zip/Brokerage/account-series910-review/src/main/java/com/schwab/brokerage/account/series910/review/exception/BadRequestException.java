package com.schwab.brokerage.account.series910.review.exception;

import com.schwab.brokerage.account.series910.review.model.response.ReturnDetails;

public class BadRequestException extends ReturnDetailsException {
    public BadRequestException() {
        super();
    }

    public BadRequestException(String message) {
        super(message);
    }

    public BadRequestException(String message, Throwable cause) {
        super(message, cause);
    }

    public BadRequestException(Throwable cause) {
        super(cause);
    }

    public BadRequestException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    public BadRequestException(Integer returnCode) {
        super(ReturnDetails.builder().returnCode(returnCode).build());
    }

    public BadRequestException(Integer returnCode, String message) {
        super(ReturnDetails.builder().returnCode(returnCode).build(), message);
    }

    public BadRequestException(Integer returnCode, String message, Throwable cause) {
        super(ReturnDetails.builder().returnCode(returnCode).build(), message, cause);
    }

    public BadRequestException(Integer returnCode, Throwable cause) {
        super(ReturnDetails.builder().returnCode(returnCode).build(), cause);
    }

    public BadRequestException(Integer returnCode, String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(ReturnDetails.builder().returnCode(returnCode).build(), message, cause, enableSuppression, writableStackTrace);
    }

    @Override
    protected ReturnDetails getDefaultReturnDetails() {
        return ReturnDetails.builder().returnCode(400).build();
    }
}
