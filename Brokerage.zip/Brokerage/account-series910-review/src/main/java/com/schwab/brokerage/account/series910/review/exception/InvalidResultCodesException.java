package com.schwab.brokerage.account.series910.review.exception;

public class InvalidResultCodesException extends BadRequestException {
    public InvalidResultCodesException(String message) {
        super(11004, message);
    }
}
