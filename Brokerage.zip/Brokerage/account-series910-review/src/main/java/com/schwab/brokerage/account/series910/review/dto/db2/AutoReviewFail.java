package com.schwab.brokerage.account.series910.review.dto.db2;

import com.schwab.brokerage.account.series910.review.dto.db2.constraint.AutoReviewFailKey;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "AUTO_REVU_FAIL", schema = "SAMS")
public class AutoReviewFail {

    @EmbeddedId
    private AutoReviewFailKey primaryKey;

    @Column(name = "RESULT_TX", length = 254)
    private String resultText;

    @Column(name = "AUDIT_UPDT_USER_ID", length = 10)
    private String auditUpdateUserId;

    @Column(name = "AUDIT_UPDT_TS")
    private Timestamp auditUpdateTimestamp;

    @MapsId("autoReviewResultKey")
    @JoinColumns({
            @JoinColumn(name = "ACCT_ID", referencedColumnName = "ACCT_ID"),
            @JoinColumn(name = "REVIEW_DT", referencedColumnName = "REVIEW_DT"),
            @JoinColumn(name = "REVIEW_TM", referencedColumnName = "REVIEW_TM")
    })
    @ManyToOne
    private AutoReviewResult autoReviewResult;

    @OneToMany
    private List<AutoReviewFailValue> autoReviewFailValues;
}
