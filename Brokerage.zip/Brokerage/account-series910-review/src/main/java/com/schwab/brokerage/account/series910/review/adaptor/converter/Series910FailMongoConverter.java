package com.schwab.brokerage.account.series910.review.adaptor.converter;

import com.schwab.brokerage.account.series910.review.model.FailReason;
import com.schwab.brokerage.account.series910.review.adaptor.converter.ModelConverter;
import com.schwab.brokerage.account.series910.review.adaptor.converter.ResponseConverter;
import com.schwab.brokerage.account.series910.review.dto.mongo.Series910FailMongo;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

@Component
public class Series910FailMongoConverter
        implements ResponseConverter<Series910FailMongo, FailReason>,
        ModelConverter<FailReason, Series910FailMongo> {

    @Override
    public FailReason toResponse(Series910FailMongo series910FailMongo) {
        return FailReason.builder()
                .failReasonCode(StringUtils.trimToEmpty(series910FailMongo.getResultCode()))
                .failReasonText(StringUtils.trimToEmpty(series910FailMongo.getResultText()))
                .build();
    }

    @Override
    public Series910FailMongo toModel(FailReason failReason) {
        return Series910FailMongo.builder()
                .resultCode(failReason.getFailReasonCode())
                .resultText(failReason.getFailReasonText())
                .build();
    }
}
