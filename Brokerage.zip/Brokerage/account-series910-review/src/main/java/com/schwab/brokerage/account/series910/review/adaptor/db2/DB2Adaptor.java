package com.schwab.brokerage.account.series910.review.adaptor.db2;

import com.schwab.brokerage.account.series910.review.adaptor.DatabaseAdaptor;
import com.schwab.brokerage.account.series910.review.connector.DB2Connector;
import com.schwab.brokerage.account.series910.review.exception.BadRequestException;
import com.schwab.brokerage.account.series910.review.model.FailReason;
import com.schwab.brokerage.account.series910.review.property.StoredProcParametersProp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

@Component("db2.adaptor")
public class DB2Adaptor implements DatabaseAdaptor {
    private final StoredProcParametersProp storedProcParametersProp;
    private final DB2Connector db2Connector;

    @Autowired
    public DB2Adaptor(
            StoredProcParametersProp storedProcParametersProp,
            DB2Connector db2Connector) {
        this.storedProcParametersProp = storedProcParametersProp;
        this.db2Connector = db2Connector;
    }

    @Override
    public Map<String, Object> saveAutoReviewResult(
            Integer accountId,
            String channelName,
            String enterprise,
            String triggerEventCode,
            String reviewUserId,
            LocalDateTime reviewUserTimestamp,
            String passFailCode,
            LocalDateTime auditUpdateTimestamp,
            List<FailReason> autoReviewFails
    ) {
        Map<String, Object> inputParameters = new HashMap<>();
        inputParameters.put(storedProcParametersProp.getAccountId(), accountId);
        inputParameters.put(storedProcParametersProp.getChannelName(), channelName);
        inputParameters.put(storedProcParametersProp.getEnterprise(), enterprise);
        inputParameters.put(storedProcParametersProp.getTriggerEventCode(), triggerEventCode);
        inputParameters.put(storedProcParametersProp.getReviewerUserId(), reviewUserId);
        inputParameters.put(storedProcParametersProp.getReviewerUserDate(), null);
        inputParameters.put(storedProcParametersProp.getReviewerUserTime(), null);
        inputParameters.put(storedProcParametersProp.getPassFailCode(), passFailCode);

        putArray(inputParameters, autoReviewFails);

        return db2Connector.createAutoReviewResult(inputParameters);
    }

    private void putArray(
            @NotNull Map<String, Object> inputParameters,
            @NotNull List<FailReason> autoReviewFails
    ) {
        if (autoReviewFails.size() > storedProcParametersProp.getParameterArrayMax()) {
            throw new BadRequestException(
                    "Fail Reasons exceeds max input(" +
                            storedProcParametersProp.getParameterArrayMax() +
                            "): " + autoReviewFails.size());
        }
        IntStream.range(storedProcParametersProp.getParameterArrayStart(), storedProcParametersProp.getParameterArrayMax() + 1)
                .forEach(i -> {
                    if (i - storedProcParametersProp.getParameterArrayStart() < autoReviewFails.size()) {
                        inputParameters.put(
                                storedProcParametersProp.getFailReasonCode() + i,
                                autoReviewFails.get(i - storedProcParametersProp.getParameterArrayStart()).getFailReasonCode());
                        inputParameters.put(
                                storedProcParametersProp.getFailReasonText() + i,
                                autoReviewFails.get(i - storedProcParametersProp.getParameterArrayStart()).getFailReasonText());
                    } else {
                        inputParameters.put(
                                storedProcParametersProp.getFailReasonCode() + i,
                                "");
                        inputParameters.put(
                                storedProcParametersProp.getFailReasonText() + i,
                                "");
                    }
                });
    }
}
