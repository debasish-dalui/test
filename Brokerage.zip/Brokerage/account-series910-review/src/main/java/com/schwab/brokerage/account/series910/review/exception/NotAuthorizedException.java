package com.schwab.brokerage.account.series910.review.exception;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class NotAuthorizedException extends RuntimeException {
    private final Integer returnCode;

    public NotAuthorizedException(Integer returnCode) {
        super();
        this.returnCode = returnCode;
    }

    public NotAuthorizedException(Integer returnCode, String message) {
        super(message);
        this.returnCode = returnCode;
    }

    public NotAuthorizedException(String message, Throwable cause, Integer returnCode) {
        super(message, cause);
        this.returnCode = returnCode;
    }

    public NotAuthorizedException(Throwable cause, Integer returnCode) {
        super(cause);
        this.returnCode = returnCode;
    }

    public NotAuthorizedException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace, Integer returnCode) {
        super(message, cause, enableSuppression, writableStackTrace);
        this.returnCode = returnCode;
    }
}
