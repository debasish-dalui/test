package com.schwab.brokerage.account.series910.review.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class AddressServiceRequest implements GenericRequest {

    @JsonProperty("IN_ACCOUNT_ID")
    private Integer accountId;
}
