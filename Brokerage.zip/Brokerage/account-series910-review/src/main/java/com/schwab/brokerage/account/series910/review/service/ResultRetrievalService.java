package com.schwab.brokerage.account.series910.review.service;

import com.schwab.brokerage.account.series910.review.adaptor.Series910ResultAdaptor;
import com.schwab.brokerage.account.series910.review.exception.ResultsNotFoundException;
import com.schwab.brokerage.account.series910.review.model.response.ReturnDetails;
import com.schwab.brokerage.account.series910.review.model.response.Series910Response;
import com.schwab.brokerage.account.series910.review.model.response.Series910Result;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
@RefreshScope
public class ResultRetrievalService {
    private final Series910ResultAdaptor series910ResultAdaptor;

    @Autowired
    public ResultRetrievalService(Series910ResultAdaptor series910ResultAdaptor) {
        this.series910ResultAdaptor = series910ResultAdaptor;
    }


    public Series910Response service(Integer accountId) {
        List<Series910Result> resultResponses = series910ResultAdaptor.retrieve(accountId);
        if (CollectionUtils.isEmpty(resultResponses)) {
            throw new ResultsNotFoundException(accountId + ".  Auto run result not found in database.");
        }

        Series910Response series910Response = Series910Response
                .builder()
                .series910Results(resultResponses)
                .build();
        series910Response.getReturnDetails().add(ReturnDetails.builder()
                .returnCode(0)
                .returnMessage("")
                .build());

        return series910Response;
    }
}