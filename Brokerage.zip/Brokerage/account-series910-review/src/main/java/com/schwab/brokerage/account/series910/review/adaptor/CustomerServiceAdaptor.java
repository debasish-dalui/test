package com.schwab.brokerage.account.series910.review.adaptor;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.schwab.brokerage.account.series910.review.connector.CustomerServiceConnector;
import com.schwab.brokerage.account.series910.review.exception.NoValidResultsException;
import com.schwab.brokerage.account.series910.review.exception.ResultsNotFoundException;
import com.schwab.brokerage.account.series910.review.model.Customer;
import com.schwab.brokerage.account.series910.review.model.request.CustomerIdRequest;
import com.schwab.brokerage.account.series910.review.model.request.CustomerServiceRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Slf4j
@Component
public class CustomerServiceAdaptor {
    private final String partyUrl;
    private final String detailsUrl;
    private final String employmentUrl;
    private final ObjectMapper objectMapper;
    private final CustomerServiceConnector customerServiceConnector;

    @Autowired
    public CustomerServiceAdaptor(
            @Value("${service.customer.partyUrl}") String partyUrl,
            @Value("${service.customer.detailsUrl}") String detailsUrl,
            @Value("${service.customer.employmentUrl}") String employmentUrl,
            ObjectMapper objectMapper,
            CustomerServiceConnector customerServiceConnector
    ) {
        this.partyUrl = partyUrl;
        this.detailsUrl = detailsUrl;
        this.employmentUrl = employmentUrl;
        this.objectMapper = objectMapper;
        this.customerServiceConnector = customerServiceConnector;
    }

    @Cacheable("customers")
    public Customer retrieveCustomerDetails(Integer customerId) throws IOException {
        CustomerServiceRequest customerServiceRequest = new CustomerServiceRequest(customerId);
        ResponseEntity<String> response = customerServiceConnector.sendRestRequest(
                detailsUrl,
                HttpMethod.POST,
                customerServiceRequest
        );
        JsonNode node = objectMapper.readValue(response.getBody(), JsonNode.class);
        node = node.get("party").get(0);
        return objectMapper.convertValue(node, Customer.class);
    }

    @Cacheable("customer407Codes")
    public String retrieveCustomer407Code(Integer customerId) throws IOException {
        CustomerServiceRequest customerServiceRequest = new CustomerServiceRequest(customerId);

        ResponseEntity<String> response = customerServiceConnector.sendRestRequest(
                employmentUrl,
                HttpMethod.POST,
                customerServiceRequest
        );
        JsonNode node = objectMapper.readValue(response.getBody(), JsonNode.class);
        if(node.get("employment").size() == 0){
            return "NO";
        }
        return node.get("employment").get(0).get("indiv407TypeCd").asText();
    }

    public List<String> retrieveCustomerIds(String taxPayerId) throws IOException {

        CustomerIdRequest customerIdRequest = new CustomerIdRequest(taxPayerId);

        ResponseEntity<String> response = customerServiceConnector.sendRestRequest(
                partyUrl,
                HttpMethod.POST,
                customerIdRequest
        );

        ArrayList<String> arrayList = new ArrayList<>();
        if (!(response.getBody().isEmpty())) {
            JsonNode jsonNode = objectMapper.readValue(response.getBody(), JsonNode.class);
            jsonNode = jsonNode.get("parties").get(0).get("party");
            Iterator<JsonNode> iterator = jsonNode.elements();
            while (iterator.hasNext()) {
                jsonNode = iterator.next();
                Iterator<JsonNode> iter = jsonNode.get("profiles").elements();
                while (iter.hasNext()) {
                    jsonNode = iter.next();
                    if ((jsonNode.get("afltCompanyCodeType").asText().equalsIgnoreCase("SCH"))) {
                        arrayList.add(jsonNode.get("afltCustId").asText());
                    } else {
                        throw new NoValidResultsException("Customer Company code is not SCH");
                    }
                }
            }
        } else {
            throw new ResultsNotFoundException("Customer Ids not found for Tax Payer Id ");
        }
        return arrayList;
    }
}
