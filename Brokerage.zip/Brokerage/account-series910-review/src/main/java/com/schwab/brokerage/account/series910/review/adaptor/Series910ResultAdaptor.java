package com.schwab.brokerage.account.series910.review.adaptor;

import com.schwab.brokerage.account.series910.review.model.response.Series910Result;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface Series910ResultAdaptor {
    List<Series910Result> retrieve(Integer accountId);
}
