package com.schwab.brokerage.account.series910.review.exception;

import com.schwab.brokerage.account.series910.review.model.response.ReturnDetails;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@EqualsAndHashCode(callSuper = true)
public abstract class ReturnDetailsException extends RuntimeException {
    private final transient ReturnDetails returnDetails;

    public ReturnDetailsException() {
        super();
        this.returnDetails = getDefaultReturnDetails();
    }

    ReturnDetailsException(String message) {
        super(message);
        this.returnDetails = this.getDefaultReturnDetails();
    }

    ReturnDetailsException(String message, Throwable cause) {
        super(message, cause);
        this.returnDetails = this.getDefaultReturnDetails();
    }

    ReturnDetailsException(Throwable cause) {
        super(cause);
        this.returnDetails = this.getDefaultReturnDetails();
    }

    ReturnDetailsException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
        this.returnDetails = this.getDefaultReturnDetails();
    }

    ReturnDetailsException(ReturnDetails returnDetails, String message) {
        super(message);
        this.returnDetails = returnDetails;
    }

    ReturnDetailsException(ReturnDetails returnDetails, String message, Throwable cause) {
        super(message, cause);
        this.returnDetails = returnDetails;
    }

    ReturnDetailsException(ReturnDetails returnDetails, Throwable cause) {
        super(cause);
        this.returnDetails = returnDetails;
    }

    ReturnDetailsException(ReturnDetails returnDetails, String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
        this.returnDetails = returnDetails;
    }


    protected abstract ReturnDetails getDefaultReturnDetails();
}
