package com.schwab.brokerage.account.series910.review.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.schwab.boa.helper.BOAHelper;
import com.schwab.brokerage.account.series910.review.exception.NotAuthorizedException;
import com.schwab.token.helper.TokenHelper;
import com.schwab.token.helper.dto.TokenDetail;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.junit4.SpringRunner;
import schwab.rrbus._1_0.sch_core_enterprisesecurity_brokerageoperationsauthorizationservice.io.*;

import java.util.ArrayList;
import java.util.List;

import static test.ReadFixture.readFixture;
@RunWith(SpringRunner.class)
public class AuthorizationServiceTest {
    @Mock
    private TokenHelper tokenHelper;
    @Mock
    private BOAHelper boaHelper;

    private AuthorizationService authorizationService;
    private GetResourceAndConfidentialAccessPermissionsReply getResourceAndConfidentialAccessPermissionsReply;
    private ObjectMapper mapper = new ObjectMapper();
    private String boaResourceId = "CACTUPDS";
    private AccessType accessType = AccessType.WRITE;
    private List<Integer> accountIdsList = new ArrayList<>();
    private ResourceList resources = new ResourceList();
    private Resource resource = new Resource();

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        accountIdsList.add(1111);
        resource.setResourceId(boaResourceId);
        resource.setAccessType(accessType);
        resource.setResourceType(ResourceType.FCT);
        resources.getResource().add(resource);
        authorizationService = new AuthorizationService(tokenHelper, boaHelper, resources);

    }

    @Test(expected = NotAuthorizedException.class)
    public void nonRepNonSystemThrowsException() throws Exception {
        Mockito.when(tokenHelper.getTokenDetails()).thenReturn(new TokenDetail());

        authorizationService.service(1111, accessType);
    }

    @Test(expected = NotAuthorizedException.class)
    public void unauthorizedByBoaService() throws Exception {
        getResourceAndConfidentialAccessPermissionsReply = mapper.readValue(readFixture("/Responses/boaUnauthorizedResponse.json"), GetResourceAndConfidentialAccessPermissionsReply.class);
        Mockito.when(boaHelper.getResourceAndConfidentialAccessPermissions(accountIdsList, resources, 0)).thenReturn(getResourceAndConfidentialAccessPermissionsReply);

        authorizationService.tokenAuthorization(1111, accessType);
    }


}
