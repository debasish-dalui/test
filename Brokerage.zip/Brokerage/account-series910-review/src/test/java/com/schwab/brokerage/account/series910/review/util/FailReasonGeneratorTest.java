package com.schwab.brokerage.account.series910.review.util;

import com.schwab.brokerage.account.series910.review.config.Series910Config;
import com.schwab.brokerage.account.series910.review.model.Account;
import com.schwab.brokerage.account.series910.review.model.FailReason;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Answers;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@RunWith(SpringRunner.class)
public class FailReasonGeneratorTest {

    @Mock(answer = Answers.RETURNS_DEEP_STUBS)
    private Series910Config series910Config;

    @Mock
    Map<String, String> validReasons;

    private FailReasonGenerator failReasonGenerator;
    private Account account;

    @Before
    public void init() {
        failReasonGenerator = new FailReasonGenerator(series910Config);


        Mockito.when(series910Config.getValidFailReasons().containsKey(Matchers.any())).thenReturn(true);
        account = Account.builder().build();
    }

    @Test
    public void addFailReasonToAccount() {
        Mockito.when(series910Config.getValidFailReasons().get("code")).thenReturn("text");
        failReasonGenerator.addFailReasonToAccount(account, "code");

        Set<FailReason> failReasons = new HashSet<FailReason>();
        failReasons.add(FailReason.builder().failReasonCode("code").failReasonText("text").build());
        Account expected = Account.builder().failReasons(failReasons).build();

        Assert.assertEquals(expected, account);
    }

    @Test
    public void addFailReasonToAccountWithId() {
        Mockito.when(series910Config.getValidFailReasons().get("code")).thenReturn("text %s");
        failReasonGenerator.addFailReasonToAccountWithId(account, "code", "extra-text");

        Set<FailReason> failReasons = new HashSet<FailReason>();
        failReasons.add(FailReason.builder().failReasonCode("code").failReasonText("text extra-text").build());
        Account expected = Account.builder().failReasons(failReasons).build();

        Assert.assertEquals(expected, account);
    }

}
