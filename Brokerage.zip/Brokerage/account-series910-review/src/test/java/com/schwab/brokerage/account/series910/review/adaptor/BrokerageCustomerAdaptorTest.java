package com.schwab.brokerage.account.series910.review.adaptor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.schwab.brokerage.account.series910.review.connector.BrokerageCustomerConnector;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import test.ReadFixture;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
@RunWith(SpringRunner.class)
public class BrokerageCustomerAdaptorTest {
    @Mock
    private HttpHeaders brokerageCustomerServiceHeaders;
    @Mock
    private BrokerageCustomerConnector brokerageCustomerConnector;

    private BrokerageCustomerAdaptor brokerageCustomerAdaptor;
    private ObjectMapper objectMapper = new ObjectMapper();

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        brokerageCustomerAdaptor = new BrokerageCustomerAdaptor(
                "/url",
                brokerageCustomerServiceHeaders,
                objectMapper,
                brokerageCustomerConnector
        );
    }

    @Test
    public void retrieveCustomerRestrictions() throws IOException {
        String response = ReadFixture.readFixture("/BrokerageCustomerService/valid-response.json");
        Mockito.when(brokerageCustomerConnector.sendRestRequest(
                "/url",
                HttpMethod.GET,
                brokerageCustomerServiceHeaders))
                .thenReturn(ResponseEntity.ok(response));
        List<String> expected = Collections.singletonList("Deceased Client");
        List<String> actual = brokerageCustomerAdaptor.retrieveCustomerRestrictions(284206799);

        Assert.assertEquals(expected, actual);

    }
}