package com.schwab.brokerage.account.series910.review.connector;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.schwab.brokerage.account.series910.review.model.request.AccountServiceRequest;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;
@RunWith(SpringRunner.class)
public class CustomerServiceConnectorTest {
    @Mock
    private RestTemplate restTemplate;
    private CustomerServiceConnector customerServiceConnector;
    private ObjectMapper mapper = new ObjectMapper();
    private HttpHeaders headers;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        customerServiceConnector = new CustomerServiceConnector(restTemplate, headers, mapper);
    }

    @Test(expected = RuntimeException.class)
    public void catchException() {
        Mockito.when(restTemplate.exchange(Matchers.any(), Matchers.any(), Matchers.any(), String.class))
                .thenThrow(new Exception("test message"));

        customerServiceConnector.sendRestRequest(
                "/path",
                HttpMethod.POST,
                AccountServiceRequest.builder().build());
    }
}
