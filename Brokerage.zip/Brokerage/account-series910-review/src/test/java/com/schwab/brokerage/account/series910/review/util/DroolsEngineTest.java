package com.schwab.brokerage.account.series910.review.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.schwab.brokerage.account.series910.review.model.Account;
import com.schwab.brokerage.account.series910.review.model.DroolsCustomerDetails;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.kie.dmn.api.core.DMNModel;
import org.kie.dmn.api.core.DMNResult;
import org.kie.dmn.api.core.DMNRuntime;
import org.kie.dmn.core.impl.DMNDecisionResultImpl;
import org.kie.dmn.core.impl.DMNResultImpl;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;
import test.ReadExcel;
import test.ReadFixture;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@RunWith(SpringRunner.class)
public class DroolsEngineTest {

    @Mock
    private DMNModel accountRegistrationEligibilityModel;
    @Mock
    private DMNRuntime accountRegistrationRuntime;
    @Mock
    private DMNModel customerEligibilityModel;
    @Mock
    private DMNRuntime customerEligibilityRuntime;
    @Mock
    private DMNModel mailingAddressModel;
    @Mock
    private DMNRuntime mailingAddressRuntime;

    private DroolsEngine droolsEngine;
    private Account account;
    private List<ArrayList<Object>> excelContents;
    Map<String, String> result = new HashMap<>();
    private ObjectMapper objectMapper = new ObjectMapper();
    private DMNDecisionResultImpl decisionResult;
    private DMNResultImpl dmnResult;
    private DroolsCustomerDetails droolsCustomerDetails;

    @Before
    public void init() throws IOException {
        MockitoAnnotations.initMocks(this);


        droolsEngine = new DroolsEngine(
                accountRegistrationEligibilityModel,
                accountRegistrationRuntime,
                customerEligibilityModel,
                customerEligibilityRuntime,
                mailingAddressModel,
                mailingAddressRuntime);
        excelContents = ReadExcel.readExcelFile("src/test/resources/accountEligibility.xlsx");
        account = Account.builder()
                .accountProductCode("IRA")
                .accountRegistrationCode("CO")
                .build();
        droolsCustomerDetails = objectMapper.readValue(ReadFixture.readFixture("/DroolsTestCases/PassingDroolsCustomer.json"), DroolsCustomerDetails.class);

        decisionResult = new DMNDecisionResultImpl("id", "name");
        decisionResult.setResult("CONFIRMED");
        dmnResult = new DMNResultImpl();
        dmnResult.setDecisionResult("Test", decisionResult);


    }


    @Test
    public void fireMailingAddressRule() throws Exception {

        Mockito.when(mailingAddressRuntime.evaluateAll(Matchers.any(), Matchers.any())).thenReturn(dmnResult);
        Map<String, String> actual = droolsEngine.fireMailingAddressRule("ANY");
        Map<String, String> expected = new HashMap<>();
        expected.put("name", "CONFIRMED");
        Assert.assertEquals(expected, actual);

    }

    @Test
    public void fireCustomerRule() throws Exception {

        Mockito.when(customerEligibilityRuntime.evaluateAll(Matchers.any(), Matchers.any())).thenReturn(dmnResult);
        Map<String, String> actual = droolsEngine.fireCustomerRule(droolsCustomerDetails);
        Map<String, String> expected = new HashMap<>();
        expected.put("name", "CONFIRMED");

        Assert.assertEquals(expected, actual);

    }

    @Test
    public void fireEligibilityRule() throws Exception {

        Mockito.when(accountRegistrationRuntime.evaluateAll(Matchers.any(), Matchers.any())).thenReturn(dmnResult);
        Map<String, String> actual = droolsEngine.fireEligibilityRule(account);
        Map<String, String> expected = new HashMap<>();
        expected.put("name", "CONFIRMED");

        Assert.assertEquals(expected, actual);

    }

    @Test
    public void populateResult() throws Exception {
        Method populateResult = DroolsEngine.class.getDeclaredMethod("populateResult", DMNResult.class);
        populateResult.setAccessible(true);
        Map<String, String> actual = (Map<String, String>) populateResult.invoke(droolsEngine, dmnResult);
        Map<String, String> expected = new HashMap<>();
        expected.put("name", "CONFIRMED");

        Assert.assertEquals(expected, actual);
    }

}
