package com.schwab.brokerage.account.series910.review.adaptor.converter;

import com.schwab.brokerage.account.series910.review.dto.mongo.Series910FailMongo;
import com.schwab.brokerage.account.series910.review.model.FailReason;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class Series910FailMongoConverterTest {
    private Series910FailMongoConverter series910FailMongoConverter;

    private FailReason failReason;
    private Series910FailMongo series910FailMongo;

    @Before
    public void setUp() {
        series910FailMongoConverter = new Series910FailMongoConverter();

        failReason = FailReason.builder()
                .failReasonCode("OTH")
                .failReasonText("Other")
                .build();
        series910FailMongo = Series910FailMongo.builder()
                .resultCode("OTH")
                .resultText("Other")
                .build();
    }

    @Test
    public void toResponse() {
        FailReason expected = FailReason.builder()
                .failReasonCode(series910FailMongo.getResultCode())
                .failReasonText(series910FailMongo.getResultText())
                .build();
        FailReason actual = series910FailMongoConverter.toResponse(series910FailMongo);
        Assert.assertEquals(expected, actual);
    }

    @Test
    public void toModel() {
        Series910FailMongo expected = Series910FailMongo.builder()
                .resultCode(failReason.getFailReasonCode())
                .resultText(failReason.getFailReasonText())
                .build();

        Series910FailMongo actual = series910FailMongoConverter.toModel(failReason);
        Assert.assertEquals(expected, actual);
    }

}