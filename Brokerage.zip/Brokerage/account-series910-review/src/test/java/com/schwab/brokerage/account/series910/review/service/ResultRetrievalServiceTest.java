package com.schwab.brokerage.account.series910.review.service;

import com.schwab.brokerage.account.series910.review.adaptor.db2.Series910ResultDb2Adaptor;
import com.schwab.brokerage.account.series910.review.exception.ResultsNotFoundException;
import com.schwab.brokerage.account.series910.review.model.response.Series910Response;
import com.schwab.brokerage.account.series910.review.model.response.Series910Result;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;
@RunWith(SpringRunner.class)
public class ResultRetrievalServiceTest {
    @Mock
    private Series910ResultDb2Adaptor series910ResultDb2Adaptor;

    @InjectMocks
    private ResultRetrievalService resultRetrievalService;

    private List<Series910Result> expected;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        expected = new ArrayList<>();

        resultRetrievalService = new ResultRetrievalService(series910ResultDb2Adaptor);
    }

    @Test(expected = ResultsNotFoundException.class)
    public void serviceEmptyResults() throws Exception {
        Mockito.when(series910ResultDb2Adaptor.retrieve(Matchers.anyInt()))
                .thenReturn(expected);
        Series910Response actual = resultRetrievalService.service(100);
    }
}