package com.schwab.brokerage.account.series910.review.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.schwab.brokerage.account.series910.review.adaptor.AccountServiceAdaptor;
import com.schwab.brokerage.account.series910.review.adaptor.Series910ResultAdaptor;
import com.schwab.brokerage.account.series910.review.exception.AccountNotFoundException;
import com.schwab.brokerage.account.series910.review.exception.ValidationAlreadyRunException;
import com.schwab.brokerage.account.series910.review.adaptor.DatabaseAdaptor;
import com.schwab.brokerage.account.series910.review.model.Account;
import com.schwab.brokerage.account.series910.review.model.Citizenship;
import com.schwab.brokerage.account.series910.review.model.Customer;
import com.schwab.brokerage.account.series910.review.model.FailReason;
import com.schwab.brokerage.account.series910.review.model.request.ClientRequestHeader;
import com.schwab.brokerage.account.series910.review.model.response.Series910Response;
import com.schwab.brokerage.account.series910.review.model.response.Series910Result;
import com.schwab.brokerage.account.series910.review.util.DroolsEngine;
import com.schwab.brokerage.account.series910.review.util.FailReasonGenerator;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.stubbing.Answer;
import org.springframework.test.context.junit4.SpringRunner;
import test.ReadFixture;

import java.lang.reflect.Method;
import java.time.LocalDate;
import java.util.*;

import static test.ReadFixture.readFixture;
@RunWith(SpringRunner.class)
public class AutoReviewServiceTest {
    @Mock
    private AccountServiceAdaptor accountServiceAdaptor;

    @Mock
    private Series910ResultAdaptor series910ResultAdaptor;

    @Mock
    private DroolsEngine droolsEngine;
    @Mock
    private FailReasonGenerator failReasonGenerator;
    @Mock
    private CustomerDataRetrievalService customerDataRetrievalService;
    @Mock
    private AccountDataRetrievalService accountDataRetrievalService;

    @Mock
    private ClientRequestHeader clientRequestHeader;
    @Mock
    private DatabaseAdaptor databaseAdaptor;

    private AutoReviewService autoReviewService;
    private ObjectMapper mapper = new ObjectMapper();
    private TypeFactory typeFactory = mapper.getTypeFactory();
    private Account account;
    private Map<String, String> result = new HashMap<>();
    private Citizenship citizenshipUS;
    private Customer customer;
    private Method handleMultipleCitizenShips;

    @Before
    public void init() throws Exception {
        MockitoAnnotations.initMocks(this);
        autoReviewService = new AutoReviewService(
                accountServiceAdaptor,
                series910ResultAdaptor,
                droolsEngine,
                failReasonGenerator,
                customerDataRetrievalService,
                accountDataRetrievalService,
                clientRequestHeader,
                databaseAdaptor,
                "accountRegistration",
                "organizationRestriction",
                "ageRestrictionbyRole",
                "custodianCheck");
        Mockito.when(clientRequestHeader.getChannel()).thenReturn("MYQ");
        Mockito.when(clientRequestHeader.getUserId()).thenReturn("Rep Id");

        account = Account.builder()
                .accountProductCode("IRA")
                .accountRegistrationCode("CO")
                .build();
        ArrayList<Citizenship> citizenship = new ArrayList<>();

        citizenshipUS = mapper.readValue(readFixture("/Customer/Citizenship/us.json"), Citizenship.class);

        citizenship.add(citizenshipUS);
        customer = Customer.builder()
                .individual407TypeCode("NO")
                .customerTypeCode("IND")
                .customerId(1)
                .taxPayerId("1")
                .citizenships(citizenship)
                .countryOfResidence("US")
                .dateOfBirth(LocalDate.of(1988, 1, 4))
                .build();
        account.addCustomer(customer, "CUST");

        Mockito.when(accountServiceAdaptor.retrieveAccountDetails(Matchers.any())).thenReturn(account);

        handleMultipleCitizenShips = AutoReviewService.class.getDeclaredMethod("handleMultipleCitizenShips", Customer.class);
        handleMultipleCitizenShips.setAccessible(true);
    }

    @Test(expected = ValidationAlreadyRunException.class)
    public void priorExecutionService() throws Exception {
        account = mapper.readValue(readFixture("/Account/account.json"), Account.class);

        List<Series910Result> results = new ArrayList<>();
        results.add(Series910Result.builder().build());
        Mockito.when(series910ResultAdaptor.retrieve(Matchers.any())).thenReturn(results);
        autoReviewService.service(1111);
    }

    @Test(expected = AccountNotFoundException.class)
    public void invalidAccountIdThrowsException() throws Exception {
        account = mapper.readValue(readFixture("/Account/account.json"), Account.class);
        account.setAccountProductCode("");
        Mockito.when(accountServiceAdaptor.retrieveAccountDetails(Matchers.any())).thenReturn(account);
        autoReviewService.service(1111);
    }

    @Test
    public void invalidAccountRegistrationCodes() throws Exception {
        Set<FailReason> failReasonsREG = mapper.readValue(
                ReadFixture.readFixture("/Responses/FailReasons/FailReasonREG.json"),
                typeFactory.constructCollectionType(Set.class, FailReason.class)
        );

        result.put("accountRegistration", "FAIL");
        Mockito.when(droolsEngine.fireEligibilityRule(account)).thenReturn(result);

        Mockito.doAnswer((Answer<Account>) invocation -> {
            account.setFailReasons(failReasonsREG);
            return account;
        }).when(failReasonGenerator).addFailReasonToAccount(Matchers.any(), Matchers.anyString());

        Series910Response series910Response = autoReviewService.service(account.getAccountId());

        Assert.assertTrue(series910Response.getReturnDetails().get(0).getReturnCode().equals(11000));
        Assert.assertTrue(series910Response.getReturnDetails().get(0).getReturnMessage().equals("Account has failed Automated Series 9/10 Review!"));
        Assert.assertTrue(series910Response.getSeries910Results().get(0).getPassFailCode().equals("FAIL"));
    }

    @Test
    public void invalidMailingAddress() throws Exception {
        Set<FailReason> failReasonsFMA = mapper.readValue(
                ReadFixture.readFixture("/Responses/FailReasons/FailReasonFMA.json"),
                typeFactory.constructCollectionType(Set.class, FailReason.class)
        );

        result.put("mailingAddressCheck", "FMA");
        Mockito.when(droolsEngine.fireMailingAddressRule("UK")).thenReturn(result);

        Mockito.doAnswer((Answer<Account>) invocation -> {
            account.setFailReasons(failReasonsFMA);
            return account;
        }).when(failReasonGenerator).addFailReasonToAccount(Matchers.any(), Matchers.anyString());

        Series910Response series910Response = autoReviewService.service(account.getAccountId());

        Assert.assertTrue(series910Response.getReturnDetails().get(0).getReturnCode().equals(11000));
        Assert.assertTrue(series910Response.getReturnDetails().get(0).getReturnMessage().equals("Account has failed Automated Series 9/10 Review!"));
        Assert.assertTrue(series910Response.getSeries910Results().get(0).getPassFailCode().equals("FAIL"));
        Assert.assertTrue(series910Response.getSeries910Results().get(0).getFailReasons().get(0).getFailReasonCode().equals("FMA"));
        Assert.assertTrue(series910Response.getSeries910Results().get(0).getFailReasons().get(0).getFailReasonText().equals("CUSTOMER/ACCOUNT HAS A FOREIGN MAILING ADDRESS"));
    }

    @Test
    public void multipleCitizenship() throws Exception {

        Citizenship citizenshipForeign = mapper.readValue(readFixture("/Customer/Citizenship/uk.json"), Citizenship.class);
        ArrayList<Citizenship> citizenship = new ArrayList<>();
        citizenship.add(citizenshipUS);
        citizenship.add(citizenshipForeign);
        customer.setCitizenships(citizenship);

        String actual = (String) handleMultipleCitizenShips.invoke(autoReviewService, customer);
        String expected = "";

        Assert.assertEquals(expected, actual);
    }

    @Test
    public void foreignCitizenship() throws Exception {

        Citizenship citizenshipForeign = mapper.readValue(readFixture("/Customer/Citizenship/uk.json"), Citizenship.class);
        ArrayList<Citizenship> citizenship = new ArrayList<>();
        citizenship.add(citizenshipForeign);
        customer.setCitizenships(citizenship);
        String actual = (String) handleMultipleCitizenShips.invoke(autoReviewService, customer);
        String expected = "";

        Assert.assertEquals(expected, actual);
    }

    @Test
    public void onlyUsCitizenship() throws Exception {
        String actual = (String) handleMultipleCitizenShips.invoke(autoReviewService, customer);
        String expected = "US";
        Assert.assertEquals(expected, actual);
    }

    @Test
    public void age() throws Exception {
        Method calcAge = AutoReviewService.class.getDeclaredMethod("calculateAge", Customer.class);
        calcAge.setAccessible(true);

        customer.setDateOfBirth(LocalDate.now().minusYears(70).minusMonths(6));
        Double actual = (Double) calcAge.invoke(autoReviewService, customer);
        Double expected = 70.5;
        Assert.assertEquals(expected,actual);
    }

    @Test
    public void successCase() throws Exception {
        result.put("accountRegistration", "CONFIRMED");
        Mockito.when(droolsEngine.fireEligibilityRule(account)).thenReturn(result);
        Mockito.when(customerDataRetrievalService.service(account)).thenReturn(account);

        Series910Response series910Response = autoReviewService.service(account.getAccountId());

        Assert.assertTrue(series910Response.getSeries910Results().get(0).getPassFailCode().equals("PASS"));
        Assert.assertTrue(series910Response.getSeries910Results().get(0).getTriggerEventCode().equals("AUTO"));
        Assert.assertNotNull(series910Response.getSeries910Results().get(0).getAuditUpdateTimestamp());
    }
}
