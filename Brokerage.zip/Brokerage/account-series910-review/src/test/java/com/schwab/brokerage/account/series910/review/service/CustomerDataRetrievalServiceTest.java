package com.schwab.brokerage.account.series910.review.service;


import com.schwab.brokerage.account.series910.review.adaptor.*;
import com.schwab.brokerage.account.series910.review.config.Series910Config;
import com.schwab.brokerage.account.series910.review.exception.DataAggregationException;
import com.schwab.brokerage.account.series910.review.model.Account;
import com.schwab.brokerage.account.series910.review.model.Customer;
import com.schwab.brokerage.account.series910.review.model.request.ClientRequestHeader;
import com.schwab.brokerage.account.series910.review.model.response.AccountCustRoleResponse;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

@RunWith(SpringRunner.class)
public class CustomerDataRetrievalServiceTest {


    @Mock
    private AccountServiceAdaptor accountServiceAdaptor;
    @Mock
    private CustomerServiceAdaptor customerServiceAdaptor;
    @Mock
    private AccountAddressAdaptor accountAddressAdaptor;
    @Mock
    private BrokerageCustomerAdaptor brokerageCustomerAdaptor;
    @Mock
    private RetailCustomerProfileAdaptor retailCustomerProfileAdaptor;
    @Mock
    private DatabaseAdaptor databaseAdaptor;
    @Mock
    private ClientRequestHeader clientRequestHeader;
    private String[] validCustomerRoles = {"ROLE1", "ROLE2"};

    private CustomerDataRetrievalService customerDataRetrievalService;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);

        Series910Config series910Config = Series910Config.builder()
                .validCustRoles(new HashSet<>(Arrays.asList(validCustomerRoles)))
                .build();

        customerDataRetrievalService = new CustomerDataRetrievalService(
                accountServiceAdaptor,
                customerServiceAdaptor,
                accountAddressAdaptor,
                brokerageCustomerAdaptor,
                databaseAdaptor,
                clientRequestHeader,
                series910Config
        );
    }

    @Test(expected = DataAggregationException.class)
    public void noCustomersFoundThrowsException() throws Exception {
        Mockito.when(accountServiceAdaptor.retrieveAccountRoles(Mockito.anyObject()))
                .thenReturn(null);
//
        customerDataRetrievalService.service(new Account());
    }

    @Test(expected = DataAggregationException.class)
    public void noCustomersWithValidRolesFoundThrowsException() throws Exception {
        List<AccountCustRoleResponse> response = new ArrayList<>();
        response.add(AccountCustRoleResponse.builder().role("WRONG").customerId(32).build());

        Mockito.when(accountServiceAdaptor.retrieveAccountRoles(Mockito.anyObject()))
                .thenReturn(response);

        customerDataRetrievalService.service(new Account());
    }

    @Test(expected = DataAggregationException.class)
    public void customerDetailsNotFoundThrowsException() throws Exception {
        List<AccountCustRoleResponse> response = new ArrayList<>();
        response.add(AccountCustRoleResponse.builder().role("ROLE1").customerId(32).build());
        response.add(AccountCustRoleResponse.builder().role("ROLE2").customerId(34).build());

        Mockito.when(accountServiceAdaptor.retrieveAccountRoles(Mockito.anyObject()))
                .thenReturn(response);
        Mockito.when(customerServiceAdaptor.retrieveCustomerDetails(32))
                .thenReturn(Customer.builder().customerId(32).build());
        Mockito.when(customerServiceAdaptor.retrieveCustomerDetails(34))
                .thenReturn(null);

        customerDataRetrievalService.service(new Account());
    }

    @Test
    public void validCustomerDataFoundReturnUpdatedAccount() throws Exception {
        List<AccountCustRoleResponse> response = new ArrayList<>();
        Customer c1 = Customer.builder().customerId(32).build();
        Customer c2 = Customer.builder().customerId(34).build();
        response.add(AccountCustRoleResponse.builder().role("ROLE1").customerId(32).build());
        response.add(AccountCustRoleResponse.builder().role("ROLE2").customerId(34).build());
        HashSet<Customer> expected = new HashSet<>();
        expected.add(c1);
        expected.add(c2);
        Mockito.when(accountServiceAdaptor.retrieveAccountRoles(Mockito.anyObject()))
                .thenReturn(response);
        Mockito.when(customerServiceAdaptor.retrieveCustomerDetails(32))
                .thenReturn(c1);
        Mockito.when(customerServiceAdaptor.retrieveCustomerDetails(34))
                .thenReturn(c2);
        Account result = customerDataRetrievalService.service(new Account());
//        Assert.assertTrue(result.getCustomers().size() == 2);
        Assert.assertEquals(result.getCustomers(), expected);
    }
}
