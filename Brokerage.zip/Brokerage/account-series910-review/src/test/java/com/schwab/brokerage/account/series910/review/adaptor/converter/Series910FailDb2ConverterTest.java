package com.schwab.brokerage.account.series910.review.adaptor.converter;

import com.schwab.brokerage.account.series910.review.dto.db2.AutoReviewFail;
import com.schwab.brokerage.account.series910.review.dto.db2.constraint.AutoReviewFailKey;
import com.schwab.brokerage.account.series910.review.model.FailReason;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;


import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;
@RunWith(SpringRunner.class)
public class Series910FailDb2ConverterTest {
    private Series910FailDb2Converter series910FailDb2Converter;

    private AutoReviewFail autoReviewFail;

    @Before
    public void setUp() {
        series910FailDb2Converter = new Series910FailDb2Converter();

        AutoReviewFailKey autoReviewFailKey = new AutoReviewFailKey();
        autoReviewFailKey.setResultCode("OTH");
        autoReviewFailKey.setFailSequenceId(1);

        autoReviewFail = new AutoReviewFail();
        autoReviewFail.setPrimaryKey(autoReviewFailKey);
        autoReviewFail.setResultText("ACCOUNTS OPENED VIA ELECT    ARE NOT ELIGIBLE FOR AUTOMATED REVIEW");
    }

    @Test
    public void toResponse() {
        FailReason expectedResult = FailReason.builder()
                .failReasonCode(autoReviewFail.getPrimaryKey().getResultCode())
                .failReasonText(autoReviewFail.getResultText())
                .build();
        FailReason actualResult = series910FailDb2Converter.toResponse(autoReviewFail);
        Assert.assertEquals(expectedResult, actualResult);
    }

}