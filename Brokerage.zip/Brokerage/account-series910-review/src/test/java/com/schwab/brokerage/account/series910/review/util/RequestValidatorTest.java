package com.schwab.brokerage.account.series910.review.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.schwab.brokerage.account.series910.review.exception.BadRequestException;
import com.schwab.brokerage.account.series910.review.model.request.ManualPostRequest;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

import static test.ReadFixture.readFixture;
@RunWith(SpringRunner.class)
public class RequestValidatorTest {
    private ManualPostRequest manualPostRequest;
    private ObjectMapper mapper = new ObjectMapper();
    private RequestValidator requestValidaterUtil;

    @Before
    public void init() {
        requestValidaterUtil = new RequestValidator(null, null);
    }


    @Test(expected = BadRequestException.class)
    public void invalidPassFailCodeThrowsException() throws Exception {
        manualPostRequest = mapper.readValue(readFixture("ManualRequestValidateService/invalid-passFailCode-request.json"), ManualPostRequest.class);

        requestValidaterUtil.validateManualPostRequest(manualPostRequest);
    }

    @Test(expected = BadRequestException.class)
    public void passedAccountWithFailureCodesThrowsException() throws Exception {
        manualPostRequest = mapper.readValue(readFixture("ManualRequestValidateService/passed-acct-with-fail-codes.json"), ManualPostRequest.class);

        requestValidaterUtil.validateManualPostRequest(manualPostRequest);
    }

    @Test(expected = BadRequestException.class)
    public void failedAccountWithNoFailureCodesThrowsException() throws Exception {
        manualPostRequest = mapper.readValue(readFixture("ManualRequestValidateService/failed-acct-with-no-fail-codes.json"), ManualPostRequest.class);
        requestValidaterUtil.validateManualPostRequest(manualPostRequest);
    }

    @Test(expected = BadRequestException.class)
    public void failedAccountWithOverFiftyFailureCodesThrowsException() throws Exception {
        manualPostRequest = mapper.readValue(readFixture("ManualRequestValidateService/failed-acct-with-many-fail-codes.json"), ManualPostRequest.class);

        requestValidaterUtil.validateManualPostRequest(manualPostRequest);
    }

    @Test(expected = BadRequestException.class)
    public void failedAccountWithInvalidFailureCodesThrowsException() throws Exception {
        manualPostRequest = mapper.readValue(readFixture("ManualRequestValidateService/failed-acct-with-incorrect-fail-codes.json"), ManualPostRequest.class);

        requestValidaterUtil.validateManualPostRequest(manualPostRequest);
    }


}
