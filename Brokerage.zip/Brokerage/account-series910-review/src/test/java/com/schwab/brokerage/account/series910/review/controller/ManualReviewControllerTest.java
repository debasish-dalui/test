package com.schwab.brokerage.account.series910.review.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.schwab.brokerage.account.series910.review.advice.GlobalExceptionHandler;
import com.schwab.brokerage.account.series910.review.constant.HeaderKeys;
import com.schwab.brokerage.account.series910.review.exception.BadRequestException;
import com.schwab.brokerage.account.series910.review.exception.InvalidResultCodesException;
import com.schwab.brokerage.account.series910.review.exception.ResultsNotFoundException;
import com.schwab.brokerage.account.series910.review.model.request.ClientRequestHeader;
import com.schwab.brokerage.account.series910.review.model.response.Series910Response;
import com.schwab.brokerage.account.series910.review.property.AccountErrorCodesProp;
import com.schwab.brokerage.account.series910.review.service.AuthorizationService;
import com.schwab.brokerage.account.series910.review.service.ManualReviewUpdateService;
import com.schwab.brokerage.account.series910.review.service.ResultRetrievalService;
import com.schwab.brokerage.account.series910.review.util.RequestValidator;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import test.ReadFixture;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
public class ManualReviewControllerTest {
    @Mock
    private ResultRetrievalService resultRetrievalService;
    @Mock
    private ManualReviewUpdateService manualReviewUpdateService;
    @Mock
    private AuthorizationService authorizationService;
    @Mock
    private AccountErrorCodesProp accountErrorCodesProp;
    @Mock
    private ClientRequestHeader clientRequestHeader;
    @Mock
    private RequestValidator requestValidator;

    private final String ENDPOINT = "/api/brokerage/accounts/series910/results";

    private MockMvc mockMvc;
    private HttpHeaders headers;
    private ObjectMapper mapper = new ObjectMapper();
    private Series910Response series910Response;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);

        headers = new HttpHeaders();
        headers.add(HeaderKeys.CLIENT_REQUEST, "{\"accountId\": 66578}");

        ManualReviewController manualReviewController = new ManualReviewController(
                mapper,
                resultRetrievalService,
                authorizationService,
                requestValidator,
                clientRequestHeader,
                manualReviewUpdateService);
        mockMvc = MockMvcBuilders
                .standaloneSetup(manualReviewController)
                .addPlaceholderValue("series910.endpoint.manual", ENDPOINT)
                .setControllerAdvice(new GlobalExceptionHandler(accountErrorCodesProp, "account-series910-review"))
                .build();
    }

    @Test
    public void validAccountIdReturnsOK() throws Exception {
        headers.add(HeaderKeys.CLIENT_REQUEST, "{\"accountId\": 1111}");
//        Series910Response series910Response = mapper.readValue(readFixture("/Responses/manualGetSuccessResponse.json"), Series910Response.class);
//        Mockito.when(resultRetrievalService.service(Matchers.any())).thenReturn(series910Response);
        headers.add("Schwab-Client-Request", "{\"accountId\": 1111}");
        Series910Response series910Response = mapper.readValue(ReadFixture.readFixture("/Responses/manualGetSuccessResponse.json"), Series910Response.class);
        Mockito.when(resultRetrievalService.service(Matchers.any())).thenReturn(series910Response);


        MvcResult result = mockMvc.perform(
                get(ENDPOINT)
                        .headers(headers)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk()).andReturn();
        Series910Response actual = mapper.readValue(result.getResponse().getContentAsString(), Series910Response.class);

        Assert.assertEquals("PASS", actual.getSeries910Results().get(0).getPassFailCode());
        Assert.assertEquals("AUTO", actual.getSeries910Results().get(0).getTriggerEventCode());
        Assert.assertEquals("SWISS", actual.getSeries910Results().get(0).getChannelName());
        Assert.assertEquals(new Integer("0"), actual.getReturnDetails().get(0).getReturnCode());
        Assert.assertEquals("", actual.getReturnDetails().get(0).getReturnMessage());
        Assert.assertEquals("account-series910-review", actual.getReturnDetails().get(0).getSource());
    }

    @Test
    public void invalidAccountIdExceptionReturns10401() throws Exception {

        Mockito.when(resultRetrievalService.service(Matchers.any())).thenThrow(new ResultsNotFoundException("No results found"));

        MvcResult result = mockMvc.perform(
                get(ENDPOINT)
                        .headers(headers))
                .andExpect(status().isBadRequest()).andReturn();
        Series910Response actual = mapper.readValue(result.getResponse().getContentAsString(), Series910Response.class);

        Assert.assertEquals(new Integer("10401"), actual.getReturnDetails().get(0).getReturnCode());
        Assert.assertEquals("No results found", actual.getReturnDetails().get(0).getReturnMessage());
        Assert.assertEquals("account-series910-review", actual.getReturnDetails().get(0).getSource());
    }

    @Test
    public void invalidHeaderReturns400() throws Exception {

        Mockito.doThrow(new BadRequestException("Test Response")).when(requestValidator).validateManualGetRequest(Matchers.any());


        MvcResult result = mockMvc.perform(
                get("/api/brokerage/accounts/series910/results")
                        .headers(headers))
                .andExpect(status().isBadRequest()).andReturn();
        Series910Response actual = mapper.readValue(result.getResponse().getContentAsString(), Series910Response.class);

        Assert.assertEquals(new Integer("400"), actual.getReturnDetails().get(0).getReturnCode());
        Assert.assertEquals("Test Response", actual.getReturnDetails().get(0).getReturnMessage());
        Assert.assertEquals("account-series910-review", actual.getReturnDetails().get(0).getSource());
    }


    @Test
    public void postInvalidResultCodesExceptionTest() throws Exception {
        String manualPostRequest = ReadFixture.readFixture("/ManualRequestValidateService/valid-manual-post-request-pass.json");


        Mockito.doThrow(new InvalidResultCodesException("Test Response")).when(requestValidator).validateManualPostRequest(Matchers.any());

        MvcResult result = mockMvc.perform(
                post("/api/brokerage/accounts/series910/results")
                        .headers(headers)
                        .content(manualPostRequest)
                        .contentType("application/json"))
                .andExpect(status().isBadRequest())
                .andReturn();
        Series910Response actual = mapper.readValue(result.getResponse().getContentAsString(), Series910Response.class);

        Assert.assertEquals(new Integer("11004"), actual.getReturnDetails().get(0).getReturnCode());
        Assert.assertEquals("Test Response", actual.getReturnDetails().get(0).getReturnMessage());
        Assert.assertEquals("account-series910-review", actual.getReturnDetails().get(0).getSource());
    }

    @Test
    public void postBadRequestExceptionTest() throws Exception {
        String manualPostRequest = ReadFixture.readFixture("/ManualRequestValidateService/valid-manual-post-request-pass.json");

        Mockito.doThrow(new BadRequestException("Test Response")).when(requestValidator).validateManualPostRequest(Matchers.any());

        MvcResult result = mockMvc.perform(
                post("/api/brokerage/accounts/series910/results")
                        .headers(headers)
                        .content(manualPostRequest)
                        .contentType("application/json"))
                .andExpect(status().isBadRequest())
                .andReturn();
        Series910Response actual = mapper.readValue(result.getResponse().getContentAsString(), Series910Response.class);

        Assert.assertEquals(new Integer("400"), actual.getReturnDetails().get(0).getReturnCode());
        Assert.assertEquals("Test Response", actual.getReturnDetails().get(0).getReturnMessage());
        Assert.assertEquals("account-series910-review", actual.getReturnDetails().get(0).getSource());
    }


}