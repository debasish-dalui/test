package com.schwab.brokerage.account.series910.review.adaptor.db2;

import com.schwab.brokerage.account.series910.review.adaptor.converter.Series910FailDb2Converter;
import com.schwab.brokerage.account.series910.review.dto.db2.AutoReviewResult;
import com.schwab.brokerage.account.series910.review.dto.db2.constraint.AutoReviewResultKey;
import com.schwab.brokerage.account.series910.review.model.response.Series910Result;
import com.schwab.brokerage.account.series910.review.repository.Series910ResultDb2Repository;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Sort;
import org.springframework.test.context.junit4.SpringRunner;

import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;

@RunWith(SpringRunner.class)
public class Series910ResultDb2AdaptorTest {
    @Mock
    private Series910ResultDb2Repository series910ResultDb2Repository;
    @Mock
    private Series910FailDb2Converter series910FailDb2Converter;
    @Mock
    private Sort autoReviewSort;

    private Series910ResultDb2Adaptor series910ResultDb2Adaptor;
    private AutoReviewResult autoReviewResult;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        series910ResultDb2Adaptor = new Series910ResultDb2Adaptor(
                series910ResultDb2Repository,
                series910FailDb2Converter,
                autoReviewSort
        );

        autoReviewResult = AutoReviewResult.builder()
                .primaryKey(AutoReviewResultKey.builder()
                        .accountId(1111)
                        .reviewDate(new Date(123123))
                        .reviewTime(new Time(123123))
                        .build())
                .channelName("channel")
                .passFailCode("FAIL")
                .triggerEventCode("AUTO")
                .auditUpdateUserId("USER")
                .auditUpdateTimestamp(new Timestamp(123123))
                .build();
    }

    @Test
    public void toResponse() {
        Mockito.when(series910FailDb2Converter.toResponse(Matchers.any()))
                .thenReturn(null);
        Series910Result expectedResult = Series910Result.builder()
                .reviewTimestamp(autoReviewResult.getPrimaryKey().getReviewTime().toLocalTime()
                        .atDate(autoReviewResult.getPrimaryKey().getReviewDate().toLocalDate()))
                .channelName(autoReviewResult.getChannelName())
                .passFailCode(autoReviewResult.getPassFailCode())
                .triggerEventCode(autoReviewResult.getTriggerEventCode())
                .auditUpdateUserId(autoReviewResult.getAuditUpdateUserId())
                .auditUpdateTimestamp(autoReviewResult.getAuditUpdateTimestamp().toLocalDateTime())
                .failReasons(series910FailDb2Converter.toResponses(autoReviewResult.getAutoReviewFails()))
                .build();
        Series910Result actualResult = series910ResultDb2Adaptor.toResponse(autoReviewResult);
        Assert.assertEquals(expectedResult, actualResult);
    }
}