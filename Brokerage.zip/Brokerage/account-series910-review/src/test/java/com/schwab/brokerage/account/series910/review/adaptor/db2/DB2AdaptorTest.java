package com.schwab.brokerage.account.series910.review.adaptor.db2;

import com.schwab.brokerage.account.series910.review.connector.DB2Connector;
import com.schwab.brokerage.account.series910.review.property.StoredProcParametersProp;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import static org.mockito.MockitoAnnotations.initMocks;
@RunWith(SpringRunner.class)
public class DB2AdaptorTest {
    @Mock
    private StoredProcParametersProp storedProcParametersProp;
    @Mock
    private DB2Connector db2Connector;

    private DB2Adaptor db2Adaptor;

    @Before
    public void setUp() throws Exception {
        initMocks(this);

        db2Adaptor = new DB2Adaptor(
                storedProcParametersProp,
                db2Connector
        );
    }

    @Test
    public void autoReviewResult() throws Exception {
        Map<String, Object> expectedResults = new HashMap<>();
        expectedResults.put("OUT_ADDRESS_ID", 1234567);
        expectedResults.put("OUT_RETURN_CODE", 0);
        expectedResults.put("OUT_RETURN_MESSAGE", "");

        Mockito.when(db2Connector.createAutoReviewResult(Matchers.any())).thenReturn(expectedResults);

        Map<String, Object> actualResults = db2Adaptor.saveAutoReviewResult(
                123123,
                "MYQ",
                "RETAIL",
                "AUTO",
                "USER",
                LocalDateTime.now(),
                "PASS",
                null,
                Collections.emptyList());

        Assert.assertEquals(expectedResults, actualResults);
        Mockito.verify(db2Connector, Mockito.times(1)).createAutoReviewResult(Matchers.any());
    }
}