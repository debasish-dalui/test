package com.schwab.brokerage.account.series910.review.adaptor.mongo;

import com.schwab.brokerage.account.series910.review.adaptor.converter.Series910FailMongoConverter;
import com.schwab.brokerage.account.series910.review.dto.mongo.Series910Audit;
import com.schwab.brokerage.account.series910.review.dto.mongo.Series910ResultMongo;
import com.schwab.brokerage.account.series910.review.model.FailReason;
import com.schwab.brokerage.account.series910.review.model.response.Series910Result;
import com.schwab.brokerage.account.series910.review.repository.Series910ResultMongoRepository;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.Sort;
import org.springframework.test.context.junit4.SpringRunner;
import java.util.ArrayList;

import java.time.LocalDateTime;
@RunWith(SpringRunner.class)
public class Series910ResultMongoAdaptorTest {
    @Mock
    private Series910ResultMongoRepository series910ResultMongoRepository;
    @Mock
    private Series910FailMongoConverter series910FailMongoAdaptor;
    @Mock
    private Sort series910ResultSortMongo;

    private Series910ResultMongoAdaptor series910ResultMongoAdaptor;
    private Series910ResultMongo series910ResultMongo;
    private LocalDateTime localDateTime;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        series910ResultMongoAdaptor = new Series910ResultMongoAdaptor(
                series910ResultMongoRepository,
                series910FailMongoAdaptor,
                series910ResultSortMongo
        );

        localDateTime = LocalDateTime.now();

        series910ResultMongo = Series910ResultMongo.builder()
                .audit(Series910Audit.builder()
                        .createdBy("TEST")
                        .lastUpdatedBy("TEST")
                        .creationDate(localDateTime)
                        .lastUpdateTimestamp(localDateTime)
                        .build())
                .channelName("MYQ")
                .passFailCode("FAIL")
                .triggerEventCode("AUTO")
                .build();
    }

    @Test
    public void toResponse() throws Exception {
        Mockito.when(series910FailMongoAdaptor.toResponse(Matchers.any())).thenReturn(FailReason.builder()
                .failReasonCode("IA")
                .failReasonText("TEST")
                .build());
        Series910Result actual = series910ResultMongoAdaptor.toResponse(series910ResultMongo);

        Series910Result expected = Series910Result.builder()
                .channelName("MYQ")
                .passFailCode("FAIL")
                .triggerEventCode("AUTO")
                .auditUpdateUserId("TEST")
                .reviewTimestamp(localDateTime)
                .auditUpdateTimestamp(localDateTime)
                .failReasons(new ArrayList<>())
                .build();

        Assert.assertEquals(expected, actual);


    }

}