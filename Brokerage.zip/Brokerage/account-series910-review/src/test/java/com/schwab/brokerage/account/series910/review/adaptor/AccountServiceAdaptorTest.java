package com.schwab.brokerage.account.series910.review.adaptor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.schwab.brokerage.account.series910.review.connector.AccountServiceConnector;
import com.schwab.brokerage.account.series910.review.model.Account;
import com.schwab.brokerage.account.series910.review.model.request.AccountServiceRequest;
import com.schwab.brokerage.account.series910.review.model.response.AccountCustRoleResponse;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.*;

import static test.ReadFixture.readFixture;
@RunWith(SpringRunner.class)
public class AccountServiceAdaptorTest {

    @Mock
    private HttpHeaders serviceHeaders;

    @Mock
    private AccountServiceConnector accountServiceConnector;

    private AccountServiceAdaptor accountServiceAdaptor;


    private Account account;
    private AccountServiceRequest accountServiceRequest;
    private ObjectMapper mapper = new ObjectMapper();
    private ResponseEntity<String> response;


    @Before
    public void init() throws Exception {
        MockitoAnnotations.initMocks(this);
        accountServiceRequest = AccountServiceRequest.builder().accountId(66578).build();
        accountServiceAdaptor = new AccountServiceAdaptor("", "", "", mapper, accountServiceConnector);
    }


    @Test
    public void validAccountReturnsDetails() throws Exception {
        String jsonResponse = readFixture("/AccountService/acctservice-validId-response.json");
        response = ResponseEntity
                .ok()
                .header("x-cat-envelope", "{\"Total\":0,\"Previouslink\":null,\"Nextlink\":null,\"CorrelationId\":\"e424b3fa-2794-46b7-b393-d0b2e2410340\",\"Code\":200,\"Message\":\"CATAPIServices\"}")
                .body(jsonResponse);
        Mockito.when(accountServiceConnector.sendRestRequest(
                Matchers.any(),
                Matchers.any(),
                Matchers.any()))
                .thenReturn(response);
        Account expected = Account
                .builder()
                .accountId(66578)
                .correlationId(UUID.fromString("e424b3fa-2794-46b7-b393-d0b2e2410340"))
                .passFailCode("FAIL")
                .accountProductCode("S3")
                .accountRegistrationCode("IN")
                .build();

        Account account = accountServiceAdaptor.retrieveAccountDetails(66578);

        Assert.assertEquals(expected, account);
    }

    @Test
    public void validCustRoleCallReturnsDetails() throws Exception {
        String responseBody = readFixture("/AccountService/acctservice-custrole-valid-response.json");
        response = ResponseEntity
                .ok()
                .body(responseBody);
        Mockito.when(accountServiceConnector.sendRestRequest(
                Matchers.any(),
                Matchers.any(),
                Matchers.any()))
                .thenReturn(response);
        AccountCustRoleResponse expected1 = new AccountCustRoleResponse(119772930, "TEN");
        AccountCustRoleResponse expected2 = new AccountCustRoleResponse(323678419, "BENE");
        AccountCustRoleResponse expected3 = new AccountCustRoleResponse(852518340, "TEN");
        List<AccountCustRoleResponse> expected = Arrays.asList(expected1, expected2, expected3);

        List<AccountCustRoleResponse> results = accountServiceAdaptor.retrieveAccountRoles(Account.builder().accountId(accountServiceRequest.getAccountId()).build());

        Assert.assertEquals(expected, results);
    }

    @Test
    public void noRestrictionsReturnsEmptySet() throws Exception {
        String responseBody = readFixture("/AccountService/acctservice-invalid-restrictions-response.json");
        response = ResponseEntity
                .ok()
                .body(responseBody);
        Mockito.when(accountServiceConnector.sendRestRequest(Matchers.any(), Matchers.any(), Matchers.any()))
                .thenReturn(response);
        Set<String> results = accountServiceAdaptor.retrieveAccountRestrictions(0);
        Assert.assertTrue(results.isEmpty());
    }

    @Test
    public void accountWithRestrictionsReturnsSet() throws Exception {
        String responseBody = readFixture("/AccountService/acctservice-valid-restrictions-response.json");
        response = ResponseEntity
                .ok()
                .body(responseBody);
        Mockito.when(accountServiceConnector.sendRestRequest(Matchers.any(), Matchers.any(), Matchers.any()))
                .thenReturn(response);
        Set<String> results = accountServiceAdaptor.retrieveAccountRestrictions(0);

        String[] codes = {"PENDING DOCS","PATRIOT ACT"};
        Set<String> expected = new HashSet<>(Arrays.asList(codes));
        Assert.assertEquals(expected, results);
    }
}
