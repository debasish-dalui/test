package com.schwab.brokerage.account.series910.review.adaptor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.schwab.brokerage.account.series910.review.connector.AccountAddressConnector;
import com.schwab.brokerage.account.series910.review.model.Account;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import test.ReadFixture;

@RunWith(SpringRunner.class)
public class AccountAddressAdaptorTest {

    @Mock
    private AccountAddressConnector accountAddressConnector;
    @Mock
    private HttpHeaders headers;
    private ObjectMapper objectMapper = new ObjectMapper();

    private AccountAddressAdaptor accountAddressAdaptor;

    @Before
    public void init() throws Exception {
        MockitoAnnotations.initMocks(this);
        accountAddressAdaptor = new AccountAddressAdaptor("", accountAddressConnector, objectMapper);
    }

    @Test
    public void validAccountCallGetsCountryCode() throws Exception {
        String jsonResponse = ReadFixture.readFixture("/AccountAddressService/acct-address-valid-output.json");
        ResponseEntity<String> response = ResponseEntity.ok().body(jsonResponse);
        Mockito.when(accountAddressConnector.sendRestRequest(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(response);

        Account account = Account.builder().accountId(1).build();
        Account result = Account.builder().accountId(1).build();
        result.setCountryCode(accountAddressAdaptor.getCountryCode(account.getAccountId()));

        account.setCountryCode("US");
        Assert.assertEquals(account, result);

    }
}
