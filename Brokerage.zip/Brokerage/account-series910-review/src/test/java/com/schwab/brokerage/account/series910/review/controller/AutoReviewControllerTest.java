package com.schwab.brokerage.account.series910.review.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.schwab.brokerage.account.series910.review.advice.GlobalExceptionHandler;
import com.schwab.brokerage.account.series910.review.constant.HeaderKeys;
import com.schwab.brokerage.account.series910.review.exception.BadRequestException;
import com.schwab.brokerage.account.series910.review.model.request.AutoReviewPostRequest;
import com.schwab.brokerage.account.series910.review.model.request.ClientRequestHeader;
import com.schwab.brokerage.account.series910.review.model.response.Series910Response;
import com.schwab.brokerage.account.series910.review.property.AccountErrorCodesProp;
import com.schwab.brokerage.account.series910.review.service.AuthorizationService;
import com.schwab.brokerage.account.series910.review.service.AutoReviewService;
import com.schwab.brokerage.account.series910.review.util.RequestValidator;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static test.ReadFixture.readFixture;
@RunWith(SpringRunner.class)
public class AutoReviewControllerTest {

    @Mock
    private AccountErrorCodesProp accountErrorCodesProp;

    @Mock
    private AutoReviewService autoReviewService;
    @Mock
    private AuthorizationService authorizationService;
    @Mock
    private ClientRequestHeader clientRequestHeader;
    @Mock
    private RequestValidator requestValidator;

    private final String ENDPOINT = "/api/brokerage/accounts/series910";
    private AutoReviewController autoReviewController;
    private ObjectMapper mapper = new ObjectMapper();
    private MockMvc mockMvc;
    private AutoReviewPostRequest autoReviewPostRequest;
    private HttpHeaders headers;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        headers = new HttpHeaders();
        headers.add(HeaderKeys.CLIENT_REQUEST, "{\"channel\": \"channel\", \"userId\": \"userId\"}");
        autoReviewController = new AutoReviewController(
                mapper,
                autoReviewService,
                authorizationService,
                clientRequestHeader,
                requestValidator);
        mockMvc = MockMvcBuilders
                .standaloneSetup(autoReviewController)
                .addPlaceholderValue("series910.endpoint.auto", ENDPOINT)
                .setControllerAdvice(new GlobalExceptionHandler(accountErrorCodesProp, "a"))
                .build();
    }

    @Test
    public void exceptionInAccountValidationShouldReturnBadRequest() throws Exception {
        autoReviewPostRequest = mapper.readValue(readFixture("/AutoPostInputs/valid-brokerageAccountId.json"), AutoReviewPostRequest.class);
        Mockito.doThrow(new BadRequestException(400, "test Message")).when(requestValidator).validateAutoReviewPostRequest(autoReviewPostRequest);

        MvcResult result = mockMvc.perform(
                post(ENDPOINT)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(autoReviewPostRequest))
                        .headers(headers))
                .andExpect(status().isBadRequest()).andReturn();
        Series910Response actual = mapper.readValue(result.getResponse().getContentAsString(), Series910Response.class);
        Assert.assertEquals(new Integer("400"), actual.getReturnDetails().get(0).getReturnCode());
        Assert.assertEquals("test Message", actual.getReturnDetails().get(0).getReturnMessage());
    }

    @Test
    public void validAcctIdShouldReturnOK() throws Exception {
        autoReviewPostRequest = mapper.readValue(readFixture("/AutoPostInputs/valid-brokerageAccountId.json"), AutoReviewPostRequest.class);
        Series910Response response = mapper.readValue(readFixture("/Responses/series910ResponseFAIL.json"), Series910Response.class);
        Mockito.when(autoReviewService.service(Matchers.any())).thenReturn(response);

        MvcResult result = mockMvc.perform(
                post(ENDPOINT)
                        .headers(headers)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(mapper.writeValueAsString(autoReviewPostRequest)))
                .andExpect(status().isOk()).andReturn();
        Series910Response actual = mapper.readValue(result.getResponse().getContentAsString(), Series910Response.class);

        Assert.assertEquals(new Integer("11000"), actual.getReturnDetails().get(0).getReturnCode());
        Assert.assertEquals("Account has failed Automated Series 9/10 Review!", actual.getReturnDetails().get(0).getReturnMessage());
    }
}
