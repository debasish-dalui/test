package com.schwab.brokerage.account.series910.review.adaptor;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.schwab.brokerage.account.series910.review.connector.CustomerServiceConnector;
import com.schwab.brokerage.account.series910.review.model.Citizenship;
import com.schwab.brokerage.account.series910.review.model.Customer;
import com.schwab.brokerage.account.series910.review.model.request.CustomerIdRequest;
import com.schwab.brokerage.account.series910.review.model.request.CustomerServiceRequest;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static test.ReadFixture.readFixture;

@RunWith(SpringRunner.class)
public class CustomerServiceAdaptorTest {

    @Mock
    private HttpHeaders customerServiceHeaders;
    @Mock
    private CustomerServiceConnector customerServiceConnector;

    private CustomerServiceAdaptor customerServiceAdaptor;


    private CustomerServiceRequest customerServiceRequest;
    private CustomerIdRequest customerIdRequest;
    private Customer customer;
    private ObjectMapper mapper = new ObjectMapper();
    private ResponseEntity<String> response;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        customerServiceAdaptor = new CustomerServiceAdaptor(
                "/party",
                "/details",
                "/employment",
                mapper,
                customerServiceConnector
        );
    }

    @Test
    public void validCustomerReturnDetails() throws Exception {
        List<Citizenship> citizenships = Arrays.asList(
                new Citizenship("US"),
                new Citizenship("VE")
        );
        customerServiceRequest = new CustomerServiceRequest(856568087);

        String jsonResponse = readFixture("/CustomerService/customer-id-valid-customer.json");
        response = ResponseEntity
                .ok()
                .body(jsonResponse);
        Mockito.when(customerServiceConnector.sendRestRequest(
                "/details",
                HttpMethod.POST,
                customerServiceRequest))
                .thenReturn(response);

        Customer expected = Customer
                .builder()
                .customerId(856568087)
                .taxPayerId("567172275")
                .countryOfResidence("US")
                .customerTypeCode("IND")
                .citizenships(citizenships)
                .build();

        Assert.assertEquals(expected, customerServiceAdaptor.retrieveCustomerDetails(856568087));
    }

    @Test
    public void validCustomerIdsReturn() throws Exception {

        customerIdRequest = new CustomerIdRequest("792573782");

        String jsonResponse = readFixture("/CustomerService/customer-taxPayerId-valid-customer.json");
        response = ResponseEntity
                .ok()
                .body(jsonResponse);
        Mockito.when(customerServiceConnector.sendRestRequest(
                "/party",
                HttpMethod.POST,
                customerIdRequest))
                .thenReturn(response);

        ArrayList<String> expected = new ArrayList<>();
        expected.add("000000664");

        Assert.assertEquals(expected, customerServiceAdaptor.retrieveCustomerIds("792573782"));
    }

}