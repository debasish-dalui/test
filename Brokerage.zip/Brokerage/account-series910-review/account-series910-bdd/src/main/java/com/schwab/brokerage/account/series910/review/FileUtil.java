package com.schwab.brokerage.account.series910.review;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Optional;

public class FileUtil {
    public static String readUrlFile(String url) throws IOException {
        try(InputStream inputStream = new URL(url).openConnection().getInputStream()) {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            Optional<String> file = bufferedReader.lines().reduce((s, s2) -> s + s2);
            if(!file.isPresent()) {
                throw new IOException("Data not found.");
            }
            return file.get();
        }
    }
}
