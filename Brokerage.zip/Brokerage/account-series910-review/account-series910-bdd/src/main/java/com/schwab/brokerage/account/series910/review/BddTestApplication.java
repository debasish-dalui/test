package com.schwab.brokerage.account.series910.review;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BddTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(BddTestApplication.class, args);
    }
}