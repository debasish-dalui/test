package com.schwab.brokerage.account.series910.review.config;

import com.mongodb.MongoClientURI;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;

import java.net.UnknownHostException;

@Configuration
public class DBConfig {
    private final ApplicationContext applicationContext;

    public DBConfig(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    @Bean
    public MongoClientURI mongoClientURI(@Value("${database.uri}") String uri) {
        return new MongoClientURI(uri);
    }

    @Bean
    public MongoDbFactory mongoDbFactory(MongoClientURI mongoClientURI) throws UnknownHostException {
        return new SimpleMongoDbFactory(mongoClientURI);
    }

    @Bean
    public MongoTemplate mongoTemplate(MongoDbFactory mongoDbFactory) {
        return new MongoTemplate(mongoDbFactory);
    }

    @Bean
    public Sort series910ResultSortMongo() {
        return new Sort(Sort.Direction.DESC, "reviewTimestamp");
    }
}
