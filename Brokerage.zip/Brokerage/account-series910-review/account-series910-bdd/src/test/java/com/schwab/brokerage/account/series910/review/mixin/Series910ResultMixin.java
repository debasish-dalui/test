package com.schwab.brokerage.account.series910.review.mixin;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.time.LocalDateTime;

public abstract class Series910ResultMixin {
    @JsonIgnore
    private LocalDateTime reviewTimestamp;

    @JsonIgnore
    private LocalDateTime auditUpdateTimestamp;
}
