package com.schwab.brokerage.account.series910.review;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;

@ContextConfiguration
@SpringBootTest(classes = {AccountSeries910ReviewApplication.class})
@ActiveProfiles({"bdd"})
public abstract class SpringTestExtender {
}
