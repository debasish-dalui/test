package com.schwab.brokerage.account.series910.review.definitions;

import com.schwab.brokerage.account.series910.review.SpringTestExtender;
import cucumber.api.PendingException;
import cucumber.api.java.en.But;
import cucumber.api.java.en.Given;
import org.springframework.beans.factory.annotation.Autowired;

public class GivenStepDroolsCustomerRules extends SpringTestExtender {
    @Autowired
    private World world;

    @Given("^there is a custodian role on the account with age less than (\\d+)$")
    public void there_is_a_custodian_role_on_the_account_with_age_less_than(int arg1) throws Throwable {
        world.setAccountId(35431438);
    }

    @Given("^there is a minor role on the account that is older than (\\d+)$")
    public void there_is_a_minor_role_on_the_account_that_is_older_than(int arg1) throws Throwable {
        world.setAccountId(95689096);
    }

    @Given("^there is a customer on the account that is a foreign citizen$")
    public void there_is_a_customer_on_the_account_that_is_a_foreign_citizen() throws Throwable {
        world.setAccountId(74771489);

    }

    @Given("^there is a customer on the account that is a foreign resident$")
    public void there_is_a_customer_on_the_account_that_is_a_foreign_resident() throws Throwable {
        world.setAccountId(96548630);

    }

    @Given("^it is an IRA account and there is a customer that is older than (\\d+)\\.(\\d+)$")
    public void it_is_an_IRA_account_and_there_is_a_customer_that_is_older_than(int arg1, int arg2) throws Throwable {
        world.setAccountId(2112);

    }

    @Given("^there is a customer on the account that is an organization$")
    public void there_is_a_customer_on_the_account_that_is_an_organization() throws Throwable {
        world.setAccountId(99692905);
    }

    @Given("^there is a customer on the account that is affiliated with a broker/dealer$")
    public void there_is_a_customer_on_the_account_that_is_affiliated_with_a_broker_dealer() throws Throwable {
        world.setAccountId(30705849);
    }

    @Given("^there is a customer with a Patriot Act restriction$")
    public void there_is_a_customer_with_a_Patriot_Act_restriction() throws Throwable {
        world.setAccountId(11824613);
    }

    @Given("^I have the following account id: \"([^\"]*)\"$")
    public void iHaveTheFollowingAccountIdAcct(Integer acctId) throws Throwable {
        world.setAccountId(acctId);
    }

    @But("^there is a customer with a Patriot Act restriction and is affiliated with a broker/dealer$")
    public void thereIsACustomerWithAPatriotActRestrictionAndIsAffiliatedWithABrokerDealer() throws Throwable {
        world.setAccountId(93036411);
    }

    //CHANGES NEED TO BE MADE TO THESE ACCOUNTS HERE!!!!!!
    @But("^it is an IRA account and there is a customer that is older than (\\d+)\\.(\\d+) and is a foreign citizen$")
    public void itIsAnIRAAccountAndThereIsACustomerThatIsOlderThanAndIsAForeignCitizen(int arg0, int arg1) throws Throwable {
        world.setAccountId(89344715);
    }

    @But("^it is an IRA account and there is a customer that is older than (\\d+)\\.(\\d+), a foreign citizen and is a customer with a Patriot Act restriction$")
    public void itIsAnIRAAccountAndThereIsACustomerThatIsOlderThanAForeignCitizenAndIsACustomerWithAPatriotActRestriction(int arg0, int arg1) throws Throwable {
        world.setAccountId(57603581);
    }

    @But("^it is an IRA account and there is a customer that is older than (\\d+)\\.(\\d+), a foreign citizen, and is affiliated with a broker/dealer$")
    public void itIsAnIRAAccountAndThereIsACustomerThatIsOlderThanAForeignCitizenAndIsAffiliatedWithABrokerDealer(int arg0, int arg1) throws Throwable {
        world.setAccountId(74083715);
    }

    @But("^it is an IRA account and there is a customer that is older than (\\d+)\\.(\\d+), a foreign citizen, has a Patriot Act restriction, and is affiliated with a broker/dealer$")
    public void itIsAnIRAAccountAndThereIsACustomerThatIsOlderThanAForeignCitizenHasAPatriotActRestrictionAndIsAffiliatedWithABrokerDealer(int arg0, int arg1) throws Throwable {
        world.setAccountId(43559212);
    }

    @But("^there is a minor role on the account that is older than (\\d+), a foreign citizen, and a foreign resident$")
    public void thereIsAMinorRoleOnTheAccountThatIsOlderThanAForeignCitizenAndAForeignResident(int arg0) throws Throwable {
        world.setAccountId(72756679);
    }

    @But("^there is a customer that has a non-US primary Citizenship and a US Secondary Citizenship$")
    public void thereIsACustomerThatHasANonUSPrimaryCitizenshipAndAUSSecondaryCitizenship() throws Throwable {
        world.setAccountId(55646100);
    }

    @But("^there is a customer that has a non-US primary citizenship, but a US Residency$")
    public void thereIsACustomerThatHasANonUSPrimaryCitizenshipButAUSResidency() throws Throwable {
        world.setAccountId(97344052);
    }

    @But("^there is a customer that has a US primary Citizenship and non-US Secondary Citizenship$")
    public void thereIsACustomerThatHasAUSPrimaryCitizenshipAndNonUSSecondaryCitizenship() throws Throwable {
        world.setAccountId(70118823);
    }

    @But("^there is a customer that is an organization and it has a Patriot Act Restriction$")
    public void theCustomerIsAnOrganizationAndItHasAPatriotActRestriction() throws Throwable {
        world.setAccountId(42318189);
    }
}
