package com.schwab.brokerage.account.series910.review.definitions;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.schwab.brokerage.account.series910.review.SpringTestExtender;
import com.schwab.brokerage.account.series910.review.config.TestConfig;
import com.schwab.brokerage.account.series910.review.constant.HeaderKeys;
import com.schwab.brokerage.account.series910.review.model.request.ManualPostRequest;
import cucumber.api.java.en.When;
import cucumber.runtime.CucumberException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;

import static org.springframework.http.HttpMethod.valueOf;

@Slf4j
public class RestRequestStep extends SpringTestExtender {
    @Autowired
    private World world;
    @Autowired
    private TestConfig testConfig;
    @Autowired
    private RestTemplate testRestTemplate;
    @Autowired
    private ObjectMapper objectMapper;

    @When("^I make a \"([^\"]*)\" request to the \"([^\"]*)\" endpoint$")
    public void iMakeARequestToTheEndpoint(String httpMethodString, String endpoint) throws Throwable {
        String url = (endpoint.equals("manual")) ? testConfig.getUriManual() : testConfig.getUriAuto();
//        String url = (endpoint.equals("manual")) ? "http://localhost:8080/api/brokerage/accounts/series910/results" : "http://localhost:8080/api/brokerage/accounts/series910";


        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.AUTHORIZATION, world.getAuth());
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));

        HttpMethod httpMethod = valueOf(httpMethodString);
        HttpEntity<?> request;
        switch (httpMethod) {
            case POST:
                headers.setContentType(MediaType.APPLICATION_JSON);
                headers.set(HeaderKeys.CLIENT_REQUEST, "{\"channel\":\"" + "MYQ" + "\",\"userId\":\"test\"}");
                ManualPostRequest manualPostRequest = ManualPostRequest.builder()
                        .brokerageAccountId(world.getAccountId())
                        .passFailCode(world.getPassFailCode())
                        .resultCode(world.getResultCodes())
                        .build();
                request = new HttpEntity<>(objectMapper.writeValueAsString(manualPostRequest), headers);
                break;
            case GET:
                headers.set(HeaderKeys.CLIENT_REQUEST, "{\"accountId\":" + world.getAccountId() + "}");
                request = new HttpEntity<>(headers);
                break;
            default:
                throw new CucumberException("Invalid parameter in feature file");
        }
        log.info("Request body: " + request.toString());
        world.setResponseEntity(testRestTemplate.exchange(url, httpMethod, request, String.class));
        log.info("Response Body = " + world.getResponseEntity().getBody());
    }
}
