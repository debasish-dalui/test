package com.schwab.brokerage.account.series910.review.config;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.schwab.brokerage.account.series910.review.exception.TestResponseErrorHandler;
import com.schwab.brokerage.account.series910.review.mixin.Series910ResultMixin;
import com.schwab.brokerage.account.series910.review.model.response.Series910Result;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpHeaders;
import org.springframework.web.client.RestTemplate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Configuration
@ConfigurationProperties(prefix = "test-series910")
@SuppressWarnings("unused")
public class TestConfig {
    private String uriAuto;
    private String uriManual;

    private String schwabClientHeader;

    @Bean
    @Primary
    public ObjectMapper objectMapper(ObjectMapper objectMapper) {
        return objectMapper
                .addMixIn(Series910Result.class, Series910ResultMixin.class)
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    @Bean
    public RestTemplate testRestTemplate(
            RestTemplateBuilder restTemplateBuilder, TestResponseErrorHandler testResponseErrorHandler
    ) {
        return restTemplateBuilder
                .errorHandler(testResponseErrorHandler)
                .build();
    }

    @Bean
    public HttpHeaders httpHeaders() {
        return new HttpHeaders();
    }
}
