package com.schwab.brokerage.account.series910.review.definitions;

import com.schwab.brokerage.account.series910.review.SpringTestExtender;
import com.schwab.brokerage.account.series910.review.dto.mongo.Series910ResultMongo;
import com.schwab.brokerage.account.series910.review.repo.Series910ResultRepository;
import cucumber.api.java.en.Then;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;

import java.util.List;

public class DatabaseStep extends SpringTestExtender {
    @Autowired
    private World world;
    @Autowired
    private Series910ResultRepository series910ResultRepository;
    @Autowired
    private Sort series910ResultSortMongo;

    @Then("^the result is saved in the database$")
    public void the_result_is_saved_in_the_database() throws Throwable {
        List<Series910ResultMongo> dbResults = series910ResultRepository.findByAccountId(
                series910ResultSortMongo,
                world.getAccountId());
        if (dbResults != null) {
            series910ResultRepository.delete(dbResults.get(0));
        }
        Assert.assertTrue(dbResults != null && dbResults.size() > 0);
    }
}
