package com.schwab.brokerage.account.series910.review.definitions;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.schwab.brokerage.account.series910.review.SpringTestExtender;
import com.schwab.brokerage.account.series910.review.config.CodeConfig;
import com.schwab.brokerage.account.series910.review.model.FailReason;
import com.schwab.brokerage.account.series910.review.model.response.Series910Response;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
public class ThenStep extends SpringTestExtender {
    @Autowired
    private World world;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private CodeConfig codeConfig;

    @Then("^I receive information about the accounts data$")
    public void i_receive_information_about_the_accounts_data() throws Throwable {
        Series910Response body = objectMapper.readValue(world.getResponseEntity().getBody(), Series910Response.class);
        Assert.assertTrue((body.getSeries910Results().size() > 0));
    }

    @Then("^I expect a response with an http status code of \"([^\"]*)\"$")
    public void i_expect_a_response_with_an_http_status_code_of(int expectedStatus) throws Throwable {
        log.info(world.getResponseEntity().getBody());
        Assert.assertEquals(expectedStatus, world.getResponseEntity().getStatusCode().value());
    }

    @Then("^I expect a return code of \"([^\"]*)\"$")
    public void i_expect_a_return_code_of(Integer expectedCode) throws Throwable {
        Series910Response body = objectMapper.readValue(world.getResponseEntity().getBody(), Series910Response.class);
        Assert.assertEquals(expectedCode, body.getReturnDetails().get(0).getReturnCode());
    }

    @And("^I expect a return message of \"([^\"]*)\"$")
    public void iExpectAReturnMessageOf(String expected) throws Throwable {
        Series910Response body = objectMapper.readValue(world.getResponseEntity().getBody(), Series910Response.class);
        Assert.assertEquals(expected, body.getReturnDetails().get(0).getReturnMessage());
    }

    @And("^I expect a result code of \"([^\"]*)\"$")
    public void iExpectAResultCodeOf(String expected) throws Throwable {
        Series910Response series910Response = objectMapper.readValue(
                world.getResponseEntity().getBody(),
                Series910Response.class);

        Set<String> requestReasonCodes = series910Response.getSeries910Results().get(0).getFailReasons().stream()
                .map(FailReason::getFailReasonCode)
                .collect(Collectors.toSet());
        Assert.assertTrue(requestReasonCodes.contains(expected));

    }

    @And("^I expect a result text of \"([^\"]*)\"$")
    public void iExpectAResultTextOf(String expected) throws Throwable {
        Series910Response series910Response = objectMapper.readValue(
                world.getResponseEntity().getBody(),
                Series910Response.class);

        Assert.assertEquals(
                expected,
                series910Response
                        .getSeries910Results().get(0)
                        .getFailReasons().get(0)
                        .getFailReasonText());
    }

    @Then("^I expect a response with an http status of \"([^\"]*)\"$")
    public void i_expect_a_response_with_an_http_status_of(String expected) throws Throwable {
        HttpStatus status = HttpStatus.valueOf(expected);
        Assert.assertEquals(status, world.getResponseEntity().getStatusCode());
    }

    @Then("^I expect the return to be \"([^\"]*)\"$")
    public void i_expect_the_error(String responseMsg) throws Throwable {
        responseMsg = responseMsg.replace("/", "").replace(" ", "-").toLowerCase();
        Integer expected = codeConfig.getReturnCodes().get(responseMsg);

        Series910Response series910Response = objectMapper.readValue(
                world.getResponseEntity().getBody(),
                Series910Response.class
        );

        Integer actual = series910Response.getReturnDetails().get(0).getReturnCode();
        Assert.assertEquals(expected, actual);
    }

    @Then("^I expect a reason of \"([^\"]*)\"$")
    public void i_expect_a_reason_of(String reason) throws Throwable {
        reason = reason.replace("/", "").replace(" ", "-").toLowerCase();
        String code = codeConfig.getResultCodes().get(reason);
        Series910Response series910Response = objectMapper.readValue(
                world.getResponseEntity().getBody(),
                Series910Response.class);

        Set<String> requestReasonCodes = series910Response.getSeries910Results().get(0).getFailReasons().stream()
                .map(FailReason::getFailReasonCode)
                .collect(Collectors.toSet());
        Assert.assertTrue(requestReasonCodes.contains(code));

    }
}
