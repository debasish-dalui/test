package com.schwab.brokerage.account.series910.review.definitions;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.schwab.brokerage.account.series910.review.SpringTestExtender;
import com.schwab.brokerage.account.series910.review.config.TestConfig;
import com.schwab.brokerage.account.series910.review.util.TokenGenerator;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.But;
import cucumber.api.java.en.Given;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Arrays;

@SuppressWarnings("unused")
public class GivenStep extends SpringTestExtender {
    @Autowired
    private World world;
    @Autowired
    private TestConfig testConfig;
    @Autowired
    private TokenGenerator tokenUtil;
    @Autowired
    private ObjectMapper objectMapper;

    @Before
    public void setup() {
        world.setAuth(tokenUtil.getToken());
    }

    @Given("^I have a \"([^\"]*)\" account number$")
    public void i_have_an_account_number(String isValid) throws Throwable {
        world.setAccountId(7997005);
        if (isValid.equals("invalid")) {
            world.setAccountId(1);
        }
    }

    @Given("^I have an invalid System SAML token")
    public void i_have_a_saml_token() throws Throwable {
        world.setAuth("SAML invalid");
    }

    @Given("^it has already been processed by 9/10 rules$")
    public void it_has_already_been_processed_by_rules() throws Throwable {
        world.setAccountId(7997660);
    }

    @Given("There are no valid Series 9-10 roles on it")
    public void thereAreNoValidSeries910RolesOnIt() throws Throwable {
        world.setAccountId(97486371);
    }

    @Given("^registration type and product type do not correspond$")
    public void registration_type_and_product_type_do_not_correspond() throws Throwable {
        world.setAccountId(1000497);
    }

    @But("^the account has no customers$")
    public void theAccountHasNoCustomer() throws Throwable {
        world.setAccountId(513213);
    }

    @But("^the account has no customer details$")
    public void theAccountHasNoCustomerDetails() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        world.setAccountId(513213);
    }

    @Given("^I have an account number for an account that \"([^\"]*)\" in the database$")
    public void i_have_an_account_number_for_an_account_that_in_the_database(String arg1) throws Throwable {
        switch (arg1) {
            case "is":
                world.setAccountId(111);
                break;
            case "is not":
                world.setAccountId(3);
                break;
            default:
                throw new Exception();
        }
    }

    @Given("^it has already been manually reviewed$")
    public void it_has_already_been_manually_reviewed() throws Throwable {
        world.setAccountId(1111);
    }

    @And("^I want to \"([^\"]*)\" the review with the following codes \"([^\"]*)\"$")
    public void iWantToTheReviewWithTheFollowingCodes(String passFailCode, String resultCodeStr) throws Throwable {
        world.setPassFailCode(passFailCode);
        world.setResultCodes(Arrays.asList(StringUtils.split(resultCodeStr, ",")));
    }

    @Given("^I have the channel set to \"([^\"]*)\"$")
    public void iHaveTheChannelSetTo(String channel) throws Throwable {
        world.setChannel(channel);
    }


    @Given("^There are no customers on it$")
    public void thereAreNoCustomersOnIt() throws Throwable {
        world.setAccountId(13503);
    }

    @But("^There are no details for a customer on it$")
    public void thereAreNoDetailsForACustomerOnIt() throws Throwable {
        world.setAccountId(2336019);
    }

    //    TODO: NEED NEW ACCOUNT ID FOR THIS METHOD
    @But("^there is a foreign country code for the mailing address$")
    public void thereIsAForeignCountryCodeForTheMailingAddress() throws Throwable {
        world.setAccountId(78243650);
    }

    //TODO: NEED NEW ACCOUNT FOR THIS
    @But("^There are no customer Id's associated with the taxpayer Id$")
    public void thereAreNoCustomerIdSAssociatedWithTheTaxpayerId() throws Throwable {
        world.setAccountId(2336019);
    }
}