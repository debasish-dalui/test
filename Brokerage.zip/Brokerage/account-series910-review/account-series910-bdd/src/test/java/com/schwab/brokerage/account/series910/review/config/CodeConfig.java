package com.schwab.brokerage.account.series910.review.config;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Configuration
@ConfigurationProperties
@SuppressWarnings("unused")
public class CodeConfig {
    private Map<String, String> resultCodes;
    private Map<String, Integer> returnCodes;

    @Bean
    Map<String, String> resultCodes() {
        return resultCodes;
    }

    @Bean
    Map<String, Integer> returnCodes() {
        return returnCodes;
    }
}
