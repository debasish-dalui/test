package com.schwab.brokerage.account.series910.review.definitions;

import lombok.Data;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.List;

@Data
@Component
public class World {
    private String samlToken;
    private Integer accountId;
    private String passFailCode;
    private List<String> resultCodes;
    private String auth;
    private String userId;
    private String channel;
    private ResponseEntity<String> responseEntity;
}
