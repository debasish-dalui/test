package com.schwab.brokerage.account.series910.review;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/resources/features",
        format = {"pretty", "html:report"},
        tags = {"~@ScenOutline" },
        glue = "com/schwab/brokerage/account/series910/review/definitions"
)
public class CucumberTestRunner {
}