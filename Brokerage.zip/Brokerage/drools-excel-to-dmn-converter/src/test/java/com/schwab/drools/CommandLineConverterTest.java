/*
 * Copyright (c) 2017, Charles Schwab and/or its affiliates. All rights reserved.
 */

package com.schwab.drools;

import org.junit.Test;

import com.schwab.drools.cli.CommandLineConverter;

public class CommandLineConverterTest {

	@Test
	public void testMain() {
		String[] args = new String[4]; 
		//String[] args = new String[] {"--inputs Registration Type, Registration Type, Registration Subtype, Legal Address Country, Citizenship Country, Residence Country, Client Type", "--outputs Auto Review Status", 
		//	 "C:/dev/code/ACS/Brokerage/drools-excel-to-dmn-converter/src/main/resources/com/schwab/drools/Series910PoC_v2.0.xlsx", "C:/dev/code/ACS/Brokerage/drools-excel-to-dmn-converter/src/main/resources/com/schwab/drools/Series910PoC-v2.0.dmn"};
		args[0] = "--inputs Registration Type, Registration Type, Registration Subtype, Legal Address Country, Citizenship Country, Residence Country, Client Type";
		args[1] = "--outputs Auto Review Status";
		args[2] = "C:/dev/code/ACS/Brokerage/drools-excel-to-dmn-converter/src/main/resources/com/schwab/drools/Series910PoC_v3.0.xlsx";
		args[3] = "C:/dev/code/ACS/Brokerage/drools-excel-to-dmn-converter/src/main/resources/com/schwab/drools/Series910PoC-v3.0.dmn";
		
		CommandLineConverter.main(args);
	}
	
}
