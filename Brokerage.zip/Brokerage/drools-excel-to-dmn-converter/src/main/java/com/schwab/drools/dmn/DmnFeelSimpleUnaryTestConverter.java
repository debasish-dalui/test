/* Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.schwab.drools.dmn;

import com.schwab.drools.xlsx.XlsxWorksheetContextReader;
import com.schwab.drools.xlsx.elements.CellContentHandler;
import org.xlsx4j.sml.Cell;
import org.xlsx4j.sml.STCellType;

/**
 * @author Debasish Dalui
 *
 */
public class DmnFeelSimpleUnaryTestConverter implements CellContentHandler {

	public boolean canConvert(Cell cell, XlsxWorksheetContextReader context) {
		if (!STCellType.S.equals(cell.getT())) {
			return false;
		}

		String rawContent = context.resolveCellValue(cell);
		return rawContent.startsWith(">") || rawContent.startsWith("<");
	}

	public String convert(Cell cell, XlsxWorksheetContextReader context) {
		return context.resolveCellValue(cell);
	}
}
