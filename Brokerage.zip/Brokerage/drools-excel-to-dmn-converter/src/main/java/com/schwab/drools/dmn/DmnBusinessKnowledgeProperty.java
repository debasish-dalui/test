package com.schwab.drools.dmn;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DmnBusinessKnowledgeProperty {

	private String name;
	private String category;
	private String orientation;

	/**
	 * ENum :: BusinessKnowledgeType
	 * 
	 */
	public enum BusinessKnowledgeType {
		DECISION_TABLE("decision table"), BOX_EXPRESSION("box expression"), LOGIC_EXPRESSION("logic expression");

		private final String type;

		private BusinessKnowledgeType(String value) {
			type = value;
		}

		@Override
		public String toString() {
			return type;
		}
	}

	/**
	 * ENum :: DecisionTableOrientation
	 * 
	 */
	public enum DecisionTableOrientation {
		HORIZONTAL("horizontal"), VERTICAL("vertical"), CROSSTAB("crosstab");

		private final String type;

		private DecisionTableOrientation(String value) {
			type = value;
		}

		@Override
		public String toString() {
			return type;
		}
	}

}
