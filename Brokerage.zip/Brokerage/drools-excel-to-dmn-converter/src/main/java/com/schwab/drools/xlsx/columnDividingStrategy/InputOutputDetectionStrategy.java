
package com.schwab.drools.xlsx.columnDividingStrategy;

import com.schwab.drools.xlsx.XlsxWorksheetContextReader;
import com.schwab.drools.xlsx.elements.EncapsulatedLogicInfo;
import com.schwab.drools.xlsx.elements.IndexedRow;

public interface InputOutputDetectionStrategy {

	EncapsulatedLogicInfo determineHeaderCells(IndexedRow headerRow, IndexedRow propertyRow, XlsxWorksheetContextReader worksheetContexts);
}
