/*
 * Copyright (c) 2017, Charles Schwab and/or its affiliates. All rights reserved.
 */
package com.schwab.drools.dmn;

import com.schwab.drools.xlsx.XlsxWorksheetContextReader;
import com.schwab.drools.xlsx.elements.InputOutputColumns;

import lombok.Data;

/**
 * @author debasish.dalui
 *
 */
@Data
public abstract class DmnDecisionTable {

	protected String name;
	protected XlsxWorksheetContextReader xlsContext;
	protected InputOutputColumns inputOutputColumns;
	
	/**
	 * Constructor
	 */
	public DmnDecisionTable( String name, XlsxWorksheetContextReader xlsContext) {
		this.name = name;
		this.xlsContext = xlsContext;
	}
	
}