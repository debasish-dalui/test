
package com.schwab.drools.xlsx.elements;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.xlsx4j.sml.CTRst;
import org.xlsx4j.sml.CTSst;
import org.xlsx4j.sml.Cell;
import org.xlsx4j.sml.STCellType;

import lombok.Data;

@Data
public class IndexedCell {

	public static final Pattern CELL_REF_PATTERN = Pattern.compile("([A-Z]+)([0-9]+)");

	protected CTSst sharedStrings;
	protected Cell cell;
	protected String column;
	protected int row;
	protected boolean cliAttr;
	protected boolean inferredAttr;

	public IndexedCell(Cell cell, CTSst sharedStrings) {
		this.sharedStrings = sharedStrings;
		this.cell = cell;
		
		String cellReference = cell.getR();
		Matcher matcher = CELL_REF_PATTERN.matcher(cellReference);

		boolean matches = matcher.matches();
		if (!matches) {
			throw new RuntimeException("Cannot parse cell reference " + cellReference);
		}

		column = matcher.group(1);
		row = Integer.parseInt(matcher.group(2));
	}

    public String resolveSharedString(int index) {
        List<CTRst> siElements = sharedStrings.getSi();
        return siElements.get(index).getT().getValue();
    }

    public String resolveCellValue(Cell cell) {
        STCellType cellType = cell.getT();
        if (STCellType.S.equals(cellType)) {
            int sharedStringIndex = Integer.parseInt(cell.getV());
            //System.out.println("The sharedStringIndex: " +sharedStringIndex);
            return resolveSharedString(sharedStringIndex);
        }
        else {
            return cell.getV();
        }
    }

}
