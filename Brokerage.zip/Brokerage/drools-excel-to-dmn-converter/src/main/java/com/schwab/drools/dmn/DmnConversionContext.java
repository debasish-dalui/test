package com.schwab.drools.dmn;

import com.schwab.drools.xlsx.XlsxWorksheetContextReader;
import com.schwab.drools.xlsx.elements.CellContentHandler;
import com.schwab.drools.xlsx.elements.IndexedDmnColumns;
import org.xlsx4j.sml.Cell;

import java.util.ArrayList;
import java.util.List;

public class DmnConversionContext {

	private List<CellContentHandler> cellContentHandlers = new ArrayList<CellContentHandler>();
	private XlsxWorksheetContextReader worksheetContext;
	private IndexedDmnColumns indexedDmnColumns = new IndexedDmnColumns();

	public DmnConversionContext(XlsxWorksheetContextReader worksheetContext) {
		this.worksheetContext = worksheetContext;
	}

	public String resolveCellValue(Cell cell) {
		for (CellContentHandler contentHandler : cellContentHandlers) {
			if (contentHandler.canConvert(cell, worksheetContext)) {
				return contentHandler.convert(cell, worksheetContext);
			}
		}
		throw new RuntimeException("cannot parse cell content, unsupported format");
	}

	public void addCellContentHandler(CellContentHandler cellContentHandler) {
		this.cellContentHandlers.add(cellContentHandler);
	}

	public IndexedDmnColumns getIndexedDmnColumns() {
		return indexedDmnColumns;
	}

}
