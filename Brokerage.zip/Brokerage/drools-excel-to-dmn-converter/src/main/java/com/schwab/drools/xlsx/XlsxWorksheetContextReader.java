package com.schwab.drools.xlsx;

import com.schwab.drools.xlsx.elements.CellContentHandler;
import com.schwab.drools.xlsx.elements.IndexedRow;
import org.xlsx4j.sml.*;

import java.util.ArrayList;
import java.util.List;

public class XlsxWorksheetContextReader {

    protected List<CellContentHandler> cellContentHandlers;
    protected CTSst sharedStrings;
    protected Worksheet worksheet;
    protected String worksheetName;

    // cached state
    protected List<IndexedRow> indexedRows;

    public XlsxWorksheetContextReader(CTSst sharedStrings, Worksheet worksheet, String worksheetName) {
        this.sharedStrings = sharedStrings;
        this.worksheet = worksheet;
        this.cellContentHandlers = new ArrayList<CellContentHandler>();
        this.worksheetName = worksheetName;
    }

    public List<IndexedRow> getRows() {
        if (indexedRows == null) {
            indexedRows = new ArrayList<IndexedRow>();
            for (Row row : worksheet.getSheetData().getRow()) {
                indexedRows.add(new IndexedRow(row, sharedStrings));
            }
        }
        return indexedRows;
    }

    public String getWorksheetName() {
        return worksheetName;
    }
}
