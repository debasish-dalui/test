package com.schwab.drools.xlsx.elements;

import org.xlsx4j.sml.Cell;

import com.schwab.drools.xlsx.XlsxWorksheetContextReader;

public interface CellContentHandler {

  boolean canConvert(Cell cell, XlsxWorksheetContextReader context);

  String convert(Cell cell, XlsxWorksheetContextReader context);

}
