package com.schwab.drools.dmn;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DmnDecisionTableIOProperty {
	private String boundary;
	private String type;
	private String defaultvalue;
	private String comparison;
}
