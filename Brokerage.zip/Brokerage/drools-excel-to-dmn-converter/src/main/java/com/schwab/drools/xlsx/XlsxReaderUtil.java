package com.schwab.drools.xlsx;

import lombok.extern.slf4j.Slf4j;
import org.docx4j.docProps.extended.Properties;
import org.docx4j.openpackaging.exceptions.Docx4JException;
import org.docx4j.openpackaging.packages.SpreadsheetMLPackage;
import org.docx4j.openpackaging.parts.SpreadsheetML.SharedStrings;
import org.docx4j.openpackaging.parts.SpreadsheetML.WorkbookPart;
import org.docx4j.openpackaging.parts.SpreadsheetML.WorksheetPart;
import org.kie.dmn.model.v1_1.Definitions;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

// TODO: exception when no worksheet present
// TODO: make worksheet number configurable/import all worksheets?
@Slf4j
public class XlsxReaderUtil {
    private List<XlsxWorksheetContextReader> worksheetContextList;

    public XlsxReaderUtil() {
        worksheetContextList = new ArrayList<>();
    }

    public Definitions convert(InputStream inputStream, String name, Set<String> inputs, Set<String> outputs) {
        SpreadsheetMLPackage spreadSheetPackage;
        try {
            spreadSheetPackage = (SpreadsheetMLPackage) SpreadsheetMLPackage.load(inputStream);
        } catch (Docx4JException e) {
            log.error("Could not load the spreadsheets into the program.");
            throw new RuntimeException("cannot load document", e);
        }

        WorkbookPart workbookPart = spreadSheetPackage.getWorkbookPart();
        XlsxWorksheetContextReader worksheetContextReader;
        WorksheetPart worksheetPart;
        try {
            for (int i = 0; i < workbookPart.getContents().getSheets().getSheet().size(); i++) {
                Properties properties = spreadSheetPackage.getDocPropsExtendedPart().getContents();
                worksheetPart = workbookPart.getWorksheet(i);
                SharedStrings sharedStrings = workbookPart.getSharedStrings();

                String worksheetName = (String) properties.getTitlesOfParts().getVector()
                        .getVariantOrI1OrI2().get(i).getValue();
                worksheetContextReader = new XlsxWorksheetContextReader(sharedStrings.getContents(),
                        worksheetPart.getContents(),
                        worksheetName);
                log.info("Added the Worksheet [" + worksheetName + "] to the list of decisions to be made.");
                worksheetContextList.add(worksheetContextReader);
            }
        } catch (Exception exception) {
            throw new RuntimeException("Could not determine worksheet", exception);
        }
        return new XlsxDmnConverterHelper(worksheetContextList, name, inputs, outputs).convert();
    }
}