/*
 * Copyright (c) 2017, Charles Schwab and/or its affiliates. All rights reserved.
 */
package com.schwab.drools.dmn;

import java.util.List;
import java.util.Set;

import org.kie.dmn.model.v1_1.DMNElementReference;
import org.kie.dmn.model.v1_1.Decision;
import org.kie.dmn.model.v1_1.InformationRequirement;

import com.schwab.drools.util.DmnAttributeValueFormatter;
import com.schwab.drools.xlsx.XlsxWorksheetContextReader;
import com.schwab.drools.xlsx.columnDividingStrategy.DecisionTableInputOutputDetectionStrategy;

/**
 * @author debasish.dalui
 *
 */
public class DmnDecisionTableHoriOri extends DmnDecisionTable {

	/**
	 * Constructor
	 */
	public DmnDecisionTableHoriOri(String name, XlsxWorksheetContextReader xlsContext, Set<String> inputsFromCLI,
			Set<String> outputsFromCLI) {
		super(name, xlsContext);
		
		this.inputOutputColumns = new DecisionTableInputOutputDetectionStrategy().determineHeaderCells(xlsContext,
				inputsFromCLI, outputsFromCLI);
		
	}	

}