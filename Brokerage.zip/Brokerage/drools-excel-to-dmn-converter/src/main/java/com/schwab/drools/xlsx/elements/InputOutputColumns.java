package com.schwab.drools.xlsx.elements;

import com.google.gson.Gson;
import com.schwab.drools.dmn.DmnDecisionTableIOProperty;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InputOutputColumns {

	protected List<IndexedCell> inputHeaderCells;
	protected List<IndexedCell> outputHeaderCells;
	
	protected List<String> inputHeaderCellValues;
	protected List<String> outputHeaderCellValues;
	protected Map<String, DmnDecisionTableIOProperty> propertyCellValues;

	public InputOutputColumns() {
		this.inputHeaderCells = new ArrayList<IndexedCell>();
		this.outputHeaderCells = new ArrayList<IndexedCell>();
		this.inputHeaderCellValues = new ArrayList<String>();
		this.outputHeaderCellValues = new ArrayList<String>();
		this.propertyCellValues = new HashMap<String, DmnDecisionTableIOProperty>();
	}

	public void addOutputHeaderCell(IndexedCell cell) {
		this.outputHeaderCells.add(cell);
	}

	public void addInputHeaderCell(IndexedCell cell) {
		this.inputHeaderCells.add(cell);
	}
	
	public void addinputHeaderCellValues(String cellValue) {
		this.inputHeaderCellValues.add(cellValue);
	}
	
	public void addOutputHeaderCellValues(String cellValue) {
		this.outputHeaderCellValues.add(cellValue);
	}

	//POSSIBLE CHANGES HERE???
	public void addPropertyCellValues(String headerValue, String propertyAsJson) {
		final Gson gson = new Gson();
		DmnDecisionTableIOProperty ioProperty = gson.fromJson(propertyAsJson, DmnDecisionTableIOProperty.class);
		this.propertyCellValues.put(headerValue, ioProperty);
	}

	public List<IndexedCell> getOutputHeaderCells() {
		return outputHeaderCells;
	}

	public List<IndexedCell> getInputHeaderCells() {
		return inputHeaderCells;
	}

	public List<String> getInputHeaderCellValues() {
		return inputHeaderCellValues;
	}

	public List<String> getOutputHeaderCellValues() {
		return outputHeaderCellValues;
	}

	public DmnDecisionTableIOProperty getPropertyCellValues(String headerValue) {
		return propertyCellValues.get(headerValue);
	}
	
}
