/*
 * Copyright (c) 2017, Charles Schwab and/or its affiliates. All rights reserved.
 */
package com.schwab.drools.dmn;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.kie.dmn.model.v1_1.DRGElement;
import org.kie.dmn.model.v1_1.Definitions;

import com.schwab.drools.util.DmnAttributeValueFormatter;
import com.schwab.drools.xlsx.XlsxWorksheetContextReader;
import com.schwab.drools.xlsx.elements.IndexedCell;
import com.schwab.drools.xlsx.elements.InputOutputColumns;

/**
 * @author debasish.dalui
 *
 */
public class DmnDefinitions extends Definitions {

	// input from CLI
	protected Set<String> inputs;

	// output from CLI
	protected Set<String> outputs;
	
	// decisions with io columns
	//protected List<DmnDecision> dmnDecisions;

	public DmnDefinitions(String name, Set<String> inputs, Set<String> outputs) {
		super();

		setNamespace("https://www.drools.org/kie-dmn");
		getNsContext().put("feel", "http://www.omg.org/spec/FEEL/20140401");
		setId(DmnAttributeValueFormatter.dmnFormattedIdNamingStandard(name));
		setName(name);

		this.inputs = inputs;
		this.outputs = outputs;
		//this.dmnDecisions = new ArrayList<DmnDecision>();
	}

	/**
	 * DMN Input Data Section By default considering all input typeRef as
	 * feel:string type and we may need to scope this with more variable type
	 * 
	 * @param drgElements
	 */
	public void deriveInputDatas() {
		List<DRGElement> drgElements = getDrgElement();
		Iterator<String> itr = inputs.iterator();

		while (itr.hasNext()) {
			drgElements.add(DmnInputData.initialize(itr.next(), "feel:string"));
		}
	}

	/**
	 * Map io-columns to specific decision
	 * 
	 * @param name
	 * @param xlsContext
	 */
	public void addDecision(XlsxWorksheetContextReader xlsContext) {
		DmnDecision dmnDecision = new DmnDecision();
		dmnDecision.addDecision(xlsContext, this.inputs, this.outputs);
		
		//this.dmnDecisions.add(dmnDecision); // need this?
		getDrgElement().add(dmnDecision);
	}
	
	/**
	 * Tells how decisions are related to each other.
	 * TODO: May be in future, need to get those from Visio DRG 
	 */
	public void updateCrossDecisionRelation( DmnDecision dmnDecision ) {
		
		System.out.println("Identifying the infer-attributes...............................");
		String decisionName = dmnDecision.getName();
		System.out.println("decisionName: " + decisionName);
		InputOutputColumns ioColumns = dmnDecision.getKnowledgeRequirementAsDecisionTable().getInputOutputColumns();

		for (IndexedCell ihCells : ioColumns.getInputHeaderCells()) {

			// inputs except than cli-inputs or so called inferred/derived ones
			if (!ihCells.isCliAttr()) {
				String ioCellValue = ihCells.resolveCellValue(ihCells.getCell());
				System.out.println("--> 1. Decisions [" + decisionName + "], Input: [" + ioCellValue + "]");

				for (DRGElement drgElement : getDrgElement()) {
					if (drgElement instanceof DmnDecision) {
						DmnDecision dmnDecisionToCompare = (DmnDecision) drgElement;
						String decisionNameToCompare = dmnDecisionToCompare.getName();
						System.out.println("decisionNameToCompare: " + decisionNameToCompare);
						InputOutputColumns ioColumns2 = dmnDecisionToCompare.getKnowledgeRequirementAsDecisionTable()
								.getInputOutputColumns();

						for (IndexedCell ohCells : ioColumns2.getOutputHeaderCells()) {
							if (ioCellValue.equals(ohCells.resolveCellValue(ohCells.getCell()))) { // matched
								dmnDecision.handleInferredAttributes(ioCellValue);
							}
						}
					}
				}
			}
		}
		
		/*
		// iterate each decisions
		for (Map.Entry<String, InputOutputColumns> decisionItr1 : decisionsWithInputOutputColumns.entrySet()) {
			String decisionName = decisionItr1.getKey();
			System.out.println("decisionName: " + decisionName);
			InputOutputColumns inputOutputColumns = decisionItr1.getValue();

			// list of inputs
			List<String> inputHeaderCellValues = inputOutputColumns.getInputHeaderCellValues();

			for (String inputCellValue : inputHeaderCellValues) {
				
				// inputs except than cli-inputs or so called inferred/derived ones
				if (!this.inputs.contains(inputCellValue)) {
					//System.out.println("--> 1. Decisions ["+ decisionName +"], Input: ["+ inputCellValue +"]");
					
					// figure out from which decisions it has derived
					for (Map.Entry<String, InputOutputColumns> decisionItr2 : decisionsWithInputOutputColumns.entrySet()) {
						String decisionNameForCompare = decisionItr2.getKey();
						InputOutputColumns ioColumns = decisionItr2.getValue();
						
						List<String> outputHeaderCellValues = ioColumns.getOutputHeaderCellValues();
						for (String outputCellValue : outputHeaderCellValues) {
							if (inputCellValue.contains(outputCellValue)) { //matched
								//System.out.println("------------------ Matched ---------------");
								//System.out.println("--> Decisions ["+decisionName+"], Input: [" + inputCellValue +"]");
								//System.out.println("--> Decisions ["+decisionNameForCompare+"], Output: [" + outputCellValue +"]");
								
								addDecisionRelations(decisionName, decisionNameForCompare, outputCellValue);
							}
						}						
					}
				}
				else {
					// add to cli-column entries for the decision
					addDecisionsWithCliColumns(decisionName, inputCellValue);
				}
			}
		}*/
		System.out.println("*********************************************************************************");
	}

}
