package com.schwab.drools.xlsx;

import com.schwab.drools.dmn.*;
import com.schwab.drools.util.DmnAttributeValueFormatter;
import com.schwab.drools.xlsx.columnDividingStrategy.InputOutputDetectionStrategy;
import com.schwab.drools.xlsx.columnDividingStrategy.BizKnowledgeElementDetectionStrategy;
import com.schwab.drools.xlsx.columnDividingStrategy.DecisionTableInputOutputDetectionStrategy;
import com.schwab.drools.xlsx.elements.EncapsulatedLogicInfo;
import com.schwab.drools.xlsx.elements.IndexedCell;
import com.schwab.drools.xlsx.elements.IndexedDmnColumns;
import com.schwab.drools.xlsx.elements.IndexedRow;
import com.schwab.drools.xlsx.elements.InputOutputColumns;
import lombok.extern.slf4j.Slf4j;
import org.kie.dmn.model.v1_1.*;

import javax.xml.namespace.QName;
import java.util.*;
import java.util.List;

@Slf4j
public class XlsxDmnConverterHelper {

    protected List<XlsxWorksheetContextReader> worksheetContextList;
    
    protected DmnDefinitions dmnDefinitions;
    protected final static String UNDERSCORE = "_";
    protected final static String SPACE = "\\s+";
    protected final static String EMPTYSPACE = "";

	public XlsxDmnConverterHelper(List<XlsxWorksheetContextReader> worksheetContextList, String name,
			Set<String> inputs, Set<String> outputs) {
		this.worksheetContextList = worksheetContextList;
		this.dmnDefinitions = new DmnDefinitions(name, inputs, outputs);
	}

    public DmnDefinitions convert() {
        // Step 1: initialize the empty definitions
     	
        // Step 2: add InputData(s) to definitions
        dmnDefinitions.deriveInputDatas();

        // initialize DRG model, considering the inputs and outputs from CLI-converter
        //DmnDrgModel drgModel = new DmnDrgModel(inputs, outputs);

        // Step3: iterate each worksheets, and collect informations of all business knowledge
        for (XlsxWorksheetContextReader worksheetContext: worksheetContextList) {
			dmnDefinitions.addDecision( worksheetContext );
        }

        // Step 3: update decision's input output dependency relations
        for (DRGElement drgElement : dmnDefinitions.getDrgElement()) {
			if (drgElement instanceof DmnDecision) {
				DmnDecision dmnDecision = (DmnDecision) drgElement;
				dmnDefinitions.updateCrossDecisionRelation(dmnDecision);
			}
        }

        /*
        // step 4: add decisions to DMN
        for (DmnDecision dmnDecision : dmnDefinitions.getDmnDecisions()) {
            String decisionName = dmnDecision.getKnowledgeRequirement().getName();
            Decision decision = new Decision();
            decision.setId(DmnAttributeValueFormatter.dmnFormattedIdNamingStandard(decisionName));
            decision.setName(DmnAttributeValueFormatter.dmnFormattedVariableNamingStandard(decisionName));
            drgElements.add(decision);

            InputOutputColumns ioColumns = dmnDecision.getKnowledgeRequirement().getInputOutputColumns();
            for (String outputHeaderName : ioColumns.getOutputHeaderCellValues()) {
                InformationItem variable = new InformationItem();
                DmnDecisionTableIOProperty dtIOProperty = ioColumns.getPropertyCellValues(DmnAttributeValueFormatter.dmnFormattedVariableNamingStandard(outputHeaderName));
                variable.setTypeRef(new QName(dtIOProperty.getType())); //by default considering all typeRef as feel:string type
                variable.setName(DmnAttributeValueFormatter.dmnFormattedVariableNamingStandard(outputHeaderName));
                decision.setVariable(variable);
            }
            // till this has done...

            // handle CLI columns **NOTE POSSIBLE ERROR HERE
            System.out.println(decision.getName());
            if ( drgModel.getDecisionsWithCliColumns().containsKey(decision.getName()) ) {
                List<String> cliColumnValues = drgModel.getDecisionsWithCliColumns().get(decisionName);
                for (String cliColumnValue : cliColumnValues) {
                    InformationRequirement infoRequirement = new InformationRequirement();
                    DMNElementReference dmnElementReference = new DMNElementReference();
                    dmnElementReference.setHref("#" + DmnAttributeValueFormatter.dmnFormattedIdNamingStandard(cliColumnValue));
                    infoRequirement.setRequiredInput(dmnElementReference);
                    decision.getInformationRequirement().add(infoRequirement);
                }
            }

            // handle other columns
            if (drgModel.getDecisionRelations() != null && (drgModel.getDecisionRelations().containsKey(decision.getName()))) {
                Map<String,String> outputDecisions = drgModel.getDecisionRelations().get(decisionName);

                for (Map.Entry<String,String> outputDecision : outputDecisions.entrySet()) {
                    String matchedColumnName = outputDecision.getValue();

                    InformationRequirement infoRequirement = new InformationRequirement();
                    DMNElementReference dmnElementReference = new DMNElementReference();
                    dmnElementReference.setHref(DmnAttributeValueFormatter.dmnFormattedHrefNamingStandard(matchedColumnName));
                    infoRequirement.setRequiredDecision(dmnElementReference);
                    decision.getInformationRequirement().add(infoRequirement);
                }
            }

            // for every decision, there will be an knowledge requirement, which connected to business knowledge model.
            KnowledgeRequirement knowledgeRequirement = new KnowledgeRequirement();
            DMNElementReference dmnElementReference = new DMNElementReference();
            dmnElementReference.setHref(DmnAttributeValueFormatter.dmnFormattedKnowledgeReqNamingStandardHref(decision.getName()));
            knowledgeRequirement.setRequiredKnowledge(dmnElementReference);
            decision.getKnowledgeRequirement().add(knowledgeRequirement);

            // invocation
            Invocation invocation = new Invocation();
            LiteralExpression literalExpression = new LiteralExpression();
            literalExpression.setText(decision.getName());
            invocation.setExpression(literalExpression);
            decision.setExpression(invocation);
        }

        // add decision table within business knowledge model
        for (XlsxWorksheetContextReader worksheetContext : worksheetContextList) {
            DmnConversionContext dmncContext = new DmnConversionContext(worksheetContext);
            // order is important; add most specific converters first
            //dmncContext.addCellContentHandler(new DmnValueRangeConverter());
            //dmncContext.addCellContentHandler(new DmnFeelSimpleUnaryTestConverter());
            //dmncContext.addCellContentHandler(new DmnValueStringConverter());
            //dmncContext.addCellContentHandler(new DmnValueNumberConverter());

            // no. of decisions will be based on number of worksheets
            String worksheetNameAsKey = DmnAttributeValueFormatter.dmnFormattedVariableNamingStandard(worksheetContext.getWorksheetName());
            String bizKnowledgeName = encpLogicInfo.getName(worksheetNameAsKey);

            BusinessKnowledgeModel bizKnwldgeModel = new BusinessKnowledgeModel();
            bizKnwldgeModel.setId(DmnAttributeValueFormatter.dmnFormattedKnowledgeReqNamingStandard(bizKnowledgeName));            

            bizKnwldgeModel.setName(bizKnowledgeName);
            FunctionDefinition funcDfn = new FunctionDefinition();
            bizKnwldgeModel.setEncapsulatedLogic(funcDfn);

            DecisionTable decisionTable = new DecisionTable();
            decisionTable.setId(UUID.randomUUID().toString());
            decisionTable.setLabel(bizKnowledgeName);
            decisionTable.setPreferredOrientation(DecisionTableOrientation.RULE_AS_ROW);
            decisionTable.setHitPolicy(HitPolicy.UNIQUE);
            funcDfn.setExpression(decisionTable);

            List<IndexedRow> rows = worksheetContext.getRows();
            // we have the columns mapped to decision, so get it.
            
			DmnBusinessKnowledgeProperty dmnBizKnowProperty = encpLogicInfo.getPropertyCellValues(
					DmnAttributeValueFormatter.dmnFormattedVariableNamingStandard(worksheetContext.getWorksheetName()));
			
            System.out.println("------> The Key to search: ): " + DmnAttributeValueFormatter.dmnFormattedVariableNamingStandard(dmnBizKnowProperty.getName()));
			InputOutputColumns ioColumns = drgModel.getDecisionsWithInputOutputColumns()
					.get(DmnAttributeValueFormatter.dmnFormattedVariableNamingStandard(dmnBizKnowProperty.getName()));

            String outputVarType = convertInputsOutputs(dmncContext, worksheetContext, decisionTable, ioColumns );
            convertRules(dmncContext, decisionTable, rows.subList(4, rows.size())); //ignore 1st 3 rows

            InformationItem variable = new InformationItem();
            variable.setTypeRef(new QName(outputVarType));
			variable.setName(DmnAttributeValueFormatter.dmnFormattedVariableNamingStandard(
					encpLogicInfo.getPropertyCellValues(worksheetNameAsKey).getName()));
            bizKnwldgeModel.setVariable(variable);

            drgElements.add(bizKnwldgeModel);
        }*/

        return this.dmnDefinitions;
    }

    protected void convertRules(DmnConversionContext dmnConversionContext, DecisionTable decisionTable, List<IndexedRow> rulesRows) {
        for (IndexedRow rule : rulesRows) {
            convertRule(dmnConversionContext, decisionTable, rule);
        }
    }

    protected void convertRule(DmnConversionContext dmnConversionContext, DecisionTable decisionTable, IndexedRow ruleRow) {

        DecisionRule decisionRule = new DecisionRule();
        decisionRule.setId(UUID.randomUUID().toString());
        decisionTable.getRule().add(decisionRule);
        IndexedDmnColumns dmnColumns = dmnConversionContext.getIndexedDmnColumns();
        System.out.println("######################################################");
        for (InputClause input : dmnColumns.getOrderedInputs()) {
            String xlsxColumn = dmnColumns.getXlsxColumn(input);
            System.out.println("The input xlsxColumn: " + xlsxColumn);
            IndexedCell cell = ruleRow.getCell(xlsxColumn);

            UnaryTests inputEntry = new UnaryTests();
            String textValue = cell != null ? dmnConversionContext.resolveCellValue(cell.getCell()) : getDefaultCellContent();
            textValue = ((textValue != null) && (!textValue.equals("null"))) ? textValue : getDefaultCellContent();
            System.out.println("The InputClause textValue: " + textValue);
            inputEntry.setText(textValue);
            inputEntry.setId(UUID.randomUUID().toString());
            decisionRule.getInputEntry().add(inputEntry);
        }

        for (OutputClause output : dmnColumns.getOrderedOutputs()) {
            String xlsxColumn = dmnColumns.getXlsxColumn(output);
            System.out.println("The output xlsxColumn: " + xlsxColumn);
            IndexedCell cell = ruleRow.getCell(xlsxColumn);

            LiteralExpression outputEntry = new LiteralExpression();
            String textValue = cell != null ? dmnConversionContext.resolveCellValue(cell.getCell()) : getDefaultCellContent();
            System.out.println("The Output textValue: " + textValue);
            outputEntry.setText(textValue);
            outputEntry.setId(UUID.randomUUID().toString());
            decisionRule.getOutputEntry().add(outputEntry);
        }
    }

    protected String convertInputsOutputs ( DmnConversionContext dmncContext, XlsxWorksheetContextReader worksheetContext, DecisionTable decisionTable, InputOutputColumns ioColumns ) {

        String outputVarType = "feel:string"; // default type value

        for (IndexedCell inputCell : ioColumns.getInputHeaderCells()) {
            String inputHeaderName = inputCell.resolveCellValue(inputCell.getCell());
            InputClause input = new InputClause();
            input.setId(UUID.randomUUID().toString());
            input.setLabel(inputHeaderName);
            System.out.println("DEBA------------->" + inputHeaderName);
            DmnDecisionTableIOProperty dtIOProperty = ioColumns
                    .getPropertyCellValues(DmnAttributeValueFormatter.dmnFormattedVariableNamingStandard(inputHeaderName));

            LiteralExpression inputExpression = new LiteralExpression();
            inputExpression.setTypeRef(new QName(dtIOProperty.getType()));
            inputExpression.setText(DmnAttributeValueFormatter.dmnFormattedVariableNamingStandard(inputHeaderName));
            input.setInputExpression(inputExpression);

            if (dtIOProperty.getBoundary() != null) {
                UnaryTests inputValues = new UnaryTests();
                String boundary = dtIOProperty.getBoundary();
                boundary = boundary.replaceAll("'", "\"");
                inputValues.setText(boundary);
                input.setInputValues(inputValues);
            }

            decisionTable.getInput().add(input);
            dmncContext.getIndexedDmnColumns().addInput(inputCell, input);
        }

        for (IndexedCell outputCell : ioColumns.getOutputHeaderCells()) {
            String outputHeaderName = outputCell.resolveCellValue(outputCell.getCell());
            OutputClause output = new OutputClause();
            output.setId(UUID.randomUUID().toString());
            output.setLabel(outputHeaderName);

            // System.out.println("------------->" + outputHeaderName);
            DmnDecisionTableIOProperty dtIOProperty = ioColumns
                    .getPropertyCellValues(DmnAttributeValueFormatter.dmnFormattedVariableNamingStandard(outputHeaderName));

            if (dtIOProperty.getBoundary() != null) {
                UnaryTests outputValue = new UnaryTests();
                String boundary = dtIOProperty.getBoundary();
                boundary = boundary.replaceAll("'", "\"");
                outputValue.setText(boundary);
                output.setOutputValues(outputValue);
            }

            if (dtIOProperty.getDefaultvalue() != null) {
                LiteralExpression outputExpression = new LiteralExpression();
                String defaultValue = dtIOProperty.getDefaultvalue();
                defaultValue = "\"" + defaultValue + "\"";
                outputExpression.setText(defaultValue);
                output.setDefaultOutputEntry(outputExpression);
            }

            if (dtIOProperty.getType() != null) {
                outputVarType = dtIOProperty.getType();
            }

            decisionTable.getOutput().add(output);
            dmncContext.getIndexedDmnColumns().addOutput(outputCell, output);
        }

        return outputVarType;
    }



    protected String getDefaultCellContent() {
        return "";
    }
}
