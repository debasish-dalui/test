package com.schwab.drools.xlsx.columnDividingStrategy;

import java.util.List;

import com.schwab.drools.xlsx.XlsxWorksheetContextReader;
import com.schwab.drools.xlsx.elements.EncapsulatedLogicInfo;
import com.schwab.drools.xlsx.elements.IndexedCell;
import com.schwab.drools.xlsx.elements.IndexedRow;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class BizKnowledgeElementDetectionStrategy {

	public void determineBizKnowledgeElements(XlsxWorksheetContextReader worksheetContext,
			EncapsulatedLogicInfo bizKnowledgeElements) {
		
		IndexedRow bizKnowledgeNameRow = worksheetContext.getRows().get(1);
		if (!bizKnowledgeNameRow.hasCells()) {
			log.error("A Business knowledge require the name. The name row contains no entries.");
			throw new RuntimeException(
					"A Business knowledge require the name. The name row contains no entries.");
		}
		List<IndexedCell> cellPropertiesName = bizKnowledgeNameRow.getCells();
		IndexedCell propCells = cellPropertiesName.get(0);
		bizKnowledgeElements.addNameCellValues(worksheetContext.getWorksheetName(),
				propCells.resolveCellValue(propCells.getCell()));
		
		IndexedRow bizKnowledgePropertyRow = worksheetContext.getRows().get(2);
		if (!bizKnowledgePropertyRow.hasCells()) {
			log.error("A Business knowledge require at least one property. The property row contains no entries.");
			throw new RuntimeException(
					"A Business knowledge requires at least one property; the property row contains no entries");
		}

		List<IndexedCell> cellPropertiesProp = bizKnowledgePropertyRow.getCells();
		System.out.println("The cellProperties.size(): " + cellPropertiesProp.size());
		String outputCellPropertyValue = propCells.resolveCellValue(propCells.getCell());
		System.out.println("The outputCellPropertyValue: " + outputCellPropertyValue);

		bizKnowledgeElements.addPropertyCellValues(worksheetContext.getWorksheetName(), outputCellPropertyValue);
	}

}