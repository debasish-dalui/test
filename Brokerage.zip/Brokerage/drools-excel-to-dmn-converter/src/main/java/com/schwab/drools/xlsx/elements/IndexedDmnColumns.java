package com.schwab.drools.xlsx.elements;

import org.kie.dmn.model.v1_1.InputClause;
import org.kie.dmn.model.v1_1.OutputClause;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class IndexedDmnColumns {

	protected Map<InputClause, IndexedCell> headerCellsByInput = new HashMap<InputClause, IndexedCell>();
	protected Map<OutputClause, IndexedCell> headerCellsByOutput = new HashMap<OutputClause, IndexedCell>();

	// as they appear in the resulting DMN table
	protected List<InputClause> orderedInputs = new ArrayList<InputClause>();
	protected List<OutputClause> orderedOutputs = new ArrayList<OutputClause>();

	public List<InputClause> getOrderedInputs() {
		return orderedInputs;
	}

	public List<OutputClause> getOrderedOutputs() {
		return orderedOutputs;
	}

	public String getXlsxColumn(InputClause input) {
		IndexedCell headerCell = headerCellsByInput.get(input);
		return headerCell.getColumn();
	}

	public String getXlsxColumn(OutputClause output) {
		IndexedCell headerCell = headerCellsByOutput.get(output);
		return headerCell.getColumn();
	}

	public void addInput(IndexedCell cell, InputClause input) {
		this.orderedInputs.add(input);
		this.headerCellsByInput.put(input, cell);
	}

	public void addOutput(IndexedCell cell, OutputClause output) {
		this.orderedOutputs.add(output);
		this.headerCellsByOutput.put(output, cell);
	}

}
