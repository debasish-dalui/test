package com.schwab.drools.cli;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.kie.dmn.api.marshalling.v1_1.DMNMarshaller;
import org.kie.dmn.backend.marshalling.v1_1.DMNMarshallerFactory;
import org.kie.dmn.model.v1_1.Definitions;

import com.schwab.drools.xlsx.XlsxReaderUtil;

import lombok.extern.slf4j.Slf4j;

/**
 * Class to generate DMN specification (.dmn) from DMN Excel template having
 * business rules.
 * 
 * @author debasish.dalui
 */
@Slf4j
public class CommandLineConverter {
	
	public static void main(String[] args) {
		if (args.length == 0) {			
			StringBuilder sb = new StringBuilder();
			sb.append(
					"Usage: java -jar ...jar [--inputs A,B,C,..] [--outputs D,E,F,...] path/to/file.xlsx path/to/outfile.dmn");
			return;
		}

		String inputFile = args[args.length - 2];
		String outputFile = args[args.length - 1];

		Set<String> inputs = null;
		Set<String> outputs = null;
		for (int i = 0; i < args.length - 2; i++) {
			if (args[i].contains("--inputs")) {
				inputs = new HashSet<>();
				inputs.addAll(Arrays.asList(StringUtils.stripAll(args[i].substring(9).split(","))));
			}

			if (args[i].contains("--outputs")) {
				outputs = new HashSet<>();
				outputs.addAll(Arrays.asList(StringUtils.stripAll(args[i].substring(10).split(","))));
			}
		}

		try {
			FileInputStream fileInputStream = null;
			FileWriter fileWriter = null;
			try {
				XlsxReaderUtil converter = new XlsxReaderUtil();
				fileInputStream = new FileInputStream(inputFile);
				String fileName = FilenameUtils.getBaseName(outputFile);
				fileWriter = new FileWriter (outputFile);
				
				Definitions dmnDefinitions = (Definitions) converter.convert(fileInputStream, fileName, inputs, outputs);
				log.info("Successfully parsed through the excel file.");
				log.info("Dmn Definitions: \n" + dmnDefinitions);

				DMNMarshaller dmnMarshaller = DMNMarshallerFactory.newDefaultMarshaller();
				String dmnStr = dmnMarshaller.marshal(dmnDefinitions);
				log.info("DMN Gen Test (From Excel): \n" + dmnStr);
				dmnMarshaller.marshal(dmnDefinitions, fileWriter);
				log.info("Successfully wrote the parsed excel file to the dmn file.");
			} finally {
				if (fileInputStream != null) {
					fileInputStream.close();
				}
				if (fileWriter != null) {
					fileWriter.close();
				}
			}
		} catch (Exception exception) {
			log.error("Could not convert file: " + exception.getMessage());
			exception.printStackTrace(System.out);
		}
	}
}
