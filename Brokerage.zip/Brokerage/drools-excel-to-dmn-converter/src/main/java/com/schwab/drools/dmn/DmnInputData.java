/**
 * 
 */
package com.schwab.drools.dmn;

import javax.xml.namespace.QName;

import org.kie.dmn.model.v1_1.InformationItem;
import org.kie.dmn.model.v1_1.InputData;

import com.schwab.drools.util.DmnAttributeValueFormatter;

/**
 * @author debasish.dalui
 *
 */
public class DmnInputData {

	/**
	 * Private Constructor
	 */
	private DmnInputData() {
		super();
	}

	public static InputData initialize(String name, String type) {
		InputData inputData = new InputData();
		inputData.setName(DmnAttributeValueFormatter.dmnFormattedVariableNamingStandard(name));
		inputData.setId(DmnAttributeValueFormatter.dmnFormattedIdNamingStandard(name));

		InformationItem variable = new InformationItem();
		variable.setTypeRef(new QName(type));
		variable.setName(DmnAttributeValueFormatter.dmnFormattedVariableNamingStandard(name));
		inputData.setVariable(variable);

		return inputData;
	}

}
