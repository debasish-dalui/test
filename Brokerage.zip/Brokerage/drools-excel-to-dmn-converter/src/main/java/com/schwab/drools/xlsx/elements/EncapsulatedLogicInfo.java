package com.schwab.drools.xlsx.elements;

import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;
import com.schwab.drools.dmn.DmnBusinessKnowledgeProperty;
import com.schwab.drools.util.DmnAttributeValueFormatter;

public class EncapsulatedLogicInfo {

	private Map<String, String> name;
	private Map<String, DmnBusinessKnowledgeProperty> dmnProperty;

	public EncapsulatedLogicInfo() {
		this.name = new HashMap<String, String>();
		this.dmnProperty = new HashMap<String, DmnBusinessKnowledgeProperty>();
	}

	public void addPropertyCellValues(String key, String propertyAsJson) {
		final Gson gson = new Gson();
		DmnBusinessKnowledgeProperty bizKnowledgeProperty = gson.fromJson(propertyAsJson,
				DmnBusinessKnowledgeProperty.class);
		this.dmnProperty.put(DmnAttributeValueFormatter.dmnFormattedVariableNamingStandard(key),
				bizKnowledgeProperty);
	}
	
	public void addNameCellValues(String key, String value) {
		this.name.put(DmnAttributeValueFormatter.dmnFormattedVariableNamingStandard(key),
				value);
	}

	public DmnBusinessKnowledgeProperty getPropertyCellValues(String key) {
		return dmnProperty.get(key);
	}
	
	public String getName (String key) {
		return name.get(key);
	}

}
