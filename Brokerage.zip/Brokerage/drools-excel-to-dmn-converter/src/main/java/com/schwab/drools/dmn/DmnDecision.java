/*
 * Copyright (c) 2017, Charles Schwab and/or its affiliates. All rights reserved.
 */
package com.schwab.drools.dmn;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.namespace.QName;

import org.kie.dmn.model.v1_1.DMNElementReference;
import org.kie.dmn.model.v1_1.Decision;
import org.kie.dmn.model.v1_1.InformationItem;
import org.kie.dmn.model.v1_1.InformationRequirement;
import org.kie.dmn.model.v1_1.KnowledgeRequirement;

import com.schwab.drools.util.DmnAttributeValueFormatter;
import com.schwab.drools.xlsx.XlsxWorksheetContextReader;
import com.schwab.drools.xlsx.columnDividingStrategy.BizKnowledgeElementDetectionStrategy;
import com.schwab.drools.xlsx.elements.EncapsulatedLogicInfo;
import com.schwab.drools.xlsx.elements.InputOutputColumns;

public class DmnDecision extends Decision {

	protected BizKnowledgeElementDetectionStrategy bkeDetectionStrategy;
	protected EncapsulatedLogicInfo encpLogicInfo;	
	
	//TODO: more of a knowledgeRequirement type
	protected DmnDecisionTable knowledgeRequirementAsDecisionTable; 

	/**
	 * Constructor
	 * 
	 * @param name
	 */
	public DmnDecision() {
		super();
		this.encpLogicInfo = new EncapsulatedLogicInfo();
		this.bkeDetectionStrategy = new BizKnowledgeElementDetectionStrategy();
	}

	public void addDecision(XlsxWorksheetContextReader xlsContext, Set<String> inputsFromCLI,
			Set<String> outputsFromCLI) {
		
		// determine business-knowledge information for each sheet
		System.out.println("The worksheetName: " + xlsContext.getWorksheetName());
		bkeDetectionStrategy.determineBizKnowledgeElements(xlsContext, encpLogicInfo);
		DmnBusinessKnowledgeProperty dmnBizKnowProperty = encpLogicInfo.getPropertyCellValues(
				DmnAttributeValueFormatter.dmnFormattedVariableNamingStandard(xlsContext.getWorksheetName()));
		
	    System.out.println("The dmnBizKnowProperty name: " + dmnBizKnowProperty.getName());
	    System.out.println("The dmnBizKnowProperty type: " + dmnBizKnowProperty.getCategory());
	    System.out.println("The dmnBizKnowProperty orientation: " + dmnBizKnowProperty.getOrientation());
	    
		if (dmnBizKnowProperty.getCategory()
				.equals(DmnBusinessKnowledgeProperty.BusinessKnowledgeType.DECISION_TABLE.toString())) {
			
			if (dmnBizKnowProperty.getOrientation()
					.equals(DmnBusinessKnowledgeProperty.DecisionTableOrientation.HORIZONTAL.toString())) {

				knowledgeRequirementAsDecisionTable = new DmnDecisionTableHoriOri(
						DmnAttributeValueFormatter.dmnFormattedVariableNamingStandard(dmnBizKnowProperty.getName()),
						xlsContext, inputsFromCLI, outputsFromCLI);
				
		        setId(DmnAttributeValueFormatter.dmnFormattedIdNamingStandard(knowledgeRequirementAsDecisionTable.getName()));
		        setName(DmnAttributeValueFormatter.dmnFormattedVariableNamingStandard(knowledgeRequirementAsDecisionTable.getName()));
		        
		        //may be??
			}
		}
		
		// if box-expression
		/*if (dmnBizKnowProperty.getCategory()
				.equals(DmnBusinessKnowledgeProperty.BusinessKnowledgeType.BOX_EXPRESSION.toString())) {
			// need to implement
		}*/
        // Add the variable inside decision
        InputOutputColumns ioColumns = knowledgeRequirementAsDecisionTable.getInputOutputColumns();
		for (String outputHeaderName : ioColumns.getOutputHeaderCellValues()) {
			
			InformationItem variable = new InformationItem();
			DmnDecisionTableIOProperty dtIOProperty = ioColumns.getPropertyCellValues(
					DmnAttributeValueFormatter.dmnFormattedVariableNamingStandard(outputHeaderName));
			variable.setTypeRef(new QName(dtIOProperty.getType())); // by default considering all typeRef as
																	// feel:string type
			variable.setName(DmnAttributeValueFormatter.dmnFormattedVariableNamingStandard(outputHeaderName));
			setVariable(variable);
		}		
		
		// Add the CLI columns as inputRequirement with requiredInput
		for (String cliInput : inputsFromCLI) {
			InformationRequirement infoRequirement = new InformationRequirement();
			DMNElementReference dmnElementReference = new DMNElementReference();
			dmnElementReference.setHref("#" + DmnAttributeValueFormatter.dmnFormattedIdNamingStandard(cliInput));
			infoRequirement.setRequiredInput(dmnElementReference);
			getInformationRequirement().add(infoRequirement);
		}
		
	}
	
	public DmnDecisionTable getKnowledgeRequirementAsDecisionTable() {
		return knowledgeRequirementAsDecisionTable;
	}

	// handle inferred attributes
	public void handleInferredAttributes ( String mColumn ) {        
        InformationRequirement infoRequirement = new InformationRequirement();
        DMNElementReference dmnElementReference = new DMNElementReference();
        dmnElementReference.setHref(DmnAttributeValueFormatter.dmnFormattedHrefNamingStandard(mColumn));
        infoRequirement.setRequiredDecision(dmnElementReference);
        getInformationRequirement().add(infoRequirement);
	}

}
