package com.schwab.drools.xlsx.columnDividingStrategy;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.schwab.drools.util.DmnAttributeValueFormatter;
import com.schwab.drools.xlsx.XlsxWorksheetContextReader;
import com.schwab.drools.xlsx.elements.IndexedCell;
import com.schwab.drools.xlsx.elements.IndexedRow;
import com.schwab.drools.xlsx.elements.InputOutputColumns;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DecisionTableInputOutputDetectionStrategy {

	List<String> hitPolicies;

	public DecisionTableInputOutputDetectionStrategy() {
		super();
		hitPolicies = new ArrayList<String>();
		hitPolicies.add("U");
		hitPolicies.add("A");
		hitPolicies.add("P");
		hitPolicies.add("F");
		hitPolicies.add("O");
		hitPolicies.add("R");
	}

	public InputOutputColumns determineHeaderCells(XlsxWorksheetContextReader worksheetContext, Set<String> inputsFromCLI, Set<String> outputsFromCLI) {

		IndexedRow headerRow = worksheetContext.getRows().get(2);
		if (!headerRow.hasCells()) {
			log.error("Decision table require at least one output. The header row contains no entries.");
			throw new RuntimeException(
					"A Business knowledge requires at least one output; the header row contains no entries");
		}

		IndexedRow propertyRow = worksheetContext.getRows().get(3);
		if (!propertyRow.hasCells()) {
			log.error("Decision table require the property, which seems missing.");
			throw new RuntimeException("Decision table require the property, which seems missing.");
		}
		InputOutputColumns ioColumns = new InputOutputColumns();
		List<IndexedCell> inputOutputCells = headerRow.getCells();
		
		// TODO: need to work on multiple output column
		IndexedCell headerCell = inputOutputCells.get(inputOutputCells.size() - 1);
		String headerValue = headerCell.resolveCellValue(headerCell.getCell());
		
		// identify if the input is from command-line
		if (outputsFromCLI.contains(headerValue)) {
			headerCell.setCliAttr(true);
		}
		ioColumns.addOutputHeaderCell(inputOutputCells.get(inputOutputCells.size() - 1));
		ioColumns.addOutputHeaderCellValues(headerValue);

		List<IndexedCell> cellProperties = propertyRow.getCells();
		IndexedCell propertyCell = cellProperties.get(inputOutputCells.size() - 1);
		String outputCellPropertyValue = propertyCell.resolveCellValue(propertyCell.getCell());
		
		ioColumns.addPropertyCellValues(DmnAttributeValueFormatter.dmnFormattedVariableNamingStandard(headerValue),
				outputCellPropertyValue);

		List<IndexedCell> inputCells = inputOutputCells.subList(0, inputOutputCells.size() - 1);
		List<IndexedCell> inputCellProperties = cellProperties.subList(0, inputOutputCells.size() - 1);
		for (int index = 0; index < inputCells.size(); index++) {
			IndexedCell inputCell = inputCells.get(index);
			
			// TODO: need to work on additional types
			if (!hitPolicies.contains(inputCell.resolveCellValue(inputCell.getCell()))) { 
				// identify if the input is from command-line
				String inputValue = inputCell.resolveCellValue(inputCell.getCell());
				if (inputsFromCLI.contains(inputValue)) {
					inputCell.setCliAttr(true);
				}
				ioColumns.addInputHeaderCell(inputCell);
				ioColumns.addinputHeaderCellValues(inputValue);

				IndexedCell inputPropertyCell = inputCellProperties.get(index);
				String inputCellPropertyValue = inputPropertyCell.resolveCellValue(inputPropertyCell.getCell());
				if ((inputCellPropertyValue != null) && (!inputCellPropertyValue.equals("null"))) {
					ioColumns.addPropertyCellValues(
							DmnAttributeValueFormatter.dmnFormattedVariableNamingStandard(inputValue),
							inputCellPropertyValue);
				}
			}
		}

		return ioColumns;
	}
	
}
