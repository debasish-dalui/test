/*
 * Copyright (c) 2017, Charles Schwab and/or its affiliates. All rights reserved.
 */

package com.schwab.drools;


import org.junit.Test;
//TODO: JHOAN ADD TESTS CASES HERE
public class CommandLineConverterTest {

    @Test
    public void addTestHere(){

    }
}
