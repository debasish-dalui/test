
package com.schwab.drools.xlsx.columnDividingStrategy;

import com.schwab.drools.util.XlsxWorksheetContextReader;
import com.schwab.drools.xlsx.elements.IndexedRow;
import com.schwab.drools.xlsx.elements.InputOutputColumns;

public interface InputOutputDetectionStrategy {

	InputOutputColumns determineHeaderCells(IndexedRow headerRow, IndexedRow propertyRow, XlsxWorksheetContextReader worksheetContexts);
}
