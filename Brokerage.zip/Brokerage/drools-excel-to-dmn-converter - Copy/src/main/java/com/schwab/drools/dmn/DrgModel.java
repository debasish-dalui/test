package com.schwab.drools.dmn;

import com.schwab.drools.xlsx.elements.InputOutputColumns;

import java.util.*;

public class DrgModel {

	protected Map<String, InputOutputColumns> decisionsWithInputOutputColumns;
	protected Map<String, List<String>> decisionsWithCliColumns;
	protected Map<String, Map<String, String>> decisionRelations;
	
	protected Set<String> inputsFromCLI;
	protected Set<String> outputsFromCLI;

	public DrgModel(Set<String> inputs, Set<String> outputs) {
		super();
		this.inputsFromCLI = inputs;
		this.outputsFromCLI = outputs;
	}

	public Map<String, InputOutputColumns> getDecisionsWithInputOutputColumns() {
		return decisionsWithInputOutputColumns;
	}

	public void addDecisionsWithInputOutputColumns(String decisionName, InputOutputColumns inputOutputColumns) {
		if ( this.decisionsWithInputOutputColumns == null ) {
			this.decisionsWithInputOutputColumns = new HashMap<String, InputOutputColumns>();
		}
		this.decisionsWithInputOutputColumns.put(decisionName, inputOutputColumns);
	}
	
	public void addDecisionsWithCliColumns(String decisionName, String cliColumnValue) {
		if ( this.decisionsWithCliColumns == null ) {
			this.decisionsWithCliColumns = new HashMap<String, List<String>>();
			
			List<String> cliColumnValues = new ArrayList<String>();
			cliColumnValues.add(cliColumnValue);
			this.decisionsWithCliColumns.put(decisionName, cliColumnValues);
		}
		else {
			List<String> cliColumnValues = this.decisionsWithCliColumns.get(decisionName);
			if (cliColumnValues == null) {
				cliColumnValues = new ArrayList<String>();
			}
			cliColumnValues.add(cliColumnValue);
			this.decisionsWithCliColumns.put(decisionName, cliColumnValues);
		}
	}
	
	public Map<String, List<String>> getDecisionsWithCliColumns() {
		return decisionsWithCliColumns;
	}

	public Map<String, Map<String, String>> getDecisionRelations() {
		return decisionRelations;
	}

	public void addDecisionRelations(String decisionUsedDeriveValueAsInput, String decisionThatDeriveValue,
			String derivedValue) {
		if (this.decisionRelations == null) {
			this.decisionRelations = new HashMap<String, Map<String, String>>();
			Map<String, String> mappedDecisions = new HashMap<String, String>();
			mappedDecisions.put(decisionThatDeriveValue, derivedValue);
			this.decisionRelations.put(decisionUsedDeriveValueAsInput, mappedDecisions);
		} else {
			Map<String, String> mappedDecisions = null;
			if (this.decisionRelations.containsKey(decisionUsedDeriveValueAsInput)) {
				mappedDecisions = decisionRelations.get(decisionUsedDeriveValueAsInput);
				mappedDecisions.put(decisionThatDeriveValue, derivedValue);
			} else {
				mappedDecisions = new HashMap<String, String>();
				mappedDecisions.put(decisionThatDeriveValue, derivedValue);
			}
			this.decisionRelations.put(decisionUsedDeriveValueAsInput, mappedDecisions);
		}
	}

	public void determineDrgRelations() {
		System.out.println("*******************************************************************************");
		// iterate each decisions
		for (Map.Entry<String, InputOutputColumns> decisionItr1 : decisionsWithInputOutputColumns.entrySet()) {
			String decisionName = decisionItr1.getKey();
			System.out.println("decisionName: " + decisionName);
			InputOutputColumns inputOutputColumns = decisionItr1.getValue();

			// list of inputs
			List<String> inputHeaderCellValues = inputOutputColumns.getInputHeaderCellValues();

			for (String inputCellValue : inputHeaderCellValues) {
				
				// inputs except than cli-inputs or so called inferred/derived ones
				if (!inputsFromCLI.contains(inputCellValue)) {
					//System.out.println("--> 1. Decisions ["+ decisionName +"], Input: ["+ inputCellValue +"]");
					
					// figure out from which decisions it has derived
					for (Map.Entry<String, InputOutputColumns> decisionItr2 : decisionsWithInputOutputColumns.entrySet()) {
						String decisionNameForCompare = decisionItr2.getKey();
						InputOutputColumns ioColumns = decisionItr2.getValue();
						
						List<String> outputHeaderCellValues = ioColumns.getOutputHeaderCellValues();
						for (String outputCellValue : outputHeaderCellValues) {
							if (inputCellValue.contains(outputCellValue)) { //matched
								//System.out.println("------------------ Matched ---------------");
								//System.out.println("--> Decisions ["+decisionName+"], Input: [" + inputCellValue +"]");
								//System.out.println("--> Decisions ["+decisionNameForCompare+"], Output: [" + outputCellValue +"]");
								
								addDecisionRelations(decisionName, decisionNameForCompare, outputCellValue);
							}
						}						
					}
				}
				else {
					// add to cli-column entries for the decision
					addDecisionsWithCliColumns(decisionName, inputCellValue);
				}
			}
		}
		System.out.println("*********************************************************************************");
	}
}
