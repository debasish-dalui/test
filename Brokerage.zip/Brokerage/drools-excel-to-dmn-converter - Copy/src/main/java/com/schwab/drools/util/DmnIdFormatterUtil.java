package com.schwab.drools.util;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class DmnIdFormatterUtil {
	private final static String UNDERSCORE = "_";
	private final static String SPACE = "\\s+";
	private final static String EMPTYSPACE = "";

	public static String dmnFormattedVariableNamingStandard(String input) {
		String str = input.replaceAll(SPACE, EMPTYSPACE);
		return Character.toLowerCase(str.charAt(0)) + str.substring(1);
	}

	public static String dmnFormattedKnowledgeReqNamingStandard(String input) {
		return "d" + dmnFormattedIdNamingStandard(input) + "_Rules";
	}

	public static String dmnFormattedKnowledgeReqNamingStandardHref(String input) {
		return "#d" + dmnFormattedIdNamingStandard(input) + "_Rules";
	}

	public static String dmnFormattedHrefNamingStandard(String input) {
		return "#" + dmnFormattedIdNamingStandard(input);
	}

	public static String dmnFormattedIdNamingStandard(String input) {
		return UNDERSCORE + dmnFormattedVariableNamingStandard(input);
	}
}
