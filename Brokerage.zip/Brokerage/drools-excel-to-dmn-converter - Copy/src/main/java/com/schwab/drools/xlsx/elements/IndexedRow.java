package com.schwab.drools.xlsx.elements;

import org.xlsx4j.sml.Cell;
import org.xlsx4j.sml.Row;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class IndexedRow {

	public static final Pattern CELL_REF_PATTERN = Pattern.compile("([A-Z]+)([0-9]+)");

	protected Row row;
	protected List<IndexedCell> cells;
	protected Map<String, IndexedCell> cellsByColumn;

	public IndexedRow(Row row) {
		this.row = row;
		this.cells = new ArrayList<IndexedCell>();
		this.cellsByColumn = new HashMap<String, IndexedCell>();

		for (Cell cell : row.getC()) {
			IndexedCell indexedCell = new IndexedCell(cell);
			String column = indexedCell.getColumn();
			cells.add(indexedCell);
			cellsByColumn.put(column, indexedCell);
		}
	}

	protected String extractColumn(Cell cell) {
		String cellReference = cell.getR();
		Matcher matcher = CELL_REF_PATTERN.matcher(cellReference);
		return matcher.group(1);
	}

	public Row getRow() {
		return row;
	}

	public Collection<String> getColumns() {
		return cellsByColumn.keySet();
	}

	public IndexedCell getCell(String column) {
		return cellsByColumn.get(column);
	}

	public boolean hasCells() {
		return !cells.isEmpty();
	}

	public List<IndexedCell> getCells() {
		return cells;
	}
}
