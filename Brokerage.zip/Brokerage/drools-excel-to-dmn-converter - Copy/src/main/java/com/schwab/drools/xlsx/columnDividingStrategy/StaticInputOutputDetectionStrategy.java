package com.schwab.drools.xlsx.columnDividingStrategy;

import com.schwab.drools.util.XlsxWorksheetContextReader;
import com.schwab.drools.xlsx.elements.IndexedCell;
import com.schwab.drools.xlsx.elements.IndexedRow;
import com.schwab.drools.xlsx.elements.InputOutputColumns;

import java.util.Set;

public class StaticInputOutputDetectionStrategy implements InputOutputDetectionStrategy {

	protected Set<String> inputColumns;
	protected Set<String> outputColumns;

	public StaticInputOutputDetectionStrategy(Set<String> inputColumns, Set<String> outputColumns) {
		this.inputColumns = inputColumns;
		this.outputColumns = outputColumns;
	}

	public InputOutputColumns determineHeaderCells(IndexedRow headerRow, IndexedRow propertyRow, XlsxWorksheetContextReader context) {
		InputOutputColumns columns = new InputOutputColumns();

		for (IndexedCell cell : headerRow.getCells()) {
			if (inputColumns.contains(cell.getColumn())) {
				columns.addInputHeaderCell(cell);
			} else if (outputColumns.contains(cell.getColumn())) {
				columns.addOutputHeaderCell(cell);
			}
		}

		return columns;
	}
}
