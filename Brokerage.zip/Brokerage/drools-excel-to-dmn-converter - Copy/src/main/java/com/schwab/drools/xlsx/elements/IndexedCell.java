
package com.schwab.drools.xlsx.elements;

import org.xlsx4j.sml.Cell;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class IndexedCell {

	public static final Pattern CELL_REF_PATTERN = Pattern.compile("([A-Z]+)([0-9]+)");

	protected Cell cell;
	protected String column;
	protected int row;

	public IndexedCell(Cell cell) {
		this.cell = cell;

		String cellReference = cell.getR();
		Matcher matcher = CELL_REF_PATTERN.matcher(cellReference);

		boolean matches = matcher.matches();
		if (!matches) {
			throw new RuntimeException("Cannot parse cell reference " + cellReference);
		}

		column = matcher.group(1);
		row = Integer.parseInt(matcher.group(2));
	}

	public Cell getCell() {
		return cell;
	}

	public String getColumn() {
		return column;
	}

	public int getRow() {
		return row;
	}

}
