package com.schwab.drools.cli;

import com.schwab.drools.util.XlsxReaderUtil;
import lombok.extern.slf4j.Slf4j;
import org.kie.dmn.api.marshalling.v1_1.DMNMarshaller;
import org.kie.dmn.backend.marshalling.v1_1.DMNMarshallerFactory;
import org.kie.dmn.model.v1_1.Definitions;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.util.HashSet;
import java.util.Set;

//TODO: FIX EXCEPTIONS
//TODO: MAKE INPUTS/OUTPUTS NOT HARD CODED IN
//TODO: BETTER RETURN MESSAGE IF USER VIOLATES THE PROGRAM
@Slf4j
public class CommandLineConverter {

    public static void main(String[] args){
        if(args.length == 0){
            StringBuilder output = new StringBuilder();
            output.append("The path location to the excel and dmn files are required.");
            return;
        }

        String excelFilePath = args[args.length-2];
        String dmnFilePath = args[args.length-1];

        //TODO: MAKE THIS NOT HARDCODED
        Set<String> inputs = new HashSet<String>();
//        inputs.add("Account Product Code");
//        inputs.add("Account Registration Code");
        inputs.add("Age");
        inputs.add("Role");

        Set<String> outputs = new HashSet<String>();
//        outputs.add("Auto Review Result");
//        outputs.add("Account Registration");
        outputs.add("Age Restriction for Minor");

        XlsxReaderUtil converter = new XlsxReaderUtil();
        FileInputStream fileInputStream = null;
        FileWriter fileWriter = null;

        try{
            try{
                fileInputStream = new FileInputStream(excelFilePath);
                fileWriter = new FileWriter(dmnFilePath);

                Definitions dmnDefinitions = converter.convert(fileInputStream, inputs, outputs);
                log.info("Successfully parsed through the excel file.");
               log.info("Dmn Definitions: \n" + dmnDefinitions);

                DMNMarshaller dmnMarshaller = DMNMarshallerFactory.newDefaultMarshaller();
                String dmnStr = dmnMarshaller.marshal(dmnDefinitions);
                log.info("DMN Gen Test (From Excel): \n" + dmnStr);
                dmnMarshaller.marshal(dmnDefinitions, fileWriter);
                log.info("Successfully wrote the parsed excel file to the dmn file.");
            } finally{
                if (fileInputStream != null) {
                    fileInputStream.close();
                }
                if (fileWriter != null) {
                    fileWriter.close();
                }
            }
        } catch(Exception e){
            log.error("Could not successfully convert the excel file into a dmn file!");
            e.printStackTrace();
        }
    }
}
