package com.schwab.drools.xlsx.elements;

import com.schwab.drools.util.XlsxWorksheetContextReader;
import org.xlsx4j.sml.Cell;

public interface CellContentHandler {

  boolean canConvert(Cell cell, XlsxWorksheetContextReader context);

  String convert(Cell cell, XlsxWorksheetContextReader context);

}
