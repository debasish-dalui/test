package com.schwab.drools.util;

import com.schwab.drools.xlsx.elements.CellContentHandler;
import com.schwab.drools.xlsx.elements.IndexedRow;
import org.xlsx4j.sml.*;

import java.util.ArrayList;
import java.util.List;

public class XlsxWorksheetContextReader {

    protected List<CellContentHandler> cellContentHandlers;
    protected CTSst sharedStrings;
    protected Worksheet worksheet;
    protected String worksheetName;

    // cached state
    protected List<IndexedRow> indexedRows;

    public XlsxWorksheetContextReader(CTSst sharedStrings, Worksheet worksheet, String worksheetName) {
        this.sharedStrings = sharedStrings;
        this.worksheet = worksheet;
        this.cellContentHandlers = new ArrayList<CellContentHandler>();
        this.worksheetName = worksheetName;
    }

    public List<IndexedRow> getRows() {
        if (indexedRows == null) {
            indexedRows = new ArrayList<IndexedRow>();
            for (Row row : worksheet.getSheetData().getRow()) {
                indexedRows.add(new IndexedRow(row));
            }
        }
        return indexedRows;
    }

    public String resolveSharedString(int index) {
        List<CTRst> siElements = sharedStrings.getSi();
        return siElements.get(index).getT().getValue();
    }

    public String resolveCellValue(Cell cell) {
        STCellType cellType = cell.getT();
        if (STCellType.S.equals(cellType)) {
            int sharedStringIndex = Integer.parseInt(cell.getV());
            //System.out.println("The sharedStringIndex: " +sharedStringIndex);
            return resolveSharedString(sharedStringIndex);
        }
        else {
            return cell.getV();
        }
    }

    public String getWorksheetName() {
        return worksheetName;
    }
}
