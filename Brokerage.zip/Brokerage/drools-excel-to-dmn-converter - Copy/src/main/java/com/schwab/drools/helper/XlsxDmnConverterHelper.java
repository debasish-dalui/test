package com.schwab.drools.helper;

import com.schwab.drools.dmn.*;
import com.schwab.drools.util.DmnIdFormatterUtil;
import com.schwab.drools.util.XlsxWorksheetContextReader;
import com.schwab.drools.xlsx.columnDividingStrategy.InputOutputDetectionStrategy;
import com.schwab.drools.xlsx.columnDividingStrategy.SimpleInputOutputDetectionStrategy;
import com.schwab.drools.xlsx.elements.IndexedCell;
import com.schwab.drools.xlsx.elements.IndexedDmnColumns;
import com.schwab.drools.xlsx.elements.IndexedRow;
import com.schwab.drools.xlsx.elements.InputOutputColumns;
import lombok.extern.slf4j.Slf4j;
import org.kie.dmn.model.v1_1.*;

import javax.xml.namespace.QName;
import java.util.*;
import java.util.List;

@Slf4j
public class XlsxDmnConverterHelper {

    protected Set<String> inputs;
    protected Set<String> outputs;
    protected List<XlsxWorksheetContextReader> worksheetContextList;
    protected InputOutputDetectionStrategy ioDetectionStrategy;
    protected final static String UNDERSCORE = "_";
    protected final static String SPACE = "\\s+";
    protected final static String EMPTYSPACE = "";
    protected ArrayList<String> inputsAndOutputs;

    public XlsxDmnConverterHelper(List<XlsxWorksheetContextReader> worksheetContextList,
                                  Set<String> inputs,
                                  Set<String> outputs) {
        this.worksheetContextList = worksheetContextList;
        this.inputs = inputs;
        this.outputs = outputs;
        this.inputsAndOutputs = new ArrayList<String>();
        this.ioDetectionStrategy = new SimpleInputOutputDetectionStrategy();
    }

    public Definitions convert2(){
        Definitions dmnModel = initializeEmptyDmnModel();
        List<DRGElement> drgElements = dmnModel.getDrgElement();

        return dmnModel;
    }

    public Definitions convert() {
        // initialize the empty definitions
        Definitions dmnModel = initializeEmptyDmnModel();
        // empty drg-elements
        List<DRGElement> drgElements = dmnModel.getDrgElement();

        //TODO: CURRENTLY USES THE HARDCODES INPUTS AND OUTPUTS FROM THE CLI- CONVERTER
        // initialize DRG model
        DrgModel drgModel = new DrgModel(inputs, outputs);
        // Step1: add InputData(s) to DMN
        deriveInputDatas(drgElements);

        // Step2: iterate each worksheets, and add decisions to DMN
        for (XlsxWorksheetContextReader worksheetContext : worksheetContextList) {
            String worksheetName = worksheetContext.getWorksheetName();
            List<IndexedRow> rows = worksheetContext.getRows();
            InputOutputColumns inputOutputColumns = ioDetectionStrategy.determineHeaderCells(rows.get(1), rows.get(2), worksheetContext);
            drgModel.addDecisionsWithInputOutputColumns(DmnIdFormatterUtil.dmnFormattedVariableNamingStandard(worksheetName), inputOutputColumns);
        }

        // Step 3: determine drg relations...
        drgModel.determineDrgRelations();

        // step 4: add decisions to DMN
        for (Map.Entry<String,InputOutputColumns> decisionMap : drgModel.getDecisionsWithInputOutputColumns().entrySet()) {
            String decisionName = decisionMap.getKey();
            Decision decision = new Decision();
            decision.setId(DmnIdFormatterUtil.dmnFormattedIdNamingStandard(decisionName));
            decision.setName(DmnIdFormatterUtil.dmnFormattedVariableNamingStandard(decisionName));
            drgElements.add(decision);

            InputOutputColumns ioColumns = decisionMap.getValue();
            for (String outputHeaderName : ioColumns.getOutputHeaderCellValues()) {
                InformationItem variable = new InformationItem();
                DmnDecisionTableIOProperty dtIOProperty = ioColumns.getPropertyCellValues(DmnIdFormatterUtil.dmnFormattedVariableNamingStandard(outputHeaderName));
                variable.setTypeRef(new QName(dtIOProperty.getType())); //by default considering all typeRef as feel:string type
                variable.setName(DmnIdFormatterUtil.dmnFormattedVariableNamingStandard(outputHeaderName));
                decision.setVariable(variable);
            }

            // handle CLI columns **NOTE POSSIBLE ERROR HERE
            System.out.println(decision.getName());
            if ( drgModel.getDecisionsWithCliColumns().containsKey(decision.getName()) ) {
                List<String> cliColumnValues = drgModel.getDecisionsWithCliColumns().get(decisionName);
                for (String cliColumnValue : cliColumnValues) {
                    InformationRequirement infoRequirement = new InformationRequirement();
                    DMNElementReference dmnElementReference = new DMNElementReference();
                    dmnElementReference.setHref("#" + DmnIdFormatterUtil.dmnFormattedIdNamingStandard(cliColumnValue));
                    infoRequirement.setRequiredInput(dmnElementReference);
                    decision.getInformationRequirement().add(infoRequirement);
                }
            }

            // handle other columns
            if (drgModel.getDecisionRelations() != null && (drgModel.getDecisionRelations().containsKey(decision.getName()))) {
                Map<String,String> outputDecisions = drgModel.getDecisionRelations().get(decisionName);

                for (Map.Entry<String,String> outputDecision : outputDecisions.entrySet()) {
                    String outputDecisionName = outputDecision.getKey();
                    String matchedColumnName = outputDecision.getValue();

                    InformationRequirement infoRequirement = new InformationRequirement();
                    DMNElementReference dmnElementReference = new DMNElementReference();
                    dmnElementReference.setHref(DmnIdFormatterUtil.dmnFormattedHrefNamingStandard(matchedColumnName));
                    infoRequirement.setRequiredDecision(dmnElementReference);
                    decision.getInformationRequirement().add(infoRequirement);
                }
            }

            // for every decision, there will be an knowledge requirement, which connected to business knowledge model.
            KnowledgeRequirement knowledgeRequirement = new KnowledgeRequirement();
            DMNElementReference dmnElementReference = new DMNElementReference();
            dmnElementReference.setHref(DmnIdFormatterUtil.dmnFormattedKnowledgeReqNamingStandardHref(decision.getName()));
            knowledgeRequirement.setRequiredKnowledge(dmnElementReference);
            decision.getKnowledgeRequirement().add(knowledgeRequirement);

            // invocation
            Invocation invocation = new Invocation();
            LiteralExpression literalExpression = new LiteralExpression();
            literalExpression.setText(decision.getName());
            invocation.setExpression(literalExpression);
            decision.setExpression(invocation);
        }

        // add decision table within business knowledge model
        for (XlsxWorksheetContextReader worksheetContext : worksheetContextList) {
            DmnConversionContext dmncContext = new DmnConversionContext(worksheetContext);
            // order is important; add most specific converters first
            dmncContext.addCellContentHandler(new DmnValueRangeConverter());
            dmncContext.addCellContentHandler(new DmnFeelSimpleUnaryTestConverter());
            dmncContext.addCellContentHandler(new DmnValueStringConverter());
            dmncContext.addCellContentHandler(new DmnValueNumberConverter());

            // no. of decisions will be based on number of worksheets
            String worksheetName = worksheetContext.getWorksheetName();
            System.out.println("---------------------- Worksheet Name ---------------------->" + worksheetName);

            BusinessKnowledgeModel bizKnwldgeModel = new BusinessKnowledgeModel();
            bizKnwldgeModel.setId(DmnIdFormatterUtil.dmnFormattedKnowledgeReqNamingStandard(worksheetName));

            bizKnwldgeModel.setName(worksheetName + "Rules"); //TODO need to read from the decision table name
            FunctionDefinition funcDfn = new FunctionDefinition();
            bizKnwldgeModel.setEncapsulatedLogic(funcDfn);

            DecisionTable decisionTable = new DecisionTable();
            decisionTable.setId(UUID.randomUUID().toString());
            decisionTable.setLabel(worksheetName + "Rules");
            decisionTable.setPreferredOrientation(DecisionTableOrientation.RULE_AS_ROW);
            decisionTable.setHitPolicy(HitPolicy.UNIQUE);
            funcDfn.setExpression(decisionTable);

            List<IndexedRow> rows = worksheetContext.getRows();
            // we have the columns mapped to decision, so get it.
            InputOutputColumns ioColumns = drgModel.getDecisionsWithInputOutputColumns().get(DmnIdFormatterUtil.dmnFormattedVariableNamingStandard(worksheetName));

            String outputVarType = convertInputsOutputs(dmncContext, worksheetContext, decisionTable, ioColumns );
            convertRules(dmncContext, decisionTable, rows.subList(3, rows.size())); //ignore 1st 3 rows

            InformationItem variable = new InformationItem();
            System.out.println("DmnDecisionTableIOProperty: " + outputVarType);
            variable.setTypeRef(new QName(outputVarType));
            variable.setName(DmnIdFormatterUtil.dmnFormattedVariableNamingStandard(worksheetName));
            bizKnwldgeModel.setVariable(variable);

            drgElements.add(bizKnwldgeModel);
        }

        return dmnModel;
    }

    protected void convertRules(DmnConversionContext dmnConversionContext, DecisionTable decisionTable, List<IndexedRow> rulesRows) {
        for (IndexedRow rule : rulesRows) {
            convertRule(dmnConversionContext, decisionTable, rule);
        }
    }

    protected void convertRule(DmnConversionContext dmnConversionContext, DecisionTable decisionTable, IndexedRow ruleRow) {

        DecisionRule decisionRule = new DecisionRule();
        decisionRule.setId(UUID.randomUUID().toString());
        decisionTable.getRule().add(decisionRule);
        IndexedDmnColumns dmnColumns = dmnConversionContext.getIndexedDmnColumns();
        System.out.println("######################################################");
        for (InputClause input : dmnColumns.getOrderedInputs()) {
            String xlsxColumn = dmnColumns.getXlsxColumn(input);
            System.out.println("The input xlsxColumn: " + xlsxColumn);
            IndexedCell cell = ruleRow.getCell(xlsxColumn);

            UnaryTests inputEntry = new UnaryTests();
            String textValue = cell != null ? dmnConversionContext.resolveCellValue(cell.getCell()) : getDefaultCellContent();
            textValue = ((textValue != null) && (!textValue.equals("null"))) ? textValue : getDefaultCellContent();
            System.out.println("The InputClause textValue: " + textValue);
            inputEntry.setText(textValue);
            inputEntry.setId(UUID.randomUUID().toString());
            decisionRule.getInputEntry().add(inputEntry);
        }

        for (OutputClause output : dmnColumns.getOrderedOutputs()) {
            String xlsxColumn = dmnColumns.getXlsxColumn(output);
            System.out.println("The output xlsxColumn: " + xlsxColumn);
            IndexedCell cell = ruleRow.getCell(xlsxColumn);

            LiteralExpression outputEntry = new LiteralExpression();
            String textValue = cell != null ? dmnConversionContext.resolveCellValue(cell.getCell()) : getDefaultCellContent();
            System.out.println("The Output textValue: " + textValue);
            outputEntry.setText(textValue);
            outputEntry.setId(UUID.randomUUID().toString());
            decisionRule.getOutputEntry().add(outputEntry);
        }
    }

    protected String convertInputsOutputs ( DmnConversionContext dmncContext, XlsxWorksheetContextReader worksheetContext, DecisionTable decisionTable, InputOutputColumns ioColumns ) {

        String outputVarType = "feel:string"; // default type value

        for (IndexedCell inputCell : ioColumns.getInputHeaderCells()) {
            String inputHeaderName = worksheetContext.resolveCellValue(inputCell.getCell());
            InputClause input = new InputClause();
            input.setId(UUID.randomUUID().toString());
            input.setLabel(inputHeaderName);
            System.out.println("DEBA------------->" + inputHeaderName);
            DmnDecisionTableIOProperty dtIOProperty = ioColumns
                    .getPropertyCellValues(DmnIdFormatterUtil.dmnFormattedVariableNamingStandard(inputHeaderName));

            LiteralExpression inputExpression = new LiteralExpression();
            inputExpression.setTypeRef(new QName(dtIOProperty.getType()));
            inputExpression.setText(DmnIdFormatterUtil.dmnFormattedVariableNamingStandard(inputHeaderName));
            input.setInputExpression(inputExpression);

            if (dtIOProperty.getBoundary() != null) {
                UnaryTests inputValues = new UnaryTests();
                String boundary = dtIOProperty.getBoundary();
                boundary = boundary.replaceAll("'", "\"");
                inputValues.setText(boundary);
                input.setInputValues(inputValues);
            }

            decisionTable.getInput().add(input);
            dmncContext.getIndexedDmnColumns().addInput(inputCell, input);
        }

        for (IndexedCell outputCell : ioColumns.getOutputHeaderCells()) {
            String outputHeaderName = worksheetContext.resolveCellValue(outputCell.getCell());
            OutputClause output = new OutputClause();
            output.setId(UUID.randomUUID().toString());
            output.setLabel(outputHeaderName);

            // System.out.println("------------->" + outputHeaderName);
            DmnDecisionTableIOProperty dtIOProperty = ioColumns
                    .getPropertyCellValues(DmnIdFormatterUtil.dmnFormattedVariableNamingStandard(outputHeaderName));

            if (dtIOProperty.getBoundary() != null) {
                UnaryTests outputValue = new UnaryTests();
                String boundary = dtIOProperty.getBoundary();
                boundary = boundary.replaceAll("'", "\"");
                outputValue.setText(boundary);
                output.setOutputValues(outputValue);
            }

            if (dtIOProperty.getDefaultvalue() != null) {
                LiteralExpression outputExpression = new LiteralExpression();
                String defaultValue = dtIOProperty.getDefaultvalue();
                defaultValue = "\"" + defaultValue + "\"";
                outputExpression.setText(defaultValue);
                output.setDefaultOutputEntry(outputExpression);
            }

            if (dtIOProperty.getType() != null) {
                outputVarType = dtIOProperty.getType();
            }

            decisionTable.getOutput().add(output);
            dmncContext.getIndexedDmnColumns().addOutput(outputCell, output);
        }

        return outputVarType;
    }

    protected Definitions initializeEmptyDmnModel() {
        Definitions dmnModel = new Definitions();
        dmnModel.setNamespace("https://www.drools.org/kie-dmn");
        dmnModel.getNsContext().put("feel", "http://www.omg.org/spec/FEEL/20140401");
        dmnModel.setId("_Test");
        dmnModel.setName("Test");
        return dmnModel;
    }

    //TODO: CURRENTLY THIS IS HARD CODED AND NEEDS TO BE CHANGED -- SHOULD USE THE COLUMNS HEADERS FROM EXCEL INSTEAD
    protected void deriveInputDatas( List<DRGElement> drgElements ) {
        Iterator<String> itr = inputs.iterator();
        while (itr.hasNext()) {
            String inputName = (String) itr.next();
            InputData inputData = new InputData();
            inputData.setName(DmnIdFormatterUtil.dmnFormattedVariableNamingStandard(inputName));
            inputData.setId(DmnIdFormatterUtil.dmnFormattedIdNamingStandard(inputName));

            InformationItem variable = new InformationItem();
            variable.setTypeRef(new QName("feel:string")); //bby default considering all input typeRef as feel:string type
            variable.setName(DmnIdFormatterUtil.dmnFormattedVariableNamingStandard(inputName));
            inputData.setVariable(variable);

            drgElements.add(inputData);
        }
    }

    protected String getDefaultCellContent() {
        return "";
    }
}
