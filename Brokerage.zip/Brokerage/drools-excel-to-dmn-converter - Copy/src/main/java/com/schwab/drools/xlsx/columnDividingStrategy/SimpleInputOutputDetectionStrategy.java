package com.schwab.drools.xlsx.columnDividingStrategy;

import com.schwab.drools.util.DmnIdFormatterUtil;
import com.schwab.drools.util.XlsxWorksheetContextReader;
import com.schwab.drools.xlsx.elements.IndexedCell;
import com.schwab.drools.xlsx.elements.IndexedRow;
import com.schwab.drools.xlsx.elements.InputOutputColumns;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;

@Slf4j
public class SimpleInputOutputDetectionStrategy implements InputOutputDetectionStrategy {

    List<String> hitPolicies;

    public SimpleInputOutputDetectionStrategy() {
        super();
        hitPolicies = new ArrayList<String>();
        hitPolicies.add("U");
        hitPolicies.add("A");
        hitPolicies.add("P");
        hitPolicies.add("F");
        hitPolicies.add("O");
        hitPolicies.add("R");
    }
    //TODO: CURRENTLY THERE IS ONLY ONE OUTPUT COLUMN.....PROBABLY NEED TO CHANGE THIS TO MAKE IT MORE DYNAMIC
    public InputOutputColumns determineHeaderCells(IndexedRow headerRow, IndexedRow propertyRow, XlsxWorksheetContextReader context) {
        if (!headerRow.hasCells()) {
            log.error("DMN tables require at least one output. The header row contains no entries.");
            throw new RuntimeException("A dmn table requires at least one output; the header row contains no entries");
        }
        InputOutputColumns inputOutputColumns = new InputOutputColumns();

        List<IndexedCell> inputOutputCells = headerRow.getCells();

        inputOutputColumns.addOutputHeaderCell(inputOutputCells.get(inputOutputCells.size() - 1));
        String headerValue = context.resolveCellValue((inputOutputCells.get(inputOutputCells.size() - 1)).getCell());
        inputOutputColumns.addOutputHeaderCellValues(headerValue);

        List<IndexedCell> cellProperties = propertyRow.getCells();
        String outputCellPropertyValue = context.resolveCellValue((cellProperties.get(inputOutputCells.size() - 1)).getCell());
        inputOutputColumns.addPropertyCellValues(DmnIdFormatterUtil.dmnFormattedVariableNamingStandard(headerValue), outputCellPropertyValue);

        List<IndexedCell> inputCells = inputOutputCells.subList(0, inputOutputCells.size() - 1);
        List<IndexedCell> inputCellProperties = cellProperties.subList(0, inputOutputCells.size() - 1);
        for (int index = 0; index < inputCells.size(); index++) {
            IndexedCell inputCell = inputCells.get(index);
            if (!hitPolicies.contains(context.resolveCellValue(inputCell.getCell()))) { //need to work on additionals type
                inputOutputColumns.addInputHeaderCell(inputCell);
                String inputValue = context.resolveCellValue(inputCell.getCell());
                inputOutputColumns.addinputHeaderCellValues(inputValue);

                String inputCellPropertyValue = context.resolveCellValue((inputCellProperties.get(index)).getCell());
                if ((inputCellPropertyValue != null) && (!inputCellPropertyValue.equals("null"))) {
                    inputOutputColumns.addPropertyCellValues(DmnIdFormatterUtil.dmnFormattedVariableNamingStandard(inputValue),
                            inputCellPropertyValue);
                }
            }
        }
        return inputOutputColumns;
    }
}
