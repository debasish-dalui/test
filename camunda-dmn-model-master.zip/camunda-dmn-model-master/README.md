camunda-dmn-model
==================

DMN 1.1 model API written in Java.

Used DMN 1.1 Schema: [DMN11.xsd](src/main/resources/DMN11.xsd)
