package org.camunda.bpm.dmn.xlsx.Practice;

import java.io.FileNotFoundException;


/**
 * Name:org.camunda.bpm.dmn.xlsx.Practice.Main
 * Description:
 *
 * @author jhoan.osorno
 */
public class Main {
    public static void main(String[] args) {
        XmlConverterToDmn camundaConversion = new XmlConverterToDmn();
        try{
            camundaConversion.convertExcelToDmn("test2.xlsx", "outResult.xml", 2);
        }
        catch(FileNotFoundException e){
            e.printStackTrace();
        }
    }
}
