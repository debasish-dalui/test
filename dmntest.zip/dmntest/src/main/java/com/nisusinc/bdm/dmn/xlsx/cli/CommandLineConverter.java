/* Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.nisusinc.bdm.dmn.xlsx.cli;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.util.HashSet;
import java.util.Set;

import org.kie.dmn.api.marshalling.v1_1.DMNMarshaller;
import org.kie.dmn.backend.marshalling.v1_1.DMNMarshallerFactory;
import org.kie.dmn.model.v1_1.Definitions;

import com.nisusinc.bdm.dmn.xlsx.XlsxConverter;

/**
 * @author Debasish Dalui
 *
 */
public class CommandLineConverter {

	public static void main(String[] args) {		
		
/*		if (args.length == 0) {
			StringBuilder sb = new StringBuilder();
			sb.append(
					"Usage: java -jar ...jar [--inputs A,B,C,..] [--outputs D,E,F,...] path/to/file.xlsx path/to/outfile.dmn");
			System.out.println(sb.toString());
			return;
		}

		String inputFile = args[args.length - 2];
		String outputFile = args[args.length - 1];
		
		Set<String> inputs = null;
		Set<String> outputs = null;
		for (int i = 0; i < args.length - 2; i++) {
			if ("--inputs".equals(args[i])) {
				inputs = new HashSet<String>();
				inputs.addAll(Arrays.asList(args[i + 1].split(",")));
			}

			if ("--outputs".equals(args[i])) {
				outputs = new HashSet<String>();
				outputs.addAll(Arrays.asList(args[i + 1].split(",")));
			}
		}*/

		//Test
		String inputFile = "D:/DEV/DMN/dmntest/dmntest/src/main/resource/com/nisusinc/bdm/dmn/dmntest/Series910PoC.xlsx"; 
		String outputFile = "D:/DEV/DMN/dmntest/dmntest/src/main/resource/com/nisusinc/bdm/dmn/dmntest/Series910PoC-v0.1.xml";
		Set<String> inputs = new HashSet<String>();
		inputs.add("Registration Type");
		inputs.add("Registration Subtype");
		inputs.add("Legal Address Country");
		inputs.add("Citizenship Country");
		inputs.add("Residence Country");
		inputs.add("Client Type");
		
		Set<String> outputs = new HashSet<String>();
		outputs.add("Auto Review Status");
		
		XlsxConverter converter = new XlsxConverter();
		FileInputStream fileInputStream = null;
		FileWriter fileWriter = null;
		try {
			try {
				fileInputStream = new FileInputStream(inputFile);
				fileWriter = new FileWriter(outputFile);

				Definitions dmnDefinitions = converter.convert(fileInputStream, inputs, outputs);
				System.out.println("DMN Definitions: " + dmnDefinitions);

				DMNMarshaller dmnMarshaller = DMNMarshallerFactory.newDefaultMarshaller();
				String dmnStr = dmnMarshaller.marshal(dmnDefinitions);
				System.out.println("DMN Gen Test (From Excel): " + dmnStr);

				// dmnMarshaller.marshal(dmnDefinitions, fileWriter);
			} finally {
				if (fileInputStream != null) {
					fileInputStream.close();
				}

				if (fileWriter != null) {
					fileWriter.close();
				}
			}
		} catch (Exception e) {
			System.out.println("Could not convert file: " + e.getMessage());
			e.printStackTrace(System.out);
		}

	}
}
