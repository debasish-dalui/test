/* Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.nisusinc.bdm.dmn.xlsx;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.namespace.QName;

import org.kie.dmn.model.v1_1.BusinessKnowledgeModel;
import org.kie.dmn.model.v1_1.DMNElementReference;
import org.kie.dmn.model.v1_1.DRGElement;
import org.kie.dmn.model.v1_1.Decision;
import org.kie.dmn.model.v1_1.DecisionTable;
import org.kie.dmn.model.v1_1.Definitions;
import org.kie.dmn.model.v1_1.FunctionDefinition;
import org.kie.dmn.model.v1_1.InformationItem;
import org.kie.dmn.model.v1_1.InformationRequirement;
import org.kie.dmn.model.v1_1.InputData;
import org.kie.dmn.model.v1_1.Invocation;
import org.kie.dmn.model.v1_1.KnowledgeRequirement;
import org.kie.dmn.model.v1_1.LiteralExpression;

import com.nisusinc.bdm.dmn.xlsx.elements.IndexedCell;
import com.nisusinc.bdm.dmn.xlsx.elements.IndexedRow;

/**
 * @author Debasish Dalui
 *
 */
public class XlsxWorksheetConverter {

	protected Set<String> inputs; 
	protected Set<String> outputs;
	protected List<XlsxWorksheetContext> worksheetContextList;
	protected DmnConversionContext dmnConversionContext;
	protected InputOutputDetectionStrategy ioDetectionStrategy;
	protected final static String UNDERSCORE = "_";
	protected final static String SPACE = "\\s+";
	protected final static String EMPTYSPACE = "";

	public XlsxWorksheetConverter(List<XlsxWorksheetContext> worksheetContextList, Set<String> inputs,
			Set<String> outputs) {
		this.worksheetContextList = worksheetContextList;
		this.inputs = inputs;
		this.outputs = outputs;

		for (XlsxWorksheetContext worksheetContext : worksheetContextList) {
			this.dmnConversionContext = new DmnConversionContext(worksheetContext);
			this.ioDetectionStrategy = new SimpleInputOutputDetectionStrategy();

			// TODO order is important; add most specific converters first ???
			/*
			 * this.dmnConversionContext.addCellContentHandler(new
			 * DmnValueRangeConverter());
			 * this.dmnConversionContext.addCellContentHandler(new
			 * FeelSimpleUnaryTestConverter());
			 * this.dmnConversionContext.addCellContentHandler(new
			 * DmnValueStringConverter());
			 * this.dmnConversionContext.addCellContentHandler(new
			 * DmnValueNumberConverter());
			 */
		}
	}

	public Definitions convert() {

		// initialize the empty definitions
		Definitions dmnModel = initializeEmptyDmnModel();

		// empty drg-elements
		List<DRGElement> drgElements = dmnModel.getDrgElement();
		
		// initialize DRG model
		DrgModel drgModel = new DrgModel(inputs, outputs);
		
		// Step1: add InputData(s) to DMN
		deriveInputDatas(drgElements);
		
		// Step2: iterate each worksheets, and add decisions to DMN
		for (XlsxWorksheetContext worksheetContext : worksheetContextList) {

			// no of decisions will be based on number of worksheets
			String worksheetName = worksheetContext.getWorksheetName();
			//worksheetName = worksheetName.replaceAll("\\s+", "");
			//System.out.println("After Removal of whitespace - Worksheet Name: " + worksheetName);
			//Decision decision = new Decision();
			//decision.setId(UNDERSCORE + worksheetName);
			//decision.setName(worksheetName);
			// dmnModel.addChildren(decision);
			//drgElements.add(decision);
			
			// get input & output cell
			List<IndexedRow> rows = worksheetContext.getRows();
			InputOutputColumns inputOutputColumns = ioDetectionStrategy.determineHeaderCells(rows.get(1), worksheetContext);
			//System.out.println("----------->" + inputOutputColumns.getInputHeaderCellValues());
			drgModel.addDecisionsWithInputOutputColumns(dmnFormattedVariableNamingStandard(worksheetName), inputOutputColumns);
		}
		
		// determine the relationships within decisions test
		/*
		Map<String, InputOutputColumns> decisionsWithInputOutputColumns = drgModel.getDecisionsWithInputOutputColumns();		
		Iterator<String> itr1 = decisionsWithInputOutputColumns.keySet().iterator();
		while (itr1.hasNext()) {
			String decision = (String) itr1.next();
			System.out.println("The decision name: " + decision);
			InputOutputColumns inputOutputColumns = decisionsWithInputOutputColumns.get(decision);	
			
			System.out.println("The inputs: " + inputOutputColumns.getInputHeaderCellValues());
			System.out.println("The outputs: " + inputOutputColumns.getOutputHeaderCellValues());
		}*/
		
		//System.out.println("Mapped Decisions with All IO: "+ drgModel.getDecisionsWithInputOutputColumns());
		
		// Step 3: determine drg relations...
		drgModel.determineDrgRelations();
		
		// step 4: add decisions to DMN
		for (Map.Entry<String,InputOutputColumns> decisionMap : drgModel.getDecisionsWithInputOutputColumns().entrySet()) {
			String decisionName = decisionMap.getKey();
			Decision decision = new Decision();
			decision.setId(dmnFormattedIdNamingStandard(decisionName));
			decision.setName(dmnFormattedVariableNamingStandard(decisionName));
			//System.out.println("Decision name: " + decision.getName());
			// dmnModel.addChildren(decision);
			drgElements.add(decision);
			
			InputOutputColumns ioColumns = decisionMap.getValue();
			for (String outputHeaderName : ioColumns.getOutputHeaderCellValues()) {
				InformationItem variable = new InformationItem();
				variable.setTypeRef(new QName("feel:string")); //bby default considering all typeRef as feel:string type
				variable.setName(dmnFormattedVariableNamingStandard(outputHeaderName));
				decision.setVariable(variable);
			}
			
			// handle CLI columns
			if ( drgModel.getDecisionsWithCliColumns().containsKey(decision.getName()) ) {
				//System.out.println("2. Decision name: " + decision.getName());
				List<String> cliColumnValues = drgModel.getDecisionsWithCliColumns().get(decisionName);				
				for (String cliColumnValue : cliColumnValues) {
					InformationRequirement infoRequirement = new InformationRequirement();
					DMNElementReference dmnElementReference = new DMNElementReference();
					dmnElementReference.setHref("#" + dmnFormattedIdNamingStandard(cliColumnValue));
					infoRequirement.setRequiredInput(dmnElementReference);
					System.out.println("2. HREF: " + dmnElementReference.getHref());
					//decision.addChildren(infoRequirement);
					decision.getInformationRequirement().add(infoRequirement);
				}				
			}
			
			// handle other columns
			if ( drgModel.getDecisionRelations().containsKey(decision.getName()) ) {
				Map<String,String> outputDecisions = drgModel.getDecisionRelations().get(decisionName);
				//System.out.println("Input Decison Name: " + decisionName);
				
				for (Map.Entry<String,String> outputDecision : outputDecisions.entrySet()) {
					String outputDecisionName = outputDecision.getKey();
					String matchedColumnName = outputDecision.getValue();
					
					//System.out.println("Output Decison Name: " + outputDecisionName);
					//System.out.println("Matched Column Name: " + matchedColumnName);
					
					InformationRequirement infoRequirement = new InformationRequirement();
					DMNElementReference dmnElementReference = new DMNElementReference();
					dmnElementReference.setHref(dmnFormattedHrefNamingStandard(matchedColumnName));
					infoRequirement.setRequiredDecision(dmnElementReference);
					decision.getInformationRequirement().add(infoRequirement);
				}
			}
			
			// for every decision, there will be an knowledge requirement, which connected to business knowledge model. 
			KnowledgeRequirement knowledgeRequirement = new KnowledgeRequirement();
			DMNElementReference dmnElementReference = new DMNElementReference();
			dmnElementReference.setHref(dmnFormattedKnowledgeReqNamingStandard(decision.getName()));
			knowledgeRequirement.setRequiredKnowledge(dmnElementReference);
			decision.getKnowledgeRequirement().add(knowledgeRequirement);
			
			// invocation
			Invocation invocation = new Invocation();
			LiteralExpression literalExpression = new LiteralExpression();
			literalExpression.setText(decision.getName());
			invocation.setExpression(literalExpression);
			decision.setExpression(invocation);
		}
		
		// add decision table within business knowledge model
		BusinessKnowledgeModel bizKnwldgeModel = new BusinessKnowledgeModel();
		//bizKnwldgeModel.setId(value);
		FunctionDefinition funcDfn = new FunctionDefinition();
		DecisionTable decisionTable = new DecisionTable();
		//decisionTable.set
		
		funcDfn.setExpression(decisionTable);
		
		bizKnwldgeModel.setEncapsulatedLogic(funcDfn);
		drgElements.add(bizKnwldgeModel);
			
		
		for (Map.Entry<String,Map<String,String>> inputDecision : drgModel.getDecisionRelations().entrySet()) {
			String inputDecisionName = inputDecision.getKey();
			Map<String,String> outputDecisions = inputDecision.getValue();
			System.out.println("Input Decison Name: " + inputDecisionName);
			
			for (Map.Entry<String,String> outputDecision : outputDecisions.entrySet()) {
				String outputDecisionName = outputDecision.getKey();
				String matchedColumnName = outputDecision.getValue();
				System.out.println("Output Decison Name: " + outputDecisionName);
				System.out.println("Matched Column Name: " + matchedColumnName);
			}
		}
		
		//Map<String, Map<String, String>> mappedDecisions = drgModel.getDecisionRelations();
		//System.out.println("Mapped Decisions: "+ mappedDecisions);
		//drgElements.add(e);

		/*
		 * dmnModel.getDefinitions().addChildElement(decision);
		 * 
		 * DecisionTable decisionTable = generateElement(dmnModel, DecisionTable.class,
		 * "decisionTable"); decision.addChildElement(decisionTable);
		 */

		return dmnModel;
	}
	
	protected void deriveInputDatas( List<DRGElement> drgElements ) {
		Iterator<String> itr = inputs.iterator();
		while (itr.hasNext()) {
			String inputName = (String) itr.next();
			InputData inputData = new InputData();
			inputData.setName(inputName);
			inputData.setId(UNDERSCORE + inputName);
			
			InformationItem variable = new InformationItem();
			variable.setTypeRef(new QName("feel:string")); //bby default considering all typeRef as feel:string type
			variable.setName(inputName);
			inputData.setVariable(variable);
			
			drgElements.add(inputData);
		}
	}
	
/*	protected void convertInputsOutputs(DmnModelInstance dmnModel, DecisionTable decisionTable, IndexedRow header) {		

		// inputs
		for (IndexedCell inputCell : inputOutputColumns.getInputHeaderCells()) {
			Input input = generateElement(dmnModel, Input.class,
					worksheetContext.resolveCellValue(inputCell.getCell()));
			decisionTable.addChildElement(input);

			InputExpression inputExpression = generateElement(dmnModel, InputExpression.class);
			Text text = generateText(dmnModel, worksheetContext.resolveCellValue(inputCell.getCell()));
			inputExpression.setText(text);
			input.setInputExpression(inputExpression);

			dmnConversionContext.getIndexedDmnColumns().addInput(inputCell, input);
		}

		// outputs
		for (IndexedCell outputCell : inputOutputColumns.getOutputHeaderCells()) {
			Output output = generateElement(dmnModel, Output.class,
					worksheetContext.resolveCellValue(outputCell.getCell()));
			output.setName(worksheetContext.resolveCellValue(outputCell.getCell()));
			decisionTable.addChildElement(output);

			dmnConversionContext.getIndexedDmnColumns().addOutput(outputCell, output);
		}

	}*/

	protected String getDefaultCellContent() {
		return "-";
	}

	protected Definitions initializeEmptyDmnModel() {

		Definitions dmnModel = new Definitions();
		dmnModel.setNamespace("https://www.drools.org/kie-dmn");
		dmnModel.getNsContext().put("feel", "http://www.omg.org/spec/FEEL/20140401");
		dmnModel.setId("_Test");
		dmnModel.setName("Test");

		return dmnModel;
	}
	

	protected static String dmnFormattedKnowledgeReqNamingStandard(String input) {

		return "#d" + dmnFormattedIdNamingStandard(input) + "Rules";
	}
	
	protected static String dmnFormattedHrefNamingStandard(String input) {

		return "#" + dmnFormattedIdNamingStandard(input);
	}
	
	protected static String dmnFormattedIdNamingStandard(String input) {

		return UNDERSCORE + dmnFormattedVariableNamingStandard(input);
	}
	
	protected static String dmnFormattedVariableNamingStandard(String input) {

		String str = input.replaceAll(SPACE, EMPTYSPACE);
		str = Character.toLowerCase(str.charAt(0)) + str.substring(1);

		return str;
	}

}
