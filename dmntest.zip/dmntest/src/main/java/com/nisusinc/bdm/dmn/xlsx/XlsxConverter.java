/* Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.nisusinc.bdm.dmn.xlsx;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.docx4j.docProps.extended.Properties;
import org.docx4j.openpackaging.exceptions.Docx4JException;
import org.docx4j.openpackaging.packages.SpreadsheetMLPackage;
import org.docx4j.openpackaging.parts.SpreadsheetML.SharedStrings;
import org.docx4j.openpackaging.parts.SpreadsheetML.WorkbookPart;
import org.docx4j.openpackaging.parts.SpreadsheetML.WorksheetPart;
import org.kie.dmn.model.v1_1.Definitions;

/**
 * @author Debasish Dalui
 *
 */
public class XlsxConverter {

	//protected InputOutputDetectionStrategy ioDetectionStrategy;
	protected List<XlsxWorksheetContext> worksheetContextList;
	
	public XlsxConverter() {
		//ioDetectionStrategy = new SimpleInputOutputDetectionStrategy();
		worksheetContextList = new ArrayList<XlsxWorksheetContext>();
	}

	public Definitions convert(InputStream inputStream, Set<String> inputs, Set<String> outputs) {
		SpreadsheetMLPackage spreadSheetPackage = null;
		try {
			spreadSheetPackage = (SpreadsheetMLPackage) SpreadsheetMLPackage.load(inputStream);
		} catch (Docx4JException e) {
			// TODO: checked exception
			throw new RuntimeException("cannot load document", e);
		}

		WorkbookPart workbookPart = spreadSheetPackage.getWorkbookPart();
		// TODO: exception when no worksheet present
		// TODO: make worksheet number configurable/import all worksheets?
		XlsxWorksheetContext worksheetContext = null;

		WorksheetPart worksheetPart = null;
		try {
			for (int i = 0; i < workbookPart.getContents().getSheets().getSheet().size(); i++) {
				Properties properties = spreadSheetPackage.getDocPropsExtendedPart().getContents();
				String worksheetName = (String) properties.getTitlesOfParts().getVector().getVariantOrI1OrI2().get(i)
						.getValue();
				
				System.out.println("Worksheet name: " + worksheetName);
				worksheetPart = workbookPart.getWorksheet(i);
				SharedStrings sharedStrings = workbookPart.getSharedStrings();
				worksheetContext = new XlsxWorksheetContext(sharedStrings.getContents(), worksheetPart.getContents(),
						worksheetName);
				worksheetContextList.add(worksheetContext);
			}
		} catch (Exception e) {
			throw new RuntimeException("Could not determine worksheet", e);
		}

		return new XlsxWorksheetConverter(worksheetContextList, inputs, outputs).convert();
	}

	public InputOutputDetectionStrategy getIoDetectionStrategy() {
		return ioDetectionStrategy;
	}

	public void setIoDetectionStrategy(InputOutputDetectionStrategy ioDetectionStrategy) {
		this.ioDetectionStrategy = ioDetectionStrategy;
	}

}
