package com.nisusinc.bdm.dmn.dmntest;

import java.math.BigDecimal;
import java.util.Map;
import java.util.UUID;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.dmn.api.core.DMNContext;
import org.kie.dmn.api.core.DMNDecisionResult;
import org.kie.dmn.api.core.DMNMessage;
import org.kie.dmn.api.core.DMNModel;
import org.kie.dmn.api.core.DMNResult;
import org.kie.dmn.api.core.DMNRuntime;
import org.kie.dmn.core.api.DMNFactory;
import org.kie.dmn.core.compiler.RuntimeTypeCheckOption;
import org.kie.dmn.core.impl.DMNRuntimeImpl;
import org.kie.dmn.core.util.KieHelper;

/**
 * Name:
 * Description:
 *
 */
public class Main {
	
	/*
	public void parseExcelToDmn( String excelFile, String dmnFile ) {
		XmlConverterToDmn xmlConverterToDmn = new XmlConverterToDmn();
		//xmlConverterToDmn.convertExcelToDmn(excelFile, dmnFile);
	}*/
	
	public void fireRuleSetSeries910() throws Exception {
		try {
	        final DMNRuntime runtime = Main.createRuntime( "Series910PoC.dmn", this.getClass() );
	        final DMNModel dmnModel = runtime.getModel( "https://www.drools.org/kie-dmn", "Series910PoC" );
	        final DMNContext context = DMNFactory.newContext();
	        
	        context.set( "applicantType", "Individual");
	        context.set( "regType", "Schwab One Accounts");
	        context.set( "regSubType", "Individual");
	        context.set( "country", "USA");
	        context.set( "citizenshipCountry", "USA");
	        context.set( "residenceCountry", "USA");
	        
	        System.out.println("Context: "+ context);
	        
	        final DMNResult dmnResult = runtime.evaluateAll(dmnModel, context);
	        System.out.println("Execution Messages: "+ dmnResult.getMessages());
	        final DMNContext result = dmnResult.getContext();
	        System.out.println("Result Context: "+ result);
	        
	        //System.out.println("Result 910_1: "+ ((Account)result.get("account")).getListedRegistration());
	        System.out.println("Listed Registration?: "+ result.get("listedAccountRegistration"));
	        
	        System.out.println("Address Type: "+ result.get("addressType"));
	        
	        System.out.println("Legal Status: "+ result.get("legalStatus"));
	        
	        System.out.println("AutoReview Status: "+ result.get("autoReviewStatus"));
	        
	        //System.out.println("Result 910_2: "+ dmnResult.getDecisionResultByName("_Series910PoC").getResult());

	        //Map<String, Object> resultsMap = result.getAll();
	        //System.out.println("Result 910_3: "+ ((Account)resultsMap.get("account")).getListedRegistration());
	        /*
	        for ( DMNDecisionResult dmnDecisionResult : dmnResult.getDecisionResults()) {
	        	System.out.println("Result 910_4: "+ dmnDecisionResult.getResult());
			}*/
	        
		} catch (Exception exception) {
			exception.printStackTrace();
			throw new RuntimeException("Errors during firing the rule !!!", exception);
		}
	}
	
	public void fireRuleSetExampleDrools1() throws Exception {
		try {
	        final DMNRuntime runtime = Main.createRuntime( "Example2.dmn", this.getClass() );
	        final DMNModel dmnModel = runtime.getModel( "https://www.drools.org/kie-dmn", "Example2" );
	        final DMNContext context = DMNFactory.newContext();
	        context.set( "CustomerStatus", "silver");
	        context.set( "OrderSum", 900);
	        
	        final DMNResult dmnResult = runtime.evaluateAll(dmnModel, context);
	        final DMNContext result = dmnResult.getContext();
	        System.out.println("Result1: "+ result.get("CheckResult"));
	        
	        System.out.println("Result21: "+ dmnResult.getDecisionResultByName("_Example2").getResult());

	        for ( DMNDecisionResult dmnDecisionResult : dmnResult.getDecisionResults()) {
	        	System.out.println("Result11: "+ dmnDecisionResult.getResult());
			}
	        
		} catch (Exception exception) {
			exception.printStackTrace();
			throw new RuntimeException("Errors during firing the rule !!!", exception);
		}
	}
	
	public void fireRuleSetExampleDrools2() throws Exception {
		try {
            final DMNRuntime runtime = Main.createRuntime( "0004-simpletable-U.dmn", this.getClass() );
	        final DMNModel dmnModel = runtime.getModel( "https://www.drools.org/kie-dmn", "0004-simpletable-U" );

	        final DMNContext context = DMNFactory.newContext();
	        context.set("Age", BigDecimal.valueOf(18));
	        context.set("Risk Category", "Medium");
	        context.set("isAffordable", true);
	        
	        final DMNResult dmnResult = runtime.evaluateAll(dmnModel, context);
	        final DMNContext result = dmnResult.getContext();
	        System.out.println("Result3: "+ result.get("ApprovalStatus2"));
	        
	        Map <String, Object> decisionResult = result.getAll();
            System.out.println("Reason31: "+ decisionResult.get("ApprovalStatus2"));            

	        //System.out.println("Result21: "+ dmnResult.getDecisionResultByName("_0004-simpletable-U").getResult());

	        for ( DMNDecisionResult dmnDecisionResult : dmnResult.getDecisionResults()) {
	        	System.out.println("Result41: "+ dmnDecisionResult.getResult());
			}
	        
		} catch (Exception exception) {
			exception.printStackTrace();
			throw new RuntimeException("Errors during firing the rule !!!", exception);
		}
	}
	
	public void fireRuleSetExampleDrools() throws Exception {
		try {
	        KieServices ks = KieServices.Factory.get();
	        KieContainer kieContainer = KieHelper.getKieContainer(
	                ks.newReleaseId("org.kie", "dmn-test-"+ UUID.randomUUID(), "1.0"),
	                ks.getResources().newClassPathResource("Example.dmn", Main.class.getClass() ));
	        DMNRuntime runtime = kieContainer.newKieSession().getKieRuntime(DMNRuntime.class);
	        DMNModel dmnModel = runtime.getModel( "https://www.drools.org/kie-dmn", "Example" );

	        System.out.println(runtime);
	        System.out.println(dmnModel);

	        DMNContext context = DMNFactory.newContext();
	        context.set( "status", "silver");
	        context.set( "sum", 9000);
	        DMNResult dmnResult = runtime.evaluateAll( dmnModel, context );	        
	        DMNContext result = dmnResult.getContext();
	        System.out.println("Decision Result: "+ result.get("decision"));
	        for ( DMNDecisionResult dmnDecisionResult : dmnResult.getDecisionResults()) {
	        	System.out.println("Decision: "+ dmnDecisionResult.getDecisionName());
	            System.out.println("Result: "+ dmnDecisionResult.getResult());
			}
	        for ( DMNMessage dmnMessage : dmnResult.getMessages()) {
	        	System.out.println("Message: "+ dmnMessage.getMessage());
	            System.out.println("Exception: "+ dmnMessage.getException());
			}
		} catch (Exception e) {
			throw new RuntimeException("Errors during firing the rule !!!", e);
		}
	}
	
    private static DMNRuntime createRuntime(final String resourceName, final Class testClass) {
        final KieServices ks = KieServices.Factory.get();
        final KieContainer kieContainer = KieHelper.getKieContainer(
                ks.newReleaseId("org.kie", "dmn-test-"+UUID.randomUUID(), "1.0"),
                ks.getResources().newClassPathResource(resourceName, testClass));

        final DMNRuntime runtime = kieContainer.newKieSession().getKieRuntime(DMNRuntime.class);
        ((DMNRuntimeImpl) runtime).setOption(new RuntimeTypeCheckOption(true));
        return runtime;
    }
	
    /*
	public void fireRuleSetExampleCamunda() throws Exception {
		try {
			// configure and build the DMN engine
		    DmnEngine dmnEngine = DmnEngineConfiguration.createDefaultDmnEngineConfiguration().buildEngine();
		    
		    // parse a decision
		    DmnDecision decision = dmnEngine.parseDecision("decision", createDmnModelInstance());		    
			VariableMap variables = Variables.createVariables().putValue("status", "silver").putValue("sum", 9000);
			DmnDecisionResult results = dmnEngine.evaluateDecision(decision, variables);
			//System.out.println("Decision Result: " + results.getResultList());
			for ( Map <String, Object> decisionResult : results.getResultList()) {
	        	System.out.println("Result: "+ decisionResult.get("result"));
	            System.out.println("Reason: "+ decisionResult.get("reason"));
			}
			
		} catch (Exception e) {
			throw new RuntimeException("Errors during firing the rule !!!", e);
		}
	}	
	
	protected InputStream createInputStream() {
		return IoUtil.fileAsStream("org/camunda/bpm/dmn/xlsx/practice/Example.dmn");
	}

	protected DmnModelInstance createDmnModelInstance() {
		return Dmn.readModelFromStream(createInputStream());
	}*/
	
    public static void main(String[] args) {
        
    	Main main = new Main();
    	try{
    		//main.fireRuleSetExampleCamunda();
    		//main.fireRuleSetExampleDrools1();
    		main.fireRuleSetSeries910();
        }
        catch(Exception exception){
        	exception.printStackTrace();
        }
    }
}
