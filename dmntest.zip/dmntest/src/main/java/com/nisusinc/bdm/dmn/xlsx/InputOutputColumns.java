/* Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.nisusinc.bdm.dmn.xlsx;

import java.util.ArrayList;
import java.util.List;

import com.nisusinc.bdm.dmn.xlsx.elements.IndexedCell;

/**
 * @author Debasish Dalui
 *
 */
public class InputOutputColumns {

	protected List<IndexedCell> inputHeaderCells;
	protected List<IndexedCell> outputHeaderCells;
	protected List<String> inputHeaderCellValues;
	protected List<String> outputHeaderCellValues;

	public InputOutputColumns() {
		this.inputHeaderCells = new ArrayList<IndexedCell>();
		this.outputHeaderCells = new ArrayList<IndexedCell>();
		this.inputHeaderCellValues = new ArrayList<String>();
		this.outputHeaderCellValues = new ArrayList<String>();
	}

	public void addOutputHeaderCell(IndexedCell cell) {
		this.outputHeaderCells.add(cell);
	}

	public void addInputHeaderCell(IndexedCell cell) {
		this.inputHeaderCells.add(cell);
	}
	
	public void addinputHeaderCellValues(String cellValue) {
		this.inputHeaderCellValues.add(cellValue);
	}
	
	public void addOutputHeaderCellValues(String cellValue) {
		this.outputHeaderCellValues.add(cellValue);
	}

	public List<IndexedCell> getOutputHeaderCells() {
		return outputHeaderCells;
	}

	public List<IndexedCell> getInputHeaderCells() {
		return inputHeaderCells;
	}

	public List<String> getInputHeaderCellValues() {
		return inputHeaderCellValues;
	}

	public List<String> getOutputHeaderCellValues() {
		return outputHeaderCellValues;
	}	
	
}
