package com.nisusinc.bdm.dmn.dmntest;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.util.List;

import javax.xml.namespace.QName;

import org.kie.dmn.api.core.DMNContext;
import org.kie.dmn.api.core.DMNModel;
import org.kie.dmn.api.core.DMNResult;
import org.kie.dmn.api.core.DMNRuntime;
import org.kie.dmn.api.marshalling.v1_1.DMNMarshaller;
import org.kie.dmn.backend.marshalling.v1_1.DMNMarshallerFactory;
import org.kie.dmn.core.api.DMNFactory;
import org.kie.dmn.model.v1_1.DMNElement.ExtensionElements;
import org.kie.dmn.model.v1_1.DRGElement;
import org.kie.dmn.model.v1_1.Definitions;
import org.kie.dmn.model.v1_1.InformationItem;
import org.kie.dmn.model.v1_1.InputData;

import com.nisusinc.bdm.dmn.xlsx.XlsxConverter;

/**
 * Test DMN
 *
 */
public class DMNTest {	
	
    public void testSimpleDecisionTableHitPolicyUnique() {
        final DMNRuntime runtime = DMNRuntimeUtil.createRuntime("0004-simpletable-U.dmn", this.getClass());
        final DMNModel dmnModel = runtime.getModel("https://github.com/kiegroup/kie-dmn", "0004-simpletable-U");

        final DMNContext context = getSimpleTableContext(BigDecimal.valueOf(18), "Medium", true);
        final DMNResult dmnResult = runtime.evaluateAll(dmnModel, context);
        
        final DMNContext result = dmnResult.getContext();
        System.out.println("Result context : "+ result);
        System.out.println("Result : "+result.get("Approval Status"));
    }
    
	private void generateDMN() {
		Definitions definitions = new Definitions();
		definitions.setNamespace("https://www.drools.org/kie-dmn");
		definitions.getNsContext().put("feel", "http://www.omg.org/spec/FEEL/20140401");
		definitions.setName("Test");
		definitions.setId("_Test");

		InputData id1 = new InputData();
		id1.setName("regType");
		id1.setId("_regType");
		InformationItem variable1 = new InformationItem();
		variable1.setTypeRef(new QName("feel:string"));
		variable1.setName("regType");
		id1.setVariable(variable1);
		// definitions.addChildren(id1);

		InputData id2 = new InputData();
		id2.setName("regSubType");
		id2.setId("_regSubType");
		InformationItem variable2 = new InformationItem();
		variable2.setTypeRef(new QName("feel:string"));
		variable2.setName("regSubType");
		id2.setVariable(variable2);
		// definitions.addChildren(id2);

		List<DRGElement> drgElements = definitions.getDrgElement();
		drgElements.add(id1);
		drgElements.add(id2);

		DMNMarshaller dmnMarshaller = DMNMarshallerFactory.newDefaultMarshaller();
		String dmnStr = dmnMarshaller.marshal(definitions);

		System.out.println("DMN Gen Test: " + dmnStr);

	}
    
    
    private void generateDMNfromXls () {
    	
    	String inputFile = "D:\\DEV\\DMN\\dmntest\\dmntest\\src\\main\\resource\\com\\nisusinc\\bdm\\dmn\\dmntest\\Series910PoC.xlsx"; 
    	try {
			FileInputStream fileInputStream = new FileInputStream(inputFile);
			XlsxConverter converter = new XlsxConverter();
			Definitions definitions1 = converter.convert(fileInputStream);
			System.out.println("DMN definitions1: " + definitions1);
			
			DMNMarshaller dmnMarshaller1 = DMNMarshallerFactory.newDefaultMarshaller();
	    	String dmnStr1 = dmnMarshaller1.marshal(definitions1);
	    	System.out.println("DMN Gen Test (from Excel): " + dmnStr1);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    }
    
    private DMNContext getSimpleTableContext(final BigDecimal age, final String riskCategory, final boolean isAffordable) {
        final DMNContext context = DMNFactory.newContext();
        context.set("Age", age);
        context.set("RiskCategory", riskCategory);
        context.set("isAffordable", isAffordable);
        return context;
    }
    
	public static void main(String[] args) {
		DMNTest test = new DMNTest();
		//test.generateDMN();
		test.generateDMNfromXls();
		//test.testSimpleDecisionTableHitPolicyUnique();
	}
}
