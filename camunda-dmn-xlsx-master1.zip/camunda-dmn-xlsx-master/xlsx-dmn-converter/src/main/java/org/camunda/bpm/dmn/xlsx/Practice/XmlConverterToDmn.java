package org.camunda.bpm.dmn.xlsx.Practice;

import org.camunda.bpm.dmn.xlsx.XlsxConverter;
import org.camunda.bpm.model.dmn.Dmn;
import org.camunda.bpm.model.dmn.DmnModelInstance;
import org.camunda.bpm.model.dmn.instance.Decision;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class XmlConverterToDmn {


    public void convertExcelToDmn(String pathNameToXslxFile, String pathNameToDmnFile) throws FileNotFoundException {
        OutputStream outputStream;
        try {
            // create the converter and load in the xlsx file path to locate the excel file
            XlsxConverter converter = new XlsxConverter();
            InputStream inputStream = XmlConverterToDmn.class.getClassLoader().getResourceAsStream(pathNameToXslxFile);
            DmnModelInstance dmnModelInstance = converter.convert(inputStream);
            System.out.println("Successfully created DMN instance : " + dmnModelInstance.getDefinitions().getChildElementsByType(Decision.class));
            //check if the Dmn instance is being created
            if (dmnModelInstance != null) {
                //write the dmn file and export
                outputStream = new FileOutputStream(pathNameToDmnFile);

                Dmn.writeModelToStream(outputStream, dmnModelInstance);
            }
        }catch(FileNotFoundException e){
            e.printStackTrace();
        }
    }
}
